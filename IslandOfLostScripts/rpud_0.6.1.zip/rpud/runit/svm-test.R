#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##

library(RUnit)
library(rpud)


testsuite.rpusvm <- defineTestSuite("rpusvm",
		dirs = file.path(path.package(package="rpud"), "runit"),
		testFileRegexp = "^test-svm.+\\.R",
		testFuncRegexp = "^test.svm.+")

testResult <- runTestSuite(testsuite.rpusvm)

printTextProtocol(testResult)



#####################################################################


test.svm <- function(x) {
	
	testsuite.rpusvm <- defineTestSuite("rpusvm",
			dirs = file.path(path.package(package="rpud"), "runit"),
			testFileRegexp = x,
			testFuncRegexp = "^test.svm.+",
			rngKind = "Marsaglia-Multicarry",
			rngNormalKind = "Kinderman-Ramage")
	
	testResult <- runTestSuite(testsuite.rpusvm)
    printTextProtocol(testResult)
}


test.svm("test-svm-sparse-basic.R")

test.svm("test-svm-sparse-cost.R")

test.svm("test-svm-sparse-cross.R")

test.svm("test-svm-sparse-kernel-linear.R")

test.svm("test-svm-sparse-kernel-poly.R")

test.svm("test-svm-sparse-kernel-radial.R")

test.svm("test-svm-sparse-kernel-sigmoid.R")

test.svm("test-svm-sparse-probability.R")

test.svm("test-svm-sparse-scale.R")

test.svm("test-svm-sparse-service.R")


test.svm("test-svm-dense-basic.R")

test.svm("test-svm-dense-cost.R")

test.svm("test-svm-dense-cross.R")

test.svm("test-svm-dense-kernel-linear.R")

test.svm("test-svm-dense-kernel-poly.R")

test.svm("test-svm-dense-kernel-radial.R")

test.svm("test-svm-dense-kernel-sigmoid.R")

test.svm("test-svm-dense-probability.R")

test.svm("test-svm-dense-scale.R")

test.svm("test-svm-dense-service.R")



