#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##


candidates <- 1:16

gen.data <- function(dim, num=120) {
    matrix(sample(candidates, dim*num, replace=TRUE), nrow=num)
}

gen.cases1 <- function(hasNA=FALSE) {
    m <- gen.data(15)
    if (hasNA) {
        m[3,7] <- NA
        m[7:11,9] <- NA
    }
    m
}

N1 <- 7
N2 <- 9

test.kendall.test.tide.symm.pairwise.two.sided <- function() {
    set.seed(17)
    m <- gen.cases1()
	pv1 <- cor.test(m[,N1], m[,N2], method="kendall")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="pairwise")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.symm.pairwise.less <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N1], m[,N2], method="kendall", alternative="less")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="pairwise", alternative="less")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.symm.pairwise.greater <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N1], m[,N2], method="kendall", alternative="greater")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="pairwise", alternative="greater")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.symm.complete.obs.two.sided <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N1], m[,N2], method="kendall")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="complete.obs")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.symm.complete.obs.less <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N1], m[,N2], method="kendall", alternative="less")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="complete.obs", alternative="less")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.symm.complete.obs.greater <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N1], m[,N2], method="kendall", alternative="greater")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="complete.obs", alternative="greater")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

N3 <- 4
N4 <- 12

test.kendall.test.tide.symm.everything.two.sided <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N3], m[,N4], method="kendall")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="everything")$p.value
	checkEqualsNumeric(pv1, pv2[N3, N4], tolerance=1.e-06)
}

test.kendall.test.tide.symm.everything.less <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N3], m[,N4], method="kendall", alternative="less")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="everything", alternative="less")$p.value
	checkEqualsNumeric(pv1, pv2[N3, N4], tolerance=1.e-06)
}

test.kendall.test.tide.symm.everything.greater <- function() {
	set.seed(17)
	m <- gen.cases1()
	pv1 <- cor.test(m[,N3], m[,N4], method="kendall", alternative="greater")$p.value
	pv2 <- rpucor.test(m, method="kendall", use="everything", alternative="greater")$p.value
	checkEqualsNumeric(pv1, pv2[N3, N4], tolerance=1.e-06)
}

.tearDown <- function() {
    flush.console()
}

