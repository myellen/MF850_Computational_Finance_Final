#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##


rpudpath <- path.package(package="rpud")

test.svm.sparse.read.data <- function() {
	
	iris.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris.data <- read.svm.data(iris.path, fac=TRUE, sparse=TRUE)
	
	x1 <- as.matrix(iris.data$x)
	x2 <- as.matrix(subset(iris, select = -Species))
	
	checkEquals(dim(x1), dim(x2))
	checkEqualsNumeric(as.vector(x1), as.vector(x2), tolerance=1.e-07)
	
	checkEquals(as.integer(iris.data$y), as.integer(iris$Species))
}

test.svm.sparse.dense.predict.s0 <- function() {
	
	type <- "C-classification"
	
	iris1.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris1.data <- read.svm.data(iris1.path, fac=TRUE)
	iris1.rpusvm <- rpusvm(iris1.data$x, iris1.data$y, type=type)
	iris1.fitted <- fitted(iris1.rpusvm)
	
	iris2.data <- read.svm.data(iris1.path, fac=TRUE, sparse=FALSE)
	iris2.fitted <- predict(iris1.rpusvm, iris2.data$x)
	
	checkEquals(iris1.fitted, iris2.fitted)
}

test.svm.sparse.dense.predict.s1 <- function() {
	
	type <- "nu-classification"
	
	iris1.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris1.data <- read.svm.data(iris1.path, fac=TRUE)
	iris1.rpusvm <- rpusvm(iris1.data$x, iris1.data$y, type=type)
	iris1.fitted <- fitted(iris1.rpusvm)
	
	iris2.data <- read.svm.data(iris1.path, fac=TRUE, sparse=FALSE)
	iris2.fitted <- predict(iris1.rpusvm, iris2.data$x)
	
	checkEquals(iris1.fitted, iris2.fitted)
}

test.svm.sparse.dense.predict.s2 <- function() {
	
	type <- "one-classification"
	
	iris1.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris1.data <- read.svm.data(iris1.path, fac=TRUE)
	iris1.rpusvm <- rpusvm(iris1.data$x, iris1.data$y, type=type)
	iris1.fitted <- fitted(iris1.rpusvm)
	
	iris2.data <- read.svm.data(iris1.path, fac=TRUE, sparse=FALSE)
	iris2.fitted <- predict(iris1.rpusvm, iris2.data$x)
	
	checkEquals(iris1.fitted, iris2.fitted)
}

test.svm.sparse.dense.predict.s3 <- function() {
	
	type <- "eps-regression"
	
	cadata1.path <- file.path(rpudpath, "runit/data/rpusvm/cadata-sample")
	cadata1.data <- read.svm.data(cadata1.path, fac=FALSE)
	cadata1.rpusvm <- rpusvm(cadata1.data$x, cadata1.data$y, type=type)
	cadata1.fitted <- fitted(cadata1.rpusvm)
	
	cadata2.data <- read.svm.data(cadata1.path, fac=FALSE, sparse=FALSE)
	cadata2.fitted = predict(cadata1.rpusvm, cadata2.data$x)	
	
	checkEqualsNumeric(cadata1.fitted, cadata2.fitted)
}

test.svm.sparse.dense.predict.s4 <- function() {
	
	type <- "nu-regression"
	
	cadata1.path <- file.path(rpudpath, "runit/data/rpusvm/cadata-sample")
	cadata1.data <- read.svm.data(cadata1.path, fac=FALSE)
	cadata1.rpusvm <- rpusvm(cadata1.data$x, cadata1.data$y, type=type)
	cadata1.fitted <- fitted(cadata1.rpusvm)
	
	cadata2.data <- read.svm.data(cadata1.path, fac=FALSE, sparse=FALSE)
	cadata2.fitted = predict(cadata1.rpusvm, cadata2.data$x)	
	
	checkEqualsNumeric(cadata1.fitted, cadata2.fitted)
}

.tearDown <- function() {
    flush.console()
}

