#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##

library(e1071)

filepath <- file.path(path.package(package="rpud"), "runit/data/rpusvm/heart_scale")
hs <- read.svm.data(filepath, fac=TRUE, sparse=FALSE)

x <- hs$x
y <- hs$y
y1 <- as.numeric(y)

scale <- FALSE
cross <- 5

test.svm.dense.cross.s0 <- function() {
	
	type <- "C-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, scale=scale, cross=cross)
	model.rpusvm <- rpusvm(x, y, type=type, scale=scale, cross=cross) 

	checkEqualsNumeric(model.libsvm$tot.accuracy, model.rpusvm$tot.accuracy, tolerance=0.5)
}

test.svm.dense.cross.s1 <- function() {
	
	type <- "nu-classification"

	model.libsvm <- e1071::svm(x, y, type=type, scale=scale, cross=cross)
	model.rpusvm <- rpusvm(x, y, type=type, scale=scale, cross=cross) 
	
	checkEqualsNumeric(model.libsvm$tot.accuracy, model.rpusvm$tot.accuracy, tolerance=0.5)
}

test.svm.dense.cross.s2 <- function() {
	
	type <- "one-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, scale=scale, cross=cross)
	model.rpusvm <- rpusvm(x, y, type=type, scale=scale, cross=cross) 
	
	checkEqualsNumeric(model.libsvm$tot.accuracy, model.rpusvm$tot.accuracy, tolerance=0.5)
}

test.svm.dense.cross.s3 <- function() {
	
	type <- "eps-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, scale=scale, cross=cross)
	model.rpusvm <- rpusvm(x, y1, type=type, scale=scale, cross=cross) 

	checkEqualsNumeric(model.libsvm$tot.MSE, model.rpusvm$tot.MSE, tolerance=0.15)
}

test.svm.dense.cross.s4 <- function() {
	
	type <- "nu-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, scale=scale, cross=cross)
	model.rpusvm <- rpusvm(x, y1, type=type, scale=scale, cross=cross) 
	
	checkEqualsNumeric(model.libsvm$tot.MSE, model.rpusvm$tot.MSE, tolerance=0.15)
}

.tearDown <- function() {
    flush.console()
}

