#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##
library(MASS)


test.kendall.test.survey.self <- function() {
	
	exer <- as.numeric(survey$Exer)
	
	c.test <- cor.test(exer, exer, method="kendall")
	r.test <- rpucor.test(exer, exer, method="kendall", use="pairwise")
	
	checkEqualsNumeric(c.test$estimate,	 r.test$estimate,  tolerance=1.e-06)
	checkEqualsNumeric(c.test$statistic, r.test$statistic, tolerance=1.e-06)
	checkEqualsNumeric(c.test$p.value, 	 r.test$p.value,   tolerance=1.e-06)
}

test.kendall.test.survey.mixed <- function() {
	
	exer <- as.numeric(survey$Exer)
	smoke <- as.numeric(survey$Smoke)
	
	c.test <- cor.test(exer, smoke, method="kendall")
	r.test <- rpucor.test(exer, smoke, method="kendall", use="pairwise")
	
	checkEqualsNumeric(c.test$estimate,	 r.test$estimate,  tolerance=1.e-06)
	checkEqualsNumeric(c.test$statistic, r.test$statistic, tolerance=1.e-06)
	checkEqualsNumeric(c.test$p.value, 	 r.test$p.value,   tolerance=1.e-06)
}

test.kendall.test.survey.matrix <- function() {
	
	exer <- as.numeric(survey$Exer)
	smoke <- as.numeric(survey$Smoke)
	c.t11 <- cor.test(exer,  exer,  method="kendall")
	c.t12 <- cor.test(exer,  smoke, method="kendall")
	
	m <- cbind(exer=survey$Exer, smoke=survey$Smoke) 
	r <- rpucor.test(m, method="kendall", use="pairwise")
	r.tau  <- r$estimate
	r.z    <- r$statistic
	r.pval <- r$p.val
	
	checkEqualsNumeric(c.t11$estimate, r.tau["exer", "exer"],  tolerance=1.e-06)
	checkEqualsNumeric(c.t12$estimate, r.tau["exer", "smoke"], tolerance=1.e-06)
	checkEqualsNumeric(c.t12$estimate, r.tau["smoke", "exer"], tolerance=1.e-06)
	
	checkEqualsNumeric(c.t11$statistic, r.z["exer", "exer"],  tolerance=1.e-06)
	checkEqualsNumeric(c.t12$statistic, r.z["exer", "smoke"], tolerance=1.e-06)
	checkEqualsNumeric(c.t12$statistic, r.z["smoke", "exer"], tolerance=1.e-06)
	
	checkEqualsNumeric(c.t11$p.val, r.pval["exer", "exer"],  tolerance=1.e-06)
	checkEqualsNumeric(c.t12$p.val, r.pval["exer", "smoke"], tolerance=1.e-06)
	checkEqualsNumeric(c.t12$p.val, r.pval["smoke", "exer"], tolerance=1.e-06)
}

test.kendall.test.survey.two.sided <- function() {
	
	exer <- as.numeric(survey$Exer)
	smoke <- as.numeric(survey$Smoke)
	c.pv11 <- cor.test(exer, exer, method="kendall")$p.value
	c.pv12 <- cor.test(exer, smoke, method="kendall")$p.value
	
	m <- cbind(exer=survey$Exer, smoke=survey$Smoke) 
	r.pv <- rpucor.test(m, method="kendall", use="pairwise")$p.value
	
	checkEqualsNumeric(c.pv11, r.pv["exer", "exer"],  tolerance=1.e-06)
	checkEqualsNumeric(c.pv12, r.pv["exer", "smoke"], tolerance=1.e-06)
	checkEqualsNumeric(c.pv12, r.pv["smoke", "exer"], tolerance=1.e-06)
}

test.kendall.test.survey.less <- function() {
	
	alternative <- "less"
	
	exer <- as.numeric(survey$Exer)
	smoke <- as.numeric(survey$Smoke)
	c.pv11 <- cor.test(exer, exer, method="kendall", alternative=alternative)$p.value
	c.pv12 <- cor.test(exer, smoke, method="kendall", alternative=alternative)$p.value
	
	m <- cbind(exer=survey$Exer, smoke=survey$Smoke) 
	r.pv <- rpucor.test(m, method="kendall", use="pairwise", alternative=alternative)$p.value
	
	checkEqualsNumeric(c.pv11, r.pv["exer", "exer"],  tolerance=1.e-06)
	checkEqualsNumeric(c.pv12, r.pv["exer", "smoke"], tolerance=1.e-06)
	checkEqualsNumeric(c.pv12, r.pv["smoke", "exer"], tolerance=1.e-06)
}

test.kendall.test.survey.greater <- function() {
	
	alternative <- "greater"
	
	exer <- as.numeric(survey$Exer)
	smoke <- as.numeric(survey$Smoke)
	c.pv11 <- cor.test(exer, exer, method="kendall", alternative=alternative)$p.value
	c.pv12 <- cor.test(exer, smoke, method="kendall", alternative=alternative)$p.value
	
	m <- cbind(exer=survey$Exer, smoke=survey$Smoke) 
	r.pv <- rpucor.test(m, method="kendall", use="pairwise", alternative=alternative)$p.value
	
	checkEqualsNumeric(c.pv11, r.pv["exer", "exer"],  tolerance=1.e-06)
	checkEqualsNumeric(c.pv12, r.pv["exer", "smoke"], tolerance=1.e-06)
	checkEqualsNumeric(c.pv12, r.pv["smoke", "exer"], tolerance=1.e-06)
}

.tearDown <- function() {
    flush.console()
}

