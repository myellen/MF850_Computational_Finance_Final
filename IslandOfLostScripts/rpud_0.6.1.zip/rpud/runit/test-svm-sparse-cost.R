#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##

library(e1071)
library(SparseM)

filepath <- file.path(path.package(package="rpud"), "runit/data/rpusvm/heart_scale")
hs <- read.svm.data(filepath, fac=TRUE)

x <- hs$x
y <- hs$y
y1 <- as.numeric(y)

scale <- FALSE
cost <- 3.75
nu <- 0.42


test.svm.sparse.cost.s0.c <- function() {
	
	type <- "C-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, cost=cost, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y, type=type, cost=cost, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEquals(pred.libsvm, pred.rpusvm)
}

test.svm.sparse.cost.s0.weights <- function() {
	
	type <- "C-classification"
	class.weights <- c(1.25, 2.35)
	names(class.weights) <- levels(y)
	
	model.libsvm <- e1071::svm(x, y, type=type, class.weights=class.weights, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y, type=type, class.weights=class.weights, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEquals(pred.libsvm, pred.rpusvm)
}

test.svm.sparse.cost.s1.nu <- function() {
	
	type <- "nu-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, nu=nu, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y, type=type, nu=nu, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEquals(pred.libsvm, pred.rpusvm)
}

test.svm.sparse.cost.s2.nu <- function() {
	
	type <- "one-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, nu=nu, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y, type=type, nu=nu, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	error.libsvm <- sum(pred.libsvm != y)
	error.rpusvm <- sum(pred.rpusvm != y)
	checkEquals(error.libsvm, error.rpusvm)
}

test.svm.sparse.cost.s3.c <- function() {
	
	type <- "eps-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, cost=cost, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y1, type=type, cost=cost, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEqualsNumeric(pred.libsvm, pred.rpusvm, tolerance=1.e-03)
}

test.svm.sparse.cost.s4.nu <- function() {
	
	type <- "nu-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, cost=cost, nu=nu, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y1, type=type, cost=cost, nu=nu, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEqualsNumeric(pred.libsvm, pred.rpusvm, tolerance=1.e-03)
}

.tearDown <- function() {
    flush.console()
}

