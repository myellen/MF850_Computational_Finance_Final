#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##


run.rbayes.rhiermnl.all <- function() {
    
    rpudpath <- path.package(package="rpud")
    testsuite.rbayes <- defineTestSuite("rbayes",
            dirs = file.path(rpudpath, "runit"),
            testFileRegexp = "^test-rbayes-rhiermnl.R",
            testFuncRegexp = "^test.rbayes.rhiermnl.+")
    
    testResult <- runTestSuite(testsuite.rbayes)
    printTextProtocol(testResult)
}


run.rbayes.rhiermnl.wrapper <- function(format, R, keep, seed=66) {
    
    data.path <- file.path(path.package(package="rpud"), "runit/data/rbayes")
    load(file.path(data.path, "rhierMnl-n2x6x5-rd.txt.gz"))
    
    Prior <- list(ncomp=4)
    Mcmc <- list(R=R, keep=keep)
    Data <- list(p=p, lgtdata=simlgtdata, Z=Z)
    
    set.seed(seed)
    rpud::rhierMnlRwMixture(
        Data=Data, 
        Prior=Prior, 
        Mcmc=Mcmc,
        output=format
        )
}


test.rbayes.rhiermnl.basic <- function() {
    
    out <- run.rbayes.rhiermnl.wrapper("default", 5000, 5)
    
    #sink("~/Tmp/xxx.log")
    #str(out)
    #List of 6
    #$ llkDraw  : num [1:1000, 1] -15.9 -18.8 -16 -17.6 -17.5 ...
    #$ betaDraw : num [1:1000, 1:15] 1.01 1.01 1.01 1.01 1.01 ...
    #$ DeltaDraw: num [1:1000, 1:6] -8.98057 6.63263 9.44339 1.84764 -0.00332 ...
    #$ probDraw : num [1:1000, 1:4] 0.0276 0.2907 0.3972 0.0513 0.2138 ...
    #$ muDraw   : num [1:1000, 1:12] 1.01 -5.38 -23.93 -6.29 15.35 ...
    #$ rootDraw : num [1:1000, 1:36] 0.632 0.788 0.789 0.703 0.532 ...
    
    filter <- 101:1000
    llkDraw <- out$llkdraw[filter, ]
    llk.median <- median(llkDraw)
    llk.mean <- mean(llkDraw)
    llk.sd <- sd(llkDraw)
#    cat("llkDraw median =", llk.median, "\n")
#    cat("llkDraw mean =", llk.mean, "\n")
#    cat("llkDraw sd =", llk.sd, "\n")
    checkEqualsNumeric(llk.median, -18.0, tolerance=5.e-02)
    checkEqualsNumeric(llk.mean, -18.34, tolerance=5.e-02)
    checkEqualsNumeric(llk.sd, 2.292, tolerance=5.e-02)
    
    betaDraw <- out$betadraw[filter, 1]
    beta.median <- median(betaDraw)
    beta.mean <- mean(betaDraw)
    beta.sd <- sd(betaDraw)
#    cat("betaDraw[1] median =", beta.median, "\n")
#    cat("betaDraw[1] mean =", beta.mean, "\n")
#    cat("betaDraw[1] sd =", beta.sd, "\n")
    checkEqualsNumeric(beta.median, 1.625, tolerance=1.e-01)
    checkEqualsNumeric(beta.mean, 1.61, tolerance=1.e-01)
    checkEqualsNumeric(beta.sd, 1.194, tolerance=1.e-01)
    
    DeltaDraw <- out$Deltadraw[filter, 1]
    Delta.median <- median(DeltaDraw)
    Delta.mean <- mean(DeltaDraw)
    Delta.sd <- sd(DeltaDraw)
#    cat("DeltaDraw[1] median =", Delta.median, "\n")
#    cat("DeltaDraw[1] mean =", Delta.mean, "\n")
#    cat("DeltaDraw[1] sd =", Delta.sd, "\n")
    checkEqualsNumeric(Delta.median, 4.934, tolerance=1.e-01)
    checkEqualsNumeric(Delta.mean, 3.789, tolerance=1.e-01)
    checkEqualsNumeric(Delta.sd, 7.079, tolerance=1.e-01)

    probDraw <- out$probdraw[filter, 1]
    prob.median <- median(probDraw)
    prob.mean <- mean(probDraw)
    prob.sd <- sd(probDraw)
#    cat("probDraw[1] median =", prob.median, "\n")
#    cat("probDraw[1] mean =", prob.mean, "\n")
#    cat("probDraw[1] sd =", prob.sd, "\n")
    checkEqualsNumeric(prob.median, 0.2155, tolerance=2.e-02)
    checkEqualsNumeric(prob.mean, 0.2585, tolerance=2.e-02)
    checkEqualsNumeric(prob.sd, 0.195, tolerance=2.e-02)

    muDraw <- out$mudraw[filter, 1]
    mu.median <- median(muDraw)
    mu.mean <- mean(muDraw)
    mu.sd <- sd(muDraw)
#    cat("muDraw[1] median =", mu.median, "\n")
#    cat("muDraw[1] mean =", mu.mean, "\n")
#    cat("muDraw[1] sd =", mu.sd, "\n")
    checkEqualsNumeric(mu.median, -0.09922, tolerance=2.e-02)
    checkEqualsNumeric(mu.mean, -0.4078, tolerance=2.e-02)
    checkEqualsNumeric(mu.sd, 13.08, tolerance=5.e-02)

    rootDraw <- out$rootdraw[filter, 1]
    root.median <- median(rootDraw)
    root.mean <- mean(rootDraw)
    root.sd <- sd(rootDraw)
#    cat("rootDraw[1] median =", root.median, "\n")
#    cat("rootDraw[1] mean =", root.mean, "\n")
#    cat("rootDraw[1] sd =", root.sd, "\n")
    checkEqualsNumeric(root.median, 0.7971, tolerance=2.e-02)
    checkEqualsNumeric(root.mean, 0.814, tolerance=2.e-02)
    checkEqualsNumeric(root.sd, 0.2802, tolerance=2.e-02)

    #sink()
}
    

test.rbayes.rhiermnl.coda <- function() {
    
    out <- run.rbayes.rhiermnl.wrapper("coda", 50000, 5)
    #sink("~/Tmp/xxx.log")
    #str(out)
    
    beta.res <- gelman.diag(out$beta.mcmc)
    Delta.res <- gelman.diag(out$Delta.mcmc)
    prob.res <- gelman.diag(out$prob.mcmc)
    mu.res <- gelman.diag(out$mu.mcmc)
    root.res <- gelman.diag(out$root.mcmc)
    #cat("beta.mpsrf=", beta.res$mpsrf, "\n\n")
    #cat("Delta.mpsrf=", Delta.res$mpsrf, "\n\n")
    #cat("prob.mpsrf=", prob.res$mpsrf, "\n\n")
    #cat("mu.mpsrf=", mu.res$mpsrf, "\n\n")
    #cat("root.mpsrf=", root.res$mpsrf, "\n\n")
    checkTrue(beta.res$mpsrf < 1.15)
    checkTrue(Delta.res$mpsrf < 1.02)
    checkTrue(prob.res$mpsrf < 1.01)
    checkTrue(mu.res$mpsrf < 1.06)
    checkTrue(root.res$mpsrf < 1.03)
    
    #sink()
}

.tearDown <- function() {
    flush.console()
}

