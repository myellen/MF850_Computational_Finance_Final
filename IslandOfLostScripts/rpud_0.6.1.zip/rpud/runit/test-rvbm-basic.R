#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##


verbose <- TRUE

run.rvbm.all <- function() {
	
	rpudpath <- path.package(package="rpud")
	testsuite.rvbm <- defineTestSuite("rvbm",
			dirs = file.path(rpudpath, "runit"),
			testFileRegexp = "^test-rvbm.+\\.R",
			testFuncRegexp = "^test.rvbm.+")
	
	testResult <- runTestSuite(testsuite.rvbm)
	printTextProtocol(testResult)
}

run.rvbm.basic.test <- function(vbmpKName, rpuvbmKName) {
	
	library(vbmp)

	seed <- 123
	nSamps <- 100
	maxIts <- 6
	InfoLevel <- 1
	
	x1 <- rvbm.sample.train$X
	y1 <- rvbm.sample.train$t.class
	x2 <- rvbm.sample.test$X
	y2 <- rvbm.sample.test$t.class
	
	set.seed(seed)
	model.vbmp <- vbmp( 
		x1, y1, x2, y2,
		theta = rep(1., ncol(rvbm.sample.train$X)), 
		control = list(
				sKernelType=vbmpKName,
				bThetaEstimate=T, 
				bMonitor=T, 
				nSampsIS=nSamps,
				maxIts=maxIts,
				InfoLevel=InfoLevel))
	
	set.seed(seed)
	model.rvbm <- rvbm( 
		x1, y1, x2, y2,
		theta = rep(1., ncol(rvbm.sample.train$X)), 
		control = list(
				sKernelType=rpuvbmKName,
				kDegree = 3,
				kCoef0 = 1,
				bThetaEstimate=T, 
				bMonitor=T, 
				bInitM=T,
				nSampsIS=nSamps,
				maxIts=maxIts,
				InfoLevel=InfoLevel))

	check.rvbm.model(model.rvbm, model.vbmp)
}


run.rvbm.brca <- function() {
	
	rpudpath <- path.package(package="rpud")
	testsuite.rvbm <- defineTestSuite("rvbm",
			dirs = file.path(rpudpath, "runit"),
			testFileRegexp = "^test-rvbm.+\\.R",
			testFuncRegexp = "^test.rvbm.kernel.brca")
	
	testResult <- runTestSuite(testsuite.rvbm)
	printTextProtocol(testResult)
}


test.rvbm.kernel.brca <- function() {
	
	library(vbmp)
	data("BRCA12")
	
	library("Biobase")
	brca.x <- t(exprs(BRCA12))
	brca.y <- BRCA12$Target.class
	
	seed <- 123
	nSamps <- 4
	maxIts <- 6
	InfoLevel <- 1
	
	set.seed(seed)
	model.vbmp <- vbmp(
			brca.x, brca.y, 
			brca.x, brca.y, 
			theta = rep(1.0, ncol(brca.x)),  
			control=list(
					sKernelType="iprod", 
					bThetaEstimate=T, 
					bMonitor=T, 
					nSampsIS=nSamps,
					maxIts=maxIts,
					InfoLevel=InfoLevel))
	
	set.seed(seed)
	model.rvbm <- rvbm(
			brca.x, brca.y, 
			brca.x, brca.y, 
			theta = rep(1.0, ncol(brca.x)),  
			control=list(
					sKernelType="linear", 
					bThetaEstimate=T, 
					bMonitor=T, 
					bInitM=T,
					nSampsIS=nSamps,
					maxIts=maxIts,
					InfoLevel=InfoLevel))
	
	check.rvbm.model(model.rvbm, model.vbmp)
}


check.rvbm.model <- function(model.rvbm, model.vbmp) {
	
	res.rvbm <- summary(model.rvbm)
	
	if (verbose && length(res.rvbm$covParams) < 16) {
		cat("covParams[model.vbmp] =", covParams(model.vbmp), "\n")
		cat("res.rvbm$covParams =", res.rvbm$covParams, "\n")
	}
	checkEqualsNumeric(
			covParams(model.vbmp), 
			res.rvbm$covParams,
			tolerance=0.125
	)
	
	if (verbose) {
		cat("predError[model.vbmp] =", predError(model.vbmp), "\n")
		cat("res.rvbm$predError =", res.rvbm$predError, "\n")
	}
	checkEqualsNumeric(
			predError(model.vbmp), 
			res.rvbm$predError,
			tolerance=0.125
	)
	
	if (verbose) {
		cat("predLik[model.vbmp] =", predLik(model.vbmp), "\n")
		cat("res.rvbm$predLik =", res.rvbm$predLik, "\n")
	}
	checkEqualsNumeric(
			predLik(model.vbmp), 
			res.rvbm$predLik,
			tolerance=0.125
	)
	
	checkEqualsNumeric(
			model.vbmp$Y, 
			model.rvbm$Y,
			tolerance=0.125
	)
	
	checkEqualsNumeric(
			model.vbmp$M, 
			model.rvbm$M,
			tolerance=0.125
	)
	
	checkEqualsNumeric(
			model.vbmp$Ptest, 
			model.rvbm$Ptest,
			tolerance=0.125
	)
	
}


test.rvbm.kernel.linear <- function() {
	run.rvbm.basic.test("iprod", "linear")
}

test.rvbm.kernel.gaussian <- function() {
	run.rvbm.basic.test("gauss", "gaussian")
}

test.rvbm.kernel.laplacian <- function() {
	run.rvbm.basic.test("laplace", "laplacian")
}

#test.vbm.kernel.polynomial <- function() {
#	run.vbm.test("poly3", "polynomial")
#}

.tearDown <- function() {
    flush.console()
}

