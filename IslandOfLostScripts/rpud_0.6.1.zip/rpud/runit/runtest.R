#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##

library(RUnit)
library(rpud)

testsuite.rpud <- defineTestSuite("rpud",
    dirs = file.path(path.package(package="rpud"), "runit"),
    testFileRegexp = "^test.+\\.R",
    testFuncRegexp = "^test.+")

testResult <- runTestSuite(testsuite.rpud)

printTextProtocol(testResult)

