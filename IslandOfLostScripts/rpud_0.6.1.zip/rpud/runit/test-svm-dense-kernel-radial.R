#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##

library(e1071)

filepath <- file.path(path.package(package="rpud"), "runit/data/rpusvm/heart_scale")
hs <- read.svm.data(filepath, fac=TRUE, sparse=FALSE)

x <- hs$x
y <- hs$y
y1 <- as.numeric(y)

scale <- FALSE
kernel <- "radial"

gamma <- 0.25

test.svm.dense.kernel.radial.s0 <- function() {
	
	type <- "C-classification"
	model.libsvm <- e1071::svm(x, y, type=type, kernel=kernel, gamma=gamma, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y, type=type, kernel=kernel, gamma=gamma, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEquals(pred.libsvm, pred.rpusvm)
}

test.svm.dense.kernel.radial.s1 <- function() {
	
	type <- "nu-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, kernel=kernel, gamma=gamma, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y, type=type, kernel=kernel, gamma=gamma, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEquals(pred.libsvm, pred.rpusvm)
}

test.svm.dense.kernel.radial.s2 <- function() {
	
	type <- "one-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, kernel=kernel, gamma=gamma, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y, type=type, kernel=kernel, gamma=gamma, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
    error <- sum(pred.libsvm != pred.rpusvm)
	checkEqualsNumeric(0, error, tolerance=5)
}

test.svm.dense.kernel.radial.s3 <- function() {
	
	type <- "eps-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, kernel=kernel, gamma=gamma, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y1, type=type, kernel=kernel, gamma=gamma, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEqualsNumeric(pred.libsvm, pred.rpusvm, tolerance=1.e-03)
}

test.svm.dense.kernel.radial.s4 <- function() {
	
	type <- "nu-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, kernel=kernel, gamma=gamma, scale=scale)
	pred.libsvm <- fitted(model.libsvm)
	
	model.rpusvm <- rpusvm(x, y1, type=type, kernel=kernel, gamma=gamma, scale=scale) 
	pred.rpusvm <- fitted(model.rpusvm)
	
	checkEqualsNumeric(pred.libsvm, pred.rpusvm, tolerance=1.e-03)
}

.tearDown <- function() {
    flush.console()
}


