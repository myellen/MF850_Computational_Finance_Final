#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##


gen.data <- function(dim=16, num=75, seed=17) {
    set.seed(seed)
    matrix(rnorm(dim * num), nrow=num)
}

test.hclust.default <- function() {
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d)
    hc2 <- rpuHclust(d)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

test.hclust.ward <- function() {
    method <- "ward"
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d, method)
    hc2 <- rpuHclust(d, method)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

test.hclust.single <- function() {
    method <- "single"
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d, method)
    hc2 <- rpuHclust(d, method)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

test.hclust.complete <- function() {
    method <- "complete"
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d, method)
    hc2 <- rpuHclust(d, method)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

test.hclust.average <- function() {
    method <- "average"
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d, method)
    hc2 <- rpuHclust(d, method)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

test.hclust.mcquitty <- function() {
    method <- "mcquitty"
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d, method)
    hc2 <- rpuHclust(d, method)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

test.hclust.median <- function() {
    method <- "median"
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d, method)
    hc2 <- rpuHclust(d, method)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

test.hclust.centroid <- function() {
    method <- "centroid"
    m <- gen.data()
    d <- dist(m)
    hc1 <- hclust(d, method)
    hc2 <- rpuHclust(d, method)
    checkEquals(hc1$merge, hc2$merge)
    checkEquals(hc1$order, hc2$order)
    checkEqualsNumeric(hc1$height, hc2$height, tolerance=1.e-05)
}

.tearDown <- function() {
    flush.console()
}

