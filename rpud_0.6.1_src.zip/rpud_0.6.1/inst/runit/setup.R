#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##

install.packages(c(
	"bayesm",
	"coda",
	"e1071",
	"RUnit",
	"SparseM"
	))

source("http://bioconductor.org/biocLite.R")
biocLite(c(
	"Biobase", 
	"vbmp"
	))



