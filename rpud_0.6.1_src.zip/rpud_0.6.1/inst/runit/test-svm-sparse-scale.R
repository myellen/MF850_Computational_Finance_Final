#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##

rpudpath <- path.package(package="rpud")

scale <- c(0, 1, -1, 1)

test.svm.sparse.scale.data.x <- function() {
	
	iris1.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris1.data <- read.svm.data(iris1.path, fac=TRUE)
	iris1.scaled <- rpuScale(iris1.data$x, iris1.data$y, scale=scale)
	
	iris2.path <- file.path(rpudpath, "runit/data/rpusvm/iris.scale")
	iris2.data <- read.svm.data(iris2.path, fac=TRUE)
	
	x1 <- iris1.scaled$x
	x2 <- iris2.data$x
	
	checkEquals(dim(x1), dim(x2))
	
	checkEqualsNumeric(x1@ra, x2@ra, tolerance=1.e-06)
	checkEqualsNumeric(x1@ja, x2@ja, tolerance=1.e-06)
	checkEqualsNumeric(x1@ia, x2@ia, tolerance=1.e-06)
}

test.svm.sparse.scale.data.xy <- function() {
	
	cadata1.path <- file.path(rpudpath, "runit/data/rpusvm/cadata-sample")
	cadata1.data <- read.svm.data(cadata1.path, fac=FALSE)
	cadata1.scaled <- rpuScale(cadata1.data$x, cadata1.data$y, scale=scale)
	
	cadata2.path <- file.path(rpudpath, "runit/data/rpusvm/cadata-sample.scale")
	cadata2.data <- read.svm.data(cadata2.path, fac=FALSE)
	
	x1 <- cadata1.scaled$x
	x2 <- cadata2.data$x
	
	checkEquals(dim(x1), dim(x2))
	
	checkEqualsNumeric(x1@ra, x2@ra, tolerance=1.e-06)
	checkEqualsNumeric(x1@ja, x2@ja, tolerance=1.e-06)
	checkEqualsNumeric(x1@ia, x2@ia, tolerance=1.e-06)
	
	y1 <- cadata1.scaled$y
	y2 <- cadata2.data$y
	checkEqualsNumeric(y1, y2, tolerance=1.e-06)
}

test.svm.sparse.scale.s0 <- function() {
	
	type <- "C-classification"
	
	iris1.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris1.data <- read.svm.data(iris1.path, fac=TRUE)
	iris1.rpusvm <- rpusvm(iris1.data$x, iris1.data$y, type=type, scale=scale)
	iris1.fitted <- fitted(iris1.rpusvm)
	
	iris1.scaled <- rpuScale(iris1.data$x, iris1.data$y, scale=scale)
	iris2.rpusvm <- rpusvm(iris1.scaled$x, iris1.scaled$y, type=type, scale=FALSE)
	iris2.fitted <- fitted(iris2.rpusvm)
	
	checkEquals(iris1.fitted, iris2.fitted)
}

test.svm.sparse.scale.s1 <- function() {
	
	type <- "nu-classification"
	
	iris1.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris1.data <- read.svm.data(iris1.path, fac=TRUE)
	iris1.rpusvm <- rpusvm(iris1.data$x, iris1.data$y, type=type, scale=scale)
	iris1.fitted <- fitted(iris1.rpusvm)
	
	iris1.scaled <- rpuScale(iris1.data$x, iris1.data$y, scale=scale)
	iris2.rpusvm <- rpusvm(iris1.scaled$x, iris1.scaled$y, type=type, scale=FALSE)
	iris2.fitted <- fitted(iris2.rpusvm)
	
	checkEquals(iris1.fitted, iris2.fitted)
}

test.svm.sparse.scale.s2 <- function() {
	
	type <- "one-classification"
	
	iris1.path <- file.path(rpudpath, "runit/data/rpusvm/iris")
	iris1.data <- read.svm.data(iris1.path, fac=TRUE)
	iris1.rpusvm <- rpusvm(iris1.data$x, iris1.data$y, type=type, scale=scale)
	iris1.fitted <- fitted(iris1.rpusvm)
	
	iris1.scaled <- rpuScale(iris1.data$x, iris1.data$y, scale=scale)
	iris2.rpusvm <- rpusvm(iris1.scaled$x, iris1.scaled$y, type=type, scale=FALSE)
	iris2.fitted <- fitted(iris2.rpusvm)
	
	checkEquals(iris1.fitted, iris2.fitted)
}

test.svm.sparse.scale.s3 <- function() {
	
	type <- "eps-regression"
	
	cadata1.path <- file.path(rpudpath, "runit/data/rpusvm/cadata-sample")
	cadata1.data <- read.svm.data(cadata1.path, fac=FALSE)
	cadata1.rpusvm <- rpusvm(cadata1.data$x, cadata1.data$y, type=type, scale=scale)
	cadata1.fitted <- fitted(cadata1.rpusvm)
	
	cadata1.scaled <- rpuScale(cadata1.data$x, cadata1.data$y, scale=scale)
	cadata2.rpusvm <- rpusvm(cadata1.scaled$x, cadata1.scaled$y, type=type, scale=FALSE)
	cadata2.fitted <- fitted(cadata2.rpusvm)
	
	cadata1.yrange <- cadata1.scaled$y.bound[2]-cadata1.scaled$y.bound[1]
	cadata1.yscale <- cadata1.scaled$y.scale[2]-cadata1.scaled$y.scale[1]
	
	cadata2.fitted.scaled <-
			(cadata2.fitted - cadata1.scaled$y.scale[1])*cadata1.yrange/cadata1.yscale +
			cadata1.scaled$y.bound[1]
	checkEqualsNumeric(cadata1.fitted, cadata2.fitted.scaled, tolerance=50)
}

test.svm.sparse.scale.s4 <- function() {
	
	type <- "nu-regression"
	
	cadata1.path <- file.path(rpudpath, "runit/data/rpusvm/cadata-sample")
	cadata1.data <- read.svm.data(cadata1.path, fac=FALSE)
	cadata1.rpusvm <- rpusvm(cadata1.data$x, cadata1.data$y, type=type, scale=scale)
	cadata1.fitted <- fitted(cadata1.rpusvm)
	
	cadata1.scaled <- rpuScale(cadata1.data$x, cadata1.data$y, scale=scale)
	cadata2.rpusvm <- rpusvm(cadata1.scaled$x, cadata1.scaled$y, type=type, scale=FALSE)
	cadata2.fitted <- fitted(cadata2.rpusvm)
	
	cadata1.yrange <- cadata1.scaled$y.bound[2]-cadata1.scaled$y.bound[1]
	cadata1.yscale <- cadata1.scaled$y.scale[2]-cadata1.scaled$y.scale[1]
	
	cadata2.fitted.scaled <-
			(cadata2.fitted - cadata1.scaled$y.scale[1])*cadata1.yrange/cadata1.yscale +
			cadata1.scaled$y.bound[1]
	checkEqualsNumeric(cadata1.fitted, cadata2.fitted.scaled, tolerance=50)
}

.tearDown <- function() {
    flush.console()
}

