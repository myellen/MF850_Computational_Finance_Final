#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##

library(e1071)
library(SparseM)

filepath <- file.path(path.package(package="rpud"), "runit/data/rpusvm/heart_scale")
hs <- read.svm.data(filepath, fac=TRUE)

x <- hs$x
y <- hs$y
y1 <- as.numeric(y)

scale <- FALSE
probability <- TRUE

test.svm.sparse.probability.s0 <- function() {
	
	type <- "C-classification"
	
	model.libsvm <- e1071::svm(x, y, type=type, scale=scale, probability=probability)
	pred.libsvm <- predict(model.libsvm, x, probability=probability)
	
	model.rpusvm <- rpusvm(x, y, type=type, scale=scale, probability=probability) 
	pred.rpusvm <- predict(model.rpusvm, x, probability=probability)
	
	error.libsvm <- sum(pred.libsvm != y)
	error.rpusvm <- sum(pred.rpusvm != y)
	checkEqualsNumeric(error.libsvm, error.rpusvm, tolerance=1)
}

test.svm.sparse.probability.s1 <- function() {
	
	type <- "nu-classification"

	model.libsvm <- e1071::svm(x, y, type=type, scale=scale, probability=probability)
	pred.libsvm <- predict(model.libsvm, x, probability=probability)
	
	model.rpusvm <- rpusvm(x, y, type=type, scale=scale, probability=probability) 
	pred.rpusvm <- predict(model.rpusvm, x, probability=probability)
	
	error.libsvm <- sum(pred.libsvm != y)
	error.rpusvm <- sum(pred.rpusvm != y)
	checkEqualsNumeric(error.libsvm, error.rpusvm, tolerance=1)
}

test.svm.sparse.probability.s3 <- function() {
	
	type <- "eps-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, scale=scale, probability=probability)
	pred.libsvm <- predict(model.libsvm, x, probability=probability)
	
	model.rpusvm <- rpusvm(x, y1, type=type, scale=scale, probability=probability) 
	pred.rpusvm <- predict(model.rpusvm, x, probability=probability)
	
	checkEqualsNumeric(pred.libsvm, pred.rpusvm, tolerance=1.e-03)
}

test.svm.sparse.probability.s4 <- function() {
	
	type <- "nu-regression"
	
	model.libsvm <- e1071::svm(x, y1, type=type, scale=scale, probability=probability)
	pred.libsvm <- predict(model.libsvm, x, probability=probability)
	
	model.rpusvm <- rpusvm(x, y1, type=type, scale=scale, probability=probability) 
	pred.rpusvm <- predict(model.rpusvm, x, probability=probability)
	
	checkEqualsNumeric(pred.libsvm, pred.rpusvm, tolerance=1.e-03)
}

.tearDown <- function() {
    flush.console()
}

