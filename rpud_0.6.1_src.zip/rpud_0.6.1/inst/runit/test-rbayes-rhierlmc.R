#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##

run.rbayes.all <- function() {
    
    rpudpath <- path.package(package="rpud")
    testsuite.rbayes <- defineTestSuite("rbayes",
            dirs = file.path(rpudpath, "runit"),
            testFileRegexp = "^test-rbayes.+\\.R",
            testFuncRegexp = "^test.rbayes.+")
    
    testResult <- runTestSuite(testsuite.rbayes)
    printTextProtocol(testResult)
}


read.rbayes.data <- function(name) {
    
    X <- read.table(
            file.path(path.package(package="rpud"), "runit/data/rbayes", name),
            header=FALSE)
    as.matrix(X)
}


# rmultireg
test.rbayes.rmultireg.basic <- function() {
    
    X <- read.rbayes.data("rmultireg-n100x2-x.txt")
    Y <- read.rbayes.data("rmultireg-n100x2-y.txt")
    
    # parameters
    n <- nrow(X)
    k <- ncol(X)
    m <- ncol(Y)
    
    # priors
    Bbar <- matrix(c(1, 0, -1, 1),nrow=k,ncol=m)	# prior conjugate (normal) mean of B
    A <- matrix(c(0.1, -0.05, -0.05, 0.1),nrow=k)	# prior conjugate (normal) precision of B
    nu <- 3; V <- nu*diag(m)						# prior Wishart params of Sigma
    
    # true data params
    B <- matrix(c(1,2,-1,3),ncol=m)
    Sigma <- matrix(c(1,.5,.5,1),ncol=m)
    
    #################################################
    # rpud
    set.seed(66)
    out <- rpud::rmultireg(Y, X, Bbar, A, nu, V, rep=4000)
    
    res <- apply(out$betadraw,2,quantile,probs=c(.01,.05,.5,.95,.99))
    ref <- read.rbayes.data("rmultireg-n100x2-beta.txt")
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
    res <- apply(out$Sigmadraw,2,quantile,probs=c(.01,.05,.5,.95,.99))
    ref <- read.rbayes.data("rmultireg-n100x2-sigma.txt")
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
}

# rhierlm
test.rbayes.rhierlmc.basic <- function() {
    
    data <- read.rbayes.data("rhierlm-n100-data.txt")
    Z    <- read.rbayes.data("rhierlm-n100-z.txt")
    
    regkey <- unique(data[,1])
    colvar <- 3:ncol(data)
    
    regdata <- NULL
    for (reg in regkey) {
        
        filter <- (data[,1]==reg)
        y <- data[filter,2]
        X <- data[filter,colvar]
        
        regdata[[reg]] <- list(y=y,X=X)
    }
    nvar <- ncol(regdata[[1]]$X)
    
    # parameters
    R <- 4000
    keep <- 1
    
    Data <- list(regdata=regdata, Z=Z)
    Mcmc <- list(R=R, keep=keep)
    
    #################################################
    # rpud
    set.seed(66)
    out <- rpud::rhierLinearModel(Data=Data, Mcmc=Mcmc)
    
    burnin <- trunc(0.1*R)
    X=out$Deltadraw[(burnin+1):R,,drop=FALSE]
    res <- matrix(apply(X, 2, median), ncol=nvar)
    ref <- t(matrix(c(
                1.0649, -0.7922,  2.194,
                0.2337,  1.0632, -0.153    
                ), nrow=nvar))
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)

    X=out$Vbetadraw[(burnin+1):R,,drop=FALSE]
    res <- matrix(apply(X, 2, median), ncol=nvar)
    ref <- t(matrix(c(
                 0.91802, 0.2808, -0.04738,
                 0.28076, 1.6981,  0.79239,
                -0.04738, 0.7924,  1.02577    
                ), nrow=nvar))
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
    X=out$taudraw[(burnin+1):R,,drop=FALSE]
    res <- quantile(apply(X, 2, median), probs=c(.01,.05,.5,.95,.99))
    ref <- c(0.08997, 0.09601, 0.15833, 0.22502, 0.23760)    
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
    X=out$betadraw[(burnin+1):R,,drop=FALSE]
    res <- quantile(apply(X, 2, median), probs=c(.01,.05,.5,.95,.99))
    ref <- c(-3.596, -2.441, 1.003, 3.212, 4.106)    
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
}
    
# rhierlm-cheese
read.cheese.data <- function() {

    library(bayesm)
    data(cheese)
    
    ##
    ## example of processing for use with rhierLinearModel
    ##
    retailer <- levels(cheese$RETAILER)
    nreg <- length(retailer)
    
    regdata <- NULL
    for (reg in 1:nreg) {
        
        filter <- (cheese$RETAILER==retailer[reg])
        y <- log(cheese$VOLUME[filter])
        X <- cbind(1, cheese$DISP[filter], log(cheese$PRICE[filter]))
        
        regdata[[reg]] <- list(y=y,X=X)
    }
    
    regdata
}
    
test.rbayes.rhierlmc.bayesm <- function() {
    
    regdata <- read.cheese.data()
    nvar <- ncol(regdata[[1]]$X)
    
    R <- 4000
    keep <- 1
    
    Data <- list(regdata=regdata)
    Mcmc <- list(R=R,keep=keep)
    
    set.seed(66)
    out <- rpud::rhierLinearModel(Data=Data,Mcmc=Mcmc,output="bayesm")
    
    burnin <- trunc(0.1*R)
    X=out$Deltadraw[(burnin+1):R,,drop=FALSE]
    res <- matrix(apply(X, 2, median), ncol=nvar)
    ref <- t(matrix(c(10.29, 0.9866, -2.142), nrow=nvar))
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
    X=out$Vbetadraw[(burnin+1):R,,drop=FALSE]
    res <- matrix(apply(X, 2, median), ncol=nvar)
    ref <- t(matrix(c(
                 1.2962,  0.1161, -0.6855,
                 0.1161,  0.5757, -0.0766,
                -0.6855, -0.0766,  0.7263
                ), nrow=nvar))
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
    X=out$taudraw[(burnin+1):R,,drop=FALSE]
    res <- quantile(apply(X, 2, median), probs=c(.01,.05,.5,.95,.99))
    ref <- c(0.009056, 0.012456, 0.041573, 0.210812, 0.314209)    
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
    X=out$betadraw[,,(burnin+1):R,drop=FALSE]
    res <- quantile(apply(X[,1,], 1, median), probs=c(.01,.05,.5,.95,.99))
    ref <- c(7.680, 8.499, 10.303, 12.082, 12.683)    
    checkEqualsNumeric(res, ref, tolerance=2.5e-02)
    
}

test.rbayes.rhierlmc.coda <- function() {
    
    regdata <- read.cheese.data()
    nvar <- ncol(regdata[[1]]$X)
    
    R <- 4000
    keep <- 1
    
    Data <- list(regdata=regdata)
    Mcmc <- list(R=R,keep=keep)
    
    set.seed(66)
    out <- rpud::rhierLinearModel(Data=Data,Mcmc=Mcmc,output="coda")
    
    Vbeta.res <- gelman.diag(out$Vbeta.mcmc)
    checkTrue(all(Vbeta.res$psrf[,1] < 1.05))
    
    Delta.res <- gelman.diag(out$Delta.mcmc)
    checkTrue(all(Delta.res$psrf[,1] < 1.05))
    
    tau.res <- gelman.diag(out$tau.mcmc)
    checkTrue(all(tau.res$psrf[,1] < 1.05))
    
    beta.res <- gelman.diag(out$beta.mcmc)
    checkTrue(all(beta.res$psrf[,1] < 1.05))
}
    
.tearDown <- function() {
    flush.console()
}

