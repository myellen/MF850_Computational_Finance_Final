#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##


candidates <- 1:16

gen.data <- function(dim, num=120) {
    matrix(sample(candidates, dim*num, replace=TRUE), nrow=num)
}

gen.cases1 <- function(hasNA=FALSE) {
    m <- gen.data(15)
    if (hasNA) {
        m[3,7] <- NA
        m[7:11,9] <- NA
    }
    m
}

gen.cases2 <- function(hasNA=FALSE) {
    m <- gen.data(21)
    if (hasNA) {
        m[12,5] <- NA
        m[14,9:12] <- NA
    }
    m
}

test.kendall.cor.tide.pair.basic <- function() {
    set.seed(17)
    m1 <- gen.cases1()
    m2 <- gen.cases2()
    cor1 <- cor(m1, m2, method="kendall")
    cor2 <- rpucor(m1, m2, method="kendall")
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.pair.everything <- function() {
    set.seed(17)
    m1 <- gen.cases1(TRUE)
    m2 <- gen.cases2(TRUE)
    cor1 <- cor(m1, m2, method="kendall")
    cor2 <- rpucor(m1, m2, method="kendall")
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.pair.all.obs <- function() {
    use <- "all.obs";
    set.seed(17)
    m1 <- gen.cases1(TRUE)
    m2 <- gen.cases2(TRUE)
    checkException(rpucor(m1, m2, method="kendall", use=use))
}

test.kendall.cor.tide.pair.complete.obs <- function() {
    use <- "complete.obs";
    set.seed(17)
    m1 <- gen.cases1(TRUE)
    m2 <- gen.cases2(TRUE)
    cor1 <- cor(m1, m2, method="kendall", use=use)
    cor2 <- rpucor(m1, m2, method="kendall", use=use)
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.pair.na.or.complete <- function() {
    use <- "na.or.complete";
    set.seed(17)
    m1 <- gen.cases1(TRUE)
    m2 <- gen.cases2(TRUE)
    cor1 <- cor(m1, m2, method="kendall", use=use)
    cor2 <- rpucor(m1, m2, method="kendall", use=use)
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.pair.pairwise.complete.obs <- function() {
    use <- "pairwise.complete.obs";
    set.seed(17)
    m1 <- gen.cases1(TRUE)
    m2 <- gen.cases2(TRUE)
    cor1 <- cor(m1, m2, method="kendall", use=use)
    cor2 <- rpucor(m1, m2, method="kendall", use=use)
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

.tearDown <- function() {
    flush.console()
}

