#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau
##

test.path <- file.path(path.package(package="rpud"), "runit/data/rpudl")


#####################################################################


test.rpudl.mnist <- function(x) {

    ds <- rpudlCreateDataSource(
            data.format="lmdb",
            data.dir=file.path(test.path, "mnist"),
            train.data="mnist-40-12-data_train_lmdb",
            test.data="mnist-40-12-data_test_lmdb",
            data.shape=c(28, 28)
    )
    
    model <- rpudl(
            file.path(test.path, "mnist/caffe_mnist_small_train.prototxt"),
            data.source=ds
    )
    model <- rpudlTrain(model, batch=2, iter=60)
    
    obj <- rpudlGetTestingDataSamples(ds, c(1, 2))
    res <- predict(model, obj$x)
    
    A <- t(matrix(c(
             0.03508639, 0.03508500,
             0.25975531, 0.25975308,
            -0.00052046,-0.00052268,
             0.15579230, 0.15578921,
            -0.02770768,-0.02770917,
            -0.19410081,-0.19410262,
             0.25611886, 0.25611705,
            -0.13532616,-0.13532792,
            -0.35533500,-0.35533670,
             0.00723612, 0.00723420
            ), nrow=2))
    checkEqualsNumeric(
            attr(res, "decision.values"),
            A, tolerance=1.e-07
    )
}


test.rpudl.cifar10 <- function(x) {
    
    ds <- rpudlCreateDataSource(
            data.format="lmdb",
            data.dir=file.path(test.path, "cifar10"),
            train.data="samples_train_lmdb",
            test.data="samples_test_lmdb",
            data.shape=c(32, 32),
            data.channels=3
    )
    #rpudl.data.mean(ds, filename="samples.mean")
    
    model <- rpudl(
            file.path(test.path, "cifar10/cifar10_small_train.prototxt"),
            data.source=ds
    )
    model <- rpudlTrain(model, batch=2, iter=4)
    
    obj <- rpudlGetTestingDataSamples(ds, c(1, 2))
    res <- predict(model, obj$x)
    
    print(attr(res, "decision.values"))
    
    A <- t(matrix(c(
            -0.0017082,-0.0017076,
             0.0020914, 0.0020920,
            -0.0017082,-0.0017076,
            -0.0017082,-0.0017076,
             0.0010010, 0.0010017,
            -0.0017082,-0.0017076,
             0.0027290, 0.0027296,
            -0.0017082,-0.0017076,
            -0.0017082,-0.0017076,
             0.0054382, 0.0054389
            ), nrow=2))
    checkEqualsNumeric(
            attr(res, "decision.values"),
            A, tolerance=1.5e-05
    )
}


