#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##

gen.data <- function(dim=16, num=64, seed=17) {
    set.seed(seed)
    matrix(rnorm(dim * num), nrow=num)
}

test.dist.euclidean <- function() {
    type <- "euclidean"
    m <- gen.data()
    d1 <- dist(m, type)
    d2 <- rpuDist(m, type)
    checkEqualsNumeric(d1, d2, tolerance=1.e-06)
}

test.dist.maximum <- function() {
    type <- "maximum"
    m <- gen.data()
    d1 <- dist(m, type)
    d2 <- rpuDist(m, type)
    checkEqualsNumeric(d1, d2, tolerance=1.e-06)
}

test.dist.manhattan <- function() {
    type <- "manhattan"
    m <- gen.data()
    d1 <- dist(m, type)
    d2 <- rpuDist(m, type)
    checkEqualsNumeric(d1, d2, tolerance=1.e-06)
}

test.dist.canberra <- function() {
    type <- "canberra"
    m <- gen.data()
    d1 <- dist(m, type)
    d2 <- rpuDist(m, type)
    checkEqualsNumeric(d1, d2, tolerance=1.e-03)
}

test.dist.binary <- function() {
    type <- "binary"
    m <- gen.data()
    d1 <- dist(m, type)
    d2 <- rpuDist(m, type)
    checkEqualsNumeric(d1, d2, tolerance=1.e-06)
}

test.dist.minkowski <- function() {
    type <- "minkowski"
    m <- gen.data()
    d1 <- dist(m, type)
    d2 <- rpuDist(m, type)
    checkEqualsNumeric(d1, d2, tolerance=1.e-06)
}

.tearDown <- function() {
    flush.console()
}


