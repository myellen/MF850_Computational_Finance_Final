#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##


candidates <- 1:16

gen.data <- function(dim, num=120) {
	matrix(sample(candidates, dim*num, replace=TRUE), nrow=num)
}

gen.cases1 <- function(hasNA=FALSE) {
    m <- gen.data(15)
    if (hasNA) {
        m[3,7] <- NA
        m[7:11,9] <- NA
    }
    m
}

test.kendall.cor.tide.symm.basic <- function() {
    set.seed(17)
    m <- gen.cases1()
    cor1 <- cor(m, method="kendall")
    cor2 <- rpucor(m, method="kendall")
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.symm.everything <- function() {
    set.seed(17)
    m <- gen.cases1(TRUE)
    cor1 <- cor(m, method="kendall")
    cor2 <- rpucor(m, method="kendall")
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.symm.all.obs <- function() {
    use <- "all.obs";
    set.seed(17)
    m <- gen.cases1(TRUE)
    checkException(rpucor(m, method="kendall", use=use))
}

test.kendall.cor.tide.symm.complete.obs <- function() {
    use <- "complete.obs";
    set.seed(17)
    m <- gen.cases1(TRUE)
    cor1 <- cor(m, method="kendall", use=use)
    cor2 <- rpucor(m, method="kendall", use=use)
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.symm.na.or.complete <- function() {
    use <- "na.or.complete";
    set.seed(17)
    m <- gen.cases1(TRUE)
    cor1 <- cor(m, method="kendall", use=use)
    cor2 <- rpucor(m, method="kendall", use=use)
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

test.kendall.cor.tide.symm.pairwise.complete.obs <- function() {
    use <- "pairwise.complete.obs";
    set.seed(17)
    m <- gen.cases1(TRUE)
    cor1 <- cor(m, method="kendall", use=use)
    cor2 <- rpucor(m, method="kendall", use=use)
    checkEqualsNumeric(cor1, cor2, tolerance=1.e-06)
}

.tearDown <- function() {
    flush.console()
}

