#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2015 Chi Yau
##


candidates <- 1:16

gen.data <- function(dim, num=120) {
    matrix(sample(candidates, dim*num, replace=TRUE), nrow=num)
}

gen.cases1 <- function(hasNA=FALSE) {
    m <- gen.data(15)
    if (hasNA) {
        m[3,7] <- NA
        m[7:11,9] <- NA
    }
    m
}

gen.cases2 <- function(hasNA=FALSE) {
    m <- gen.data(21)
    if (hasNA) {
        m[12:17,5] <- NA
        m[14,9:12] <- NA
    }
    m
}

N1 <- 9
N2 <- 5

test.kendall.test.tide.pair.pairwise.two.sided <- function() {
    set.seed(17)
    m1 <- gen.cases1()
    m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N1], m2[,N2], method="kendall")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="pairwise")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.pair.pairwise.less <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N1], m2[,N2], method="kendall", alternative="less")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="pairwise", alternative="less")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.pair.pairwise.greater <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N1], m2[,N2], method="kendall", alternative="greater")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="pairwise", alternative="greater")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.pair.complete.obs.two.sided <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N1], m2[,N2], method="kendall")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="complete.obs")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.pair.complete.obs.less <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N1], m2[,N2], method="kendall", alternative="less")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="complete.obs", alternative="less")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

test.kendall.test.tide.pair.complete.obs.greater <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N1], m2[,N2], method="kendall", alternative="greater")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="complete.obs", alternative="greater")$p.value
	checkEqualsNumeric(pv1, pv2[N1, N2], tolerance=1.e-06)
}

N3 <- 12
N4 <- 19

test.kendall.test.tide.pair.everything.two.sided <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N3], m2[,N4], method="kendall")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="everything")$p.value
	checkEqualsNumeric(pv1, pv2[N3, N4], tolerance=1.e-06)
}

test.kendall.test.tide.pair.everything.less <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N3], m2[,N4], method="kendall", alternative="less")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="everything", alternative="less")$p.value
	checkEqualsNumeric(pv1, pv2[N3, N4], tolerance=1.e-06)
}

test.kendall.test.tide.pair.everything.greater <- function() {
	set.seed(17)
	m1 <- gen.cases1()
	m2 <- gen.cases2()
	pv1 <- cor.test(m1[,N3], m2[,N4], method="kendall", alternative="greater")$p.value
	pv2 <- rpucor.test(m1, m2, method="kendall", use="everything", alternative="greater")$p.value
	checkEqualsNumeric(pv1, pv2[N3, N4], tolerance=1.e-06)
}

.tearDown <- function() {
    flush.console()
}

