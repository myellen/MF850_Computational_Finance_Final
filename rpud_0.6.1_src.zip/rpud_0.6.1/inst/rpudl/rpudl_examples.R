################################################
# pre-requisites
#
library(rpud)

install.packages("ggplot2")

rpudl.path <- file.path(path.package(package="rpud"), "rpudl")

################################################
# Ex 1: MNIST
#

# download data
ds <- rpudlCreateDataSource(
		data.format="mnist",
		data.dir="data/mnist"
)

# create model
model <- rpudl(
		file.path(rpudl.path, "mnist_mpl_lenet.prototxt"),
		data.source=ds
)	

# training
system.time(model <- rpudlTrain(model, batch=100, iter=1000))

# plot cost log
library(ggplot2)
costs <- model$cost.log
qplot(1:length(costs), costs, geom="smooth")

# plot monochrome convolutional weight params
weights <- rpudlGetLayerWeights(model, "conv1"); str(weights)
rpudlPlotLayerWeights(weights)

# extract test sample and predict
num <- 12
obj <- rpudlGetTestingDataSamples(ds, c(1, num))
res <- predict(model, obj$x)
sum((obj$y) == res)


################################################
# Ex 2: Pre-training with previous MNIST data source
#
model <- rpudl(
		file.path(rpudl.path, "pretrain_gaussian_autoencoder.prototxt"),
		data.source=ds
)

system.time(model <- rpudlPretrain(model, batch=100, iter=1000))

# show weights
weights <- rpudlGetLayerWeights(model, "ip1")
str(weights)
range(weights)

rpudlPlotLayerWeights(weights)


################################################
# Ex 3: CIFAR10
#

# download data
ds <- rpudlCreateDataSource(
		data.format="cifar10",
		data.dir="data/cifar"
)

# convert to LMDB (optional)
rpudlWriteLMDB(ds, prefix="cifar10-data")

# create LMDB data source (optional)
ds <- rpudlCreateDataSource(
		data.format="lmdb",
		data.dir="data/cifar/cifar-10-batches-bin",
		train.data="cifar10-data_train_lmdb",
		test.data="cifar10-data_test_lmdb",
		data.shape=c(32, 32),
		data.channels=3
)

# training data mean
rpudlFindTrainingDataMean(ds, filename="cifar10-data.mean")

# create model
model <- rpudl(
		file.path(rpudl.path, "cifar10_quick_train.prototxt"),
		data.source=ds
)

# initial training
system.time(model <- rpudlTrain(model, batch=100, iter=4000))

# further training with manual learning rate override
system.time(model <- rpudlTrain(model, batch=100, iter=1000, learning.rate=0.0001))

# plot cost log
library(ggplot2)
costs <- model$cost.log
qplot(1:length(costs), costs, geom="smooth")

# plot RGB color convolutional weight params
weights <- rpudlGetLayerWeights(model, "conv1"); str(weights)
rpudlPlotLayerWeights(weights)

# extract test sample and predict
num <- 12
obj <- rpudlGetTestingDataSamples(ds, c(1, num))
res <- predict(model, obj$x)
sum((obj$y) == res)

