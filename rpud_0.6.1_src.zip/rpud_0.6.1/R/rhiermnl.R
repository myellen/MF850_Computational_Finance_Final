#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  Based on bayesm (ver 2.2-5)
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##


rhierMNLLevel <- 0x36

#------------------------------------------------------------------------------
# rhierMnlRwMixture
#
# Purpose: 
#   run hierarchical multinomial logit model with mixture of normals 
#   via random walk (RW) metropolis-hastings
#   cov(RW inc) = (hess_i + Vbeta^-1)^-1
#   uses normal approximation to pooled likelihood
#
# Arguments:
#   Data contains a list of (p,lgtdata, and possibly Z)
#      p is number of choice alternatives
#      lgtdata is a list of lists (one list per unit)
#          lgtdata[[i]]=list(y,X)
#             y is a vector indicating alternative chosen
#               integers 1:p indicate alternative
#             X is a length(y)*p x nvar matrix of values of
#               X vars including intercepts
#             Z is an length(lgtdata) x nz matrix of values of variables
#               note: Z should NOT contain an intercept
#   Prior contains a list of (deltabar,Ad,mubar,Amu,nu,V,ncomp) 
#      ncomp is the number of components in normal mixture
#      if elements of Prior (other than ncomp) do not exist, defaults are used
#   Mcmc list of Mcmc parameters
#     s is the scaling parameter for the RW inc covariance matrix; s^2 Var is inc cov matrix
#     w is parameter for weighting function in fractional likelihood
#     R is number of draws
#     keep is thining parameter -- keep every keepth draw
#     chains is the number of MCMC simulations for coda diagostics
#   output format
#     default
#     bayesm
#     coda
#
# Default CODA compatible format: list of 
#   llkdraw -- R/keep array of log likelikelhood of draws
#   betadraw -- R/keep x nvar x nlgt array of draws of betas
#   Deltadraw -- R/keep x nvar x nz array of Delta draws, first row is initial value
#   probdraw -- R/keep x ncomp array of draws of probs of mixture components
#   mudraw -- R/keep x nvar x ncomp array of draws of mean parameter of beta coefficients
#   rootdraw -- R/keep x nvar x nvar x ncomp array of error variances of beta coefficients
#
# Bayesm output format: list of 
#   Deltadraw R/keep  x nz*nvar matrix of draws of Delta, first row is initial value
#   betadraw is nlgt x nvar x R/keep array of draws of betas
#   probdraw is R/keep x ncomp matrix of draws of probs of mixture components
#   compdraw is a list of list of lists (length R/keep)
#      compdraw[[rep]] is the repth draw of components for mixtures
#   loglike  log-likelikelhood at each kept draw
#
# CODA output format: 
#   list of CODA compatible simulation chains in default format
#
# Priors:
#    beta_i = D %*% z[i,] + u_i
#       u_i ~ N(mu_ind[i],Sigma_ind[i])
#       ind[i] ~multinomial(p)
#       p ~ dirichlet (a)
#       D is a k x nz array
#          delta= vec(D) ~ N(deltabar,A_d^-1)
#    mu_j ~ N(mubar,A_mu^-1(x)Sigma_j)
#    Sigma_j ~ IW(nu,V^-1)
#    ncomp is number of components
#
#------------------------------------------------------------------------------
`rhierMnlRwMixture` <-
function(
    Data, Prior, Mcmc,
    output=c("default", "bayesm", "coda")
    ) {
        
    nodata  <- missing(Data)
    noprior <- missing(Prior)
    nomcmc  <- missing(Mcmc)
        
    bayesmType <- FALSE
    codaType   <- FALSE
    if (!missing(output)) {
        bayesmType <- output == "bayesm"
        codaType   <- output == "coda"
    }
    
    if (nodata || is.null(Data$lgtdata)) 
        stop("Missing necessary data for processing")
    
    # lgtdata
    lgtdata <- Data$lgtdata
    nlgt <- length(lgtdata)
    nlen <- sum(
        sapply(lgtdata, function(item) { length(item$y) })
        )
    nvar <- ncol(lgtdata[[1]]$X)
    if (nlgt == 0 || nlen == 0 || nvar == 0)
        stop("Empty data processing")
    
    ypooled <- NULL
    for (i in 1:nlgt) {
        item <- lgtdata[[i]]
        if (!is.matrix(item$X))
            stop("The X data elements are not all matrices")
        if (is.null(item$y))
            stop("The y data contains null elements")
        ypooled <- c(ypooled, item$y)
    }
    ylevels <- levels(as.factor(ypooled))    
    
    # data matrix
    p <- Data$p
    if (p != length(ylevels))
        stop("The number of y levels does not match p=", p)
    if (!all.equal(as.integer(ylevels), 1:p))
        stop("Invalid y values beyond the range between 1 and p=", p)
    
    data <- matrix(nrow=nlen*p, ncol=nvar+2)
    iota <- rep(1, p)
    
    curr <- 1
    for (lgt in 1:nlgt) {
        item <- lgtdata[[lgt]]
        
        yval <- as.integer(factor(item$y, levels=ylevels))
        py   <- as.vector(iota %*% t(yval))
        
        npy  <- length(py)
        if (npy != nrow(item$X) || nvar != ncol(item$X))
            stop("The data matrices are non-conformant")
        
        data[curr:(curr+npy-1),] <- cbind(lgt, py, item$X)
        curr <- curr+npy
    }
    
    # Z matrix
    drawDelta <- FALSE
    Z <- if (is.null(Data$Z)) (matrix(numeric(nlgt), nrow=nlgt)) else 
            { drawDelta <- TRUE; Data$Z }
    if (!is.matrix(Z) || length(Z) == 0 || nrow(Z) != nlgt)
        stop("The Z prior is invalid")
    nz <- ncol(Z)
    nvs <- nvar*nz
    
    if (drawDelta) {
        colmeans <- apply(Z, 2, sum)
        if (sum(abs(colmeans)) > 1.e-5)
            stop("The Z matrix has non-zero column means")
    }

    # priors
    ncomp <- if (noprior || is.null(Prior$ncomp)) 
                as.integer(0) else as.integer(Prior$ncomp)
    if (!is.numeric(ncomp) || ncomp <= 0)
        stop("Invalid number of mixture components prior")    

    nu <- if (noprior || is.null(Prior$nu)) (nvar+3) else Prior$nu
    if (!is.numeric(nu) || length(nu) != 1 || nu <= 0) 
        stop("The nu prior is invalid")
    
    Amu <- if (noprior || is.null(Prior$Amu)) .01 else Prior$Amu
    if (!is.numeric(Amu) || length(Amu) != 1 || Amu <= 0) 
        stop("The Amu prior is invalid")
    
    s <- if (noprior || is.null(Prior$s)) 2.93/sqrt(nvar) else Prior$s
    if (!is.numeric(s) || length(s) != 1 || s <= 0) 
        stop("The s prior is invalid")
    
    w <- if (noprior || is.null(Prior$w)) 0.1 else Prior$w
    if (!is.numeric(w) || length(w) != 1 || w <= 0) 
        stop("The w prior is invalid")
    
    muBar <- if (noprior || is.null(Prior$muBar)) 
                numeric(nvar) else Prior$muBar
    if (!is.numeric(muBar) || length(muBar) != nvar) 
        stop("The mubar prior is invalid")
    
    deltaBar <- if (noprior || is.null(Prior$deltaBar)) 
                numeric(nvs) else Prior$deltaBar
    if (!is.numeric(deltaBar) || length(deltaBar) != nvs) 
        stop("The deltabar prior is invalid")
    
    Ad <- if (noprior || is.null(Prior$Ad)) 0.01 else Prior$Ad
    if (is.numeric(Ad) && length(Ad) == 1) Ad <- Ad*diag(nvs)
    if (!is.matrix(Ad) || nvs != nrow(Ad) || nvs != ncol(Ad)) 
        stop("The Ad prior is invalid")
    
    V <- if (noprior || is.null(Prior$V)) nu else Prior$V
    if (is.numeric(V) && length(V) == 1) V <- V*diag(nvar)
    if (!is.matrix(V) || nvar != nrow(V) || nvar != ncol(V)) 
        stop("The V prior is invalid")
    
    a <- if (noprior || is.null(Prior$a)) 
                as.integer(5) else as.integer(Prior$a)
    if (is.integer(a) && length(a) == 1) a <- rep(a, ncomp)
    if (!is.integer(a) || ncomp != length(a) || any(a < 0)) 
        stop("The a prior is invalid")

    # MCMC params
    keep <- if (nomcmc || is.null(Mcmc$keep)) 1 else Mcmc$keep
    if (keep <= 0) stop("The amount of MCMC thining is incorrect")
    
    if (nomcmc || is.null(Mcmc$R) || Mcmc$R <= 0) 
        stop("The number of MCMC iterations is incorrect")
    R <- Mcmc$R
    
    mclen <- floor(R/keep)
    if (mclen < 1) 
        stop("The MCMC thining level exceeds the number of iterations")
    
    #
    # print out problem
    #
    cat(" ",fill=TRUE)
    cat("Starting MCMC Inference for Hierarchical Logit:",fill=TRUE)
    cat("   Normal Mixture with",ncomp,"components for first stage prior",fill=TRUE)
    cat(paste("  ",p," alternatives; ",nvar," variables in X"),fill=TRUE)
    cat(paste("   for ",nlgt," cross-sectional units"),fill=TRUE)
    cat(" ",fill=TRUE)
    cat("Prior Parms: ",fill=TRUE)
    cat("nu =",nu,fill=TRUE)
    cat("\nV ",fill=TRUE)
    print(V)
    cat("\nmubar ",fill=TRUE)
    print(muBar)
    cat("\nAmu ", fill=TRUE)
    print(Amu)
    cat("\na ",fill=TRUE)
    print(a)
    if(drawDelta) { 
        cat("\ndeltabar",fill=TRUE)
        print(deltaBar)
        cat("\nAd",fill=TRUE)
        print(Ad)
    }
    cat(" ",fill=TRUE)
    cat("MCMC Parms: ",fill=TRUE)
    cat(paste("s =", round(s,3),
            ", w =", w,
            ", R =", R,
            ", keep =", keep
            ), fill=TRUE)
    cat("",fill=TRUE)
    
    if (!codaType) {
        message("bayesm option = ", bayesmType, "\n")
        return (.rhierMnlRwMixture(
                        data,
                        Z,
                        deltaBar,
                        muBar,
                        Ad,
                        V,
                        a,
                        Amu,
                        nu,
                        p,
                        nlen,
                        s,
                        w,
                        bayesmType,
                        mclen,
                        keep,
                        R))
    }
    
    mcmc.chains <- if (!nomcmc && !is.null(Mcmc$chains)) 
                    as.integer(Mcmc$chains) else as.integer(3) 
    if (!is.integer(mcmc.chains) || mcmc.chains <= 0) 
                    stop("The mcmc.chains param is invalid")
    
    library(coda)
    loglike.mcmc <- mcmc.list()
    beta.mcmc    <- mcmc.list()
    Delta.mcmc   <- mcmc.list()
    prob.mcmc    <- mcmc.list()
    mu.mcmc      <- mcmc.list()
    root.mcmc    <- mcmc.list()
    
    upper <- which(upper.tri(diag(nvar), diag=TRUE))
    for (i in 1:mcmc.chains) {
        out <- .rhierMnlRwMixture(
                data,
                Z,
                deltaBar,
                muBar,
                Ad,
                V,
                a,
                Amu,
                nu,
                p,
                nlen,
                s,
                w,
                FALSE,
                mclen,
                keep,
                R)
        
        llkDraw   <- matrix(out$llkdraw,   nrow=mclen)
        betaDraw  <- matrix(out$betadraw,  nrow=mclen)
        DeltaDraw <- matrix(out$Deltadraw, nrow=mclen)
        probDraw  <- matrix(out$probdraw,  nrow=mclen)
        muDraw    <- matrix(out$mudraw,    nrow=mclen)
        rootDraw  <- matrix(out$rootdraw,  nrow=mclen)
        
        loglike.mcmc[[i]] <- mcmc(llkDraw)
        beta.mcmc   [[i]] <- mcmc(betaDraw)
        Delta.mcmc  [[i]] <- mcmc(DeltaDraw)
        prob.mcmc   [[i]] <- mcmc(probDraw)
        mu.mcmc     [[i]] <- mcmc(muDraw)
        root.mcmc   [[i]] <- mcmc(rootDraw[, upper])
    }
    
    list(
        loglike.mcmc = loglike.mcmc,
        beta.mcmc    = beta.mcmc,
        Delta.mcmc   = Delta.mcmc,
        prob.mcmc    = prob.mcmc,
        mu.mcmc      = mu.mcmc,
        root.mcmc    = root.mcmc
        )
    
}
                
#------------------------------------------------------------------------------
# .rhierMnlRwMixture
#    -- internal utility
#------------------------------------------------------------------------------
`.rhierMnlRwMixture` <- function(
        data,
        Z,
        deltaBar,
        muBar,
        Ad,
        V,
        a,
        Amu,
        nu,
        p,
        nlen,
        s,
        w,
        bayesmType,
        mclen,
        keep,
        R
) {
    
    pkg <- rpuLoadPackage(rhierMNLLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rhierMnlRwMixture")
    
    nlgt  <- nrow(Z)
    nz    <- ncol(Z)
    nvar  <- length(muBar)
    ncomp <- length(a)
    
    seed <- as.integer(runif(1)*100000)
    ret <- .C("rpuHierMnlRwMixture2", 
            as.rpuNumeric(data), 		
            as.rpuNumeric(Z),		
            as.rpuNumeric(deltaBar),
            as.rpuNumeric(muBar),	
            
            as.rpuNumeric(Ad), 		
            as.rpuNumeric(V),		
            as.rpuNumeric(a),		
            as.rpuNumeric(Amu),		
            as.rpuNumeric(nu),		
            
            as.integer(p),		
            as.integer(nlgt),	
            as.integer(ncomp),	
            as.integer(nz),		
            as.integer(nvar),	
            as.integer(nlen),	
            
            llkDraw		= rpuNumeric(mclen), 
            betaDraw	= rpuNumeric(mclen*nvar*nlgt), 
            DeltaDraw	= rpuNumeric(mclen*nvar*nz), 
            probDraw	= rpuNumeric(mclen*ncomp), 
            muDraw		= rpuNumeric(mclen*nvar*ncomp), 
            rootDraw	= rpuNumeric(mclen*nvar*nvar*ncomp),
            
            as.rpuNumeric(s),		
            as.rpuNumeric(w),		
            
            as.integer(bayesmType),	
            as.integer(mclen),	
            as.integer(keep),	
            as.integer(seed),	
            PACKAGE = pkg)
    
    if (!bayesmType) {
        return (list(
            llkdraw   = matrix(ret$llkDraw,   nrow=mclen),
            betadraw  = matrix(ret$betaDraw,  nrow=mclen),
            Deltadraw = matrix(ret$DeltaDraw, nrow=mclen),
            probdraw  = matrix(ret$probDraw,  nrow=mclen),
            mudraw    = matrix(ret$muDraw,    nrow=mclen),
            rootdraw  = matrix(ret$rootDraw,  nrow=mclen)
        ))
    }
    
    # bayesm output
    loglike   <- as.numeric(ret$llkDraw)
    
    Deltadraw <- matrix(ret$DeltaDraw, nrow=mclen)
    attributes(Deltadraw)$class <- c("bayesm.mat", "mcmc")
    attributes(Deltadraw)$mcpar <- c(1,R,keep)
    
    betadraw  <- array(ret$betaDraw, dim=c(nlgt, nvar, mclen))
    attributes(betadraw)$class <- c("bayesm.hcoef")
    
    # nmix
    probdraw  <- matrix(ret$probDraw, nrow=mclen)
    mudraw    <- matrix(ret$muDraw,   ncol=mclen)
    rootdraw  <- matrix(ret$rootDraw, ncol=mclen)
    
    compdraw  <- list()
    for (i in 1:mclen) {

        mu_i  <- mudraw[, i]
        dim(mu_i) <- c(nvar, ncomp)
        
        root_i <- rootdraw[, i]
        dim(root_i) <- c(nvar*nvar, ncomp)
        
        compobj <- list()
        for (j in 1:ncomp) {
            
            mu_ij <- mu_i[, j]
            root_ij <- root_i[, j]
            dim(root_ij) <- c(nvar, nvar)
            compobj[[j]] <- list(
                    mu = mu_ij,
                    rooti = root_ij
                    )
        }
        
        compdraw[[i]] <- compobj
    }
    
    nmix <- list(
            probdraw = probdraw,
            zdraw    = NULL,
            compdraw = compdraw
            )
    class(nmix) <- "bayesm.nmix"
    
    return (list(
                Deltadraw = Deltadraw,
                betadraw = betadraw,
                nmix = nmix,
                loglike = loglike
                ))

}


