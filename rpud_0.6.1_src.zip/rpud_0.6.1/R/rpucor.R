#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##


#####################################################################
# rpucor
#

`rpuCor` <- 
function(x, ...) 
	UseMethod("rpucor")


`rpucor` <- 
function(x, ...) 
	UseMethod("rpucor")


`rpucor.default` <- 
function(x, y = NULL, use = "everything",
		method = c("pearson", "spearman", "kendall", "gamma"), ...) {
	
	x.name <- deparse(substitute(x))
	y.name <- if (!is.null(y)) deparse(substitute(y)) else ""

	methodNames <- c(
			"pearson", 
			"spearman", 
			"kendall",
			"gamma") 
	method <- match.arg(method)
	
	useNames <- c(
			"everything", 
			"all.obs", 
			"complete.obs", 
			"na.or.complete",
			"pairwise.complete.obs")
	na.option <- match.arg(use, useNames)
	
	pkg <- rpuLoadPackage(rpudLevel)
	if (method == "pearson" || method == "spearman" ||  pkg != RPUDPLUS) {
		ret <- stats::cor(x, y, use=use, method=method, ...)
		attr(ret, "method") <- method
		attr(ret, "use") <- na.option
		return (ret)
	}
	
	if (is.data.frame(x)) x <- as.matrix(x)
	if (is.data.frame(y)) y <- as.matrix(y)
	
	symmetric <- FALSE
	if (is.null(x)) stop("'x' must be non-null")
	if (is.null(y)) { y <- x; symmetric <- TRUE }
	
	stopifnot(is.atomic(x))
	stopifnot(is.atomic(y))
	if (length(x) == 0L || length(y) == 0L)
		stop("both 'x' and 'y' must be non-empty")
	
	matrix_result <- is.matrix(x) || is.matrix(y)
	if (!is.matrix(x)) 
		x <- matrix(x, dimnames=list(rep(NULL, length(x)), x.name))
	if (!is.matrix(y)) 
		y <- matrix(y, dimnames=list(rep(NULL, length(y)), y.name))
	
	if (nrow(x) != nrow(y))
		stop("'x' and 'y' have incompatible dimensions")
	num <- nrow(x)
	if (num < 2)
		stop("not enough finite observations")
	
	ncx <- ncol(x)
	ncy <- ncol(y)
	r <- single(ncx*ncy)
	
	if (symmetric) {
		r <- .C("rpuKendallCorrelation",
				as.single(x),
				as.integer(ncx),
				as.integer(num),
				method,
				na.option,
				r = r,
				NAOK = TRUE,
				PACKAGE = pkg)$r
	} else {
		r <- .C("rpuKendallCorrelationEx",
				as.single(x),
				as.single(y),
				as.integer(ncx),
				as.integer(ncy),
				as.integer(num),
				method,
				na.option,
				r = r,
				NAOK = TRUE,
				PACKAGE = pkg)$r
	}
	
	r <- as.double(r)
	r[is.nan(r)] <- NA
	
	if (matrix_result) {
		dim(r) <- c(ncx, ncy)
		rownames(r) <- colnames(x)
		colnames(r) <- colnames(y)
	}

	class(r) <- c("rpucor")
	attr(r, "method") <- method
	attr(r, "use") <- na.option
	return (r)
}


`print.rpucor` <-
function (x, ...) {
	print(unclass(x))
}


#####################################################################
# rpucor.test
#

`rpucor.test` <- 
function(x, ...) 
	UseMethod("rpucor.test")


`rpucor.test.default` <-
function(x, y = NULL, alternative = c("two.sided", "less", "greater"),
			use = "everything", method = "kendall", ...) {

	pkg <- rpuLoadPackage(0x20)
	if (pkg != RPUDPLUS) {
		stop("Please install Rpudplus for rpucor.test");
	}

	x.name <- deparse(substitute(x))
	y.name <- if (!is.null(y)) deparse(substitute(y)) else ""
	data.name <- if (!is.null(y)) paste(x.name, "and", y.name) else x.name
	
	methodNames <- c(
			"kendall") 
	method <- match.arg(method)
	
	useNames <- c(
			"everything", 
			"all.obs", 
			"complete.obs", 
			"na.or.complete",
			"pairwise.complete.obs")
	na.option <- match.arg(use, useNames)
	
	altNames <- c(
			"two.sided", 
			"less", 
			"greater")
	alternative <- match.arg(alternative, altNames)
	
	if (is.data.frame(x)) x <- as.matrix(x)
	if (is.data.frame(y)) y <- as.matrix(y)
	
	symmetric <- FALSE
	if (is.null(x)) stop("'x' must be non-null")
	if (is.null(y)) { y <- x; symmetric <- TRUE }
	
	stopifnot(is.atomic(x))
	stopifnot(is.atomic(y))
	if (length(x) == 0L || length(y) == 0L)
		stop("both 'x' and 'y' must be non-empty")

	matrix_result <- is.matrix(x) || is.matrix(y)
	if (!is.matrix(x)) 
		x <- matrix(x, dimnames=list(rep(NULL, length(x)), x.name))
	if (!is.matrix(y)) 
		y <- matrix(y, dimnames=list(rep(NULL, length(y)), y.name))
	
	if (nrow(x) != nrow(y))
		stop("'x' and 'y' have incompatible dimensions")
	num <- nrow(x)
	if (num < 2)
		stop("not enough finite observations")
	
	ncx <- ncol(x)
	ncy <- ncol(y)
	r <- single(ncx*ncy)
	z <- single(ncx*ncy)
	
	if (symmetric) {
		res <- .C("rpuKendallCorTest",
				as.single(x),
				as.integer(ncx),
				as.integer(num),
				method,
				na.option,
				r = r,
				z = z,
				NAOK = TRUE,
				PACKAGE = pkg)
	} else {
		res <- .C("rpuKendallCorTestEx",
				as.single(x),
				as.single(y),
				as.integer(ncx),
				as.integer(ncy),
				as.integer(num),
				method,
				na.option,
				r = r,
				z = z,
				NAOK = TRUE,
				PACKAGE = pkg)
	}
	
	# tau estimates
	r <- as.double(res$r)
	r[is.nan(r)] <- NA
	
	dim(r) <- c(ncx, ncy)
	rownames(r) <- colnames(x)
	colnames(r) <- colnames(y)
	
	# z statistics
	z <- as.double(res$z)
	z[is.nan(z)] <- NA
	
	dim(z) <- c(ncx, ncy)
	rownames(z) <- colnames(x)
	colnames(z) <- colnames(y)
	
	# p values
	v <- pnorm(z)
	pval <- switch(alternative,
			"two.sided" = ifelse(v < 0.5, 2*v, 2*(1-v)),
			"greater" = 1 - v,
			"less" = v)
	
	ret <- list(statistic = z,
			p.value = pval,
			estimate = r,
			null.value = c(tau = 0),
			alternative = alternative,
			method = method,
			use = na.option,
			data.name = data.name
	)
	
	class(ret) <- "rpucor.test"
	ret
}


`print.rpucor.test` <-
function (x, digits = 5, prefix = "", ...) {
	
	cat("\n")
	cat(strwrap(x$method, prefix = "\t"), sep="\n")
	cat("\n")
	
	cat("data: ", x$data.name, "\n")
	cat("\n")
	
	cat("use: ", x$use, "\n")
	cat("\n")
	
	if(!is.null(x$estimate)) {
		cat("tau estimates:\n")
		print(format(round(x$estimate, 4)), quote=FALSE)
		cat("\n")
	}
	
	if(!is.null(x$statistic)) {
		cat("z statistics:\n")
		print(format(round(x$statistic, 4)), quote=FALSE)
		cat("\n")
	}
	
	if(!is.null(x$p.value)) {
		cat("p-values:\n")
		print(format(round(x$p.value, digits=digits)), quote=FALSE)
		cat("\n")
	}
	
	if(!is.null(x$alternative)) {
		cat("alternative hypothesis: ")
		if(!is.null(x$null.value)) {
			if(length(x$null.value) == 1L) {
				alt.char <-
						switch(x$alternative,
								two.sided = "not equal to",
								less = "less than",
								greater = "greater than")
				cat("true", names(x$null.value), "is", alt.char,
						x$null.value, "\n")
			}
			else {
				cat(x$alternative, "\nnull values:\n")
				print(x$null.value, ...)
			}
		}
		else cat(x$alternative, "\n")
		cat("\n")
	}
	
	cat("\n")
	invisible(x)
}

