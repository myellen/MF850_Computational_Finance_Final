#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  Based on bayesm (ver 2.2-5)
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##


rhierlmcLevel <- 0x36

#------------------------------------------------------------------------------
# rmultireg
#
# purpose:
#    draw from posterior for Multivariate Regression Model with
#    natural conjugate prior
# arguments:
#    Y is n x m matrix
#    X is n x k
#    Bbar is the prior mean of regression coefficients  (k x m)
#    A is prior precision matrix
#    nu, V are parameters for prior on Sigma
#	 rep is the number of posterior sample draws
# output:
#   list of 
#   Bdraw  -- dim 'R/keep x nreg x nvar' array of B regression coefficients draws 
#   Sigmadraw -- dim 'R/keep x nreg' array of Sigma matrix draws
# model:
#    Y=XB+U  cov(u_i) = Sigma
#    B is k x m matrix of coefficients
# priors:  beta|Sigma  ~ N(betabar,Sigma (x) A^-1)
#                   betabar=vec(Bbar)
#                   beta = vec(B) 
#          Sigma ~ IW(nu,V) or Sigma^-1 ~ W(nu, V^-1)
#------------------------------------------------------------------------------
`rmultireg` <-
function(
    Y, X, Bbar, A, nu, V, rep 
    ) {
        
    pkg <- rpuLoadPackage(rhierlmcLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rmultireg")
    
    n <- nrow(Y)
    m <- ncol(Y)
    k <- ncol(X)
    if (n != nrow(X)) stop("The input data matrices are not conformant")    
    if (k != nrow(Bbar) || m != ncol(Bbar)) stop("The input matrix Bar is not conformant")    
    if (k != nrow(A) || k != ncol(A)) stop("The input matrix A is not conformant")
    if (m != nrow(V) || m != ncol(V)) stop("The input matrix V is not conformant")
    
    R <- as.integer(rep)
    if (R <= 0) stop("The rep param is non-positive")
    
    seed <- as.integer(runif(1)*100000)
    ret <- .C("rpuMultiRegression2", 
            as.rpuNumeric(Y), 
            as.rpuNumeric(X), 
            as.rpuNumeric(Bbar), 
            as.rpuNumeric(A), 
            as.rpuNumeric(V), 
            as.rpuNumeric(nu),
            as.integer(n),
            as.integer(m),
            as.integer(k),
            betaDraw	= rpuNumeric(R*k*m), 
            sigmaDraw	= rpuNumeric(R*m*m),
            R,
            seed,
            PACKAGE=pkg)
    list(
        betadraw = matrix(ret$betaDraw,  nrow=R),
        Sigmadraw = matrix(ret$sigmaDraw, nrow=R)
        )
}


#------------------------------------------------------------------------------
# rhierLinearModel
#
# Purpose:
#   run hiearchical regression model
#
# Arguments:
#   Data list of regdata,Z 
#     regdata is a list of lists each list with members y, X
#        e.g. regdata[[i]]=list(y=y,X=X)
#     X has nvar columns
#     Z is nreg=length(regdata) x nz
#   Prior list of prior hyperparameters
#     Deltabar,A, nu.e,ssq,nu,V
#          note: ssq is a nreg x 1 vector!
#   Mcmc list of Mcmc parameters
#     R is number of draws
#     keep is thining parameter -- keep every keepth draw
#     chains is the number of MCMC simulations for coda diagostics
#   output format
#     default
#     bayesm
#     coda
#
# Default CODA compatible format: list of 
#   betaDraw -- R/keep x nreg x nvar array of individual regression betas
#   tauDraw -- R/keep x nreg  array of error variances for each regression
#   DeltaDraw -- R/keep x nz x nvar array of Delta draws
#   VbetaDraw -- R/keep x nvar*nvar array of Vbeta draws
#
# Bayesm output format: list of 
#   betaDraw -- nreg x nvar x R/keep array of individual regression betas
#   tauDraw -- R/keep x nreg  array of error variances for each regression
#   DeltaDraw -- R/keep x nz x nvar array of Delta draws
#   VbetaDraw -- R/keep x nvar*nvar array of Vbeta draws
#
# CODA output format: 
#   list of CODA compatible simulation chains in default format
#   only the upper triangle of each VbetaDraw sample is kept for coda diagnostics
#
# Model:
#   nreg regression equations 
#        y_i = X_ibeta_i + epsilon_i  
#        epsilon_i ~ N(0,tau_i)
#             nvar X vars in each equation
#
# Priors:
#        tau_i ~ nu.e*ssq_i/chisq(nu.e)  tau_i is the variance of epsilon_i
#        beta_i ~ N(ZDelta[i,],V_beta)
#               Note:  ZDelta is the matrix Z * Delta; [i,] refers to ith row of this product!
#
#          vec(Delta) | V_beta ~ N(vec(Deltabar),Vbeta (x) A^-1)
#          V_beta ~ IW(nu,V)  or V_beta^-1 ~ W(nu,V^-1)
#              Delta, Deltabar are nz x nvar
#              A is nz x nz
#              Vbeta is nvar x nvar
#------------------------------------------------------------------------------
`rhierLinearModel` <-
function(
    Data, Prior, Mcmc,
    output=c("default", "bayesm", "coda")
    ) {
        
    nodata  <- missing(Data)
    noprior <- missing(Prior)
    nomcmc  <- missing(Mcmc)
        
    bayesmType <- FALSE
    codaType   <- FALSE
    if (!missing(output)) {
        bayesmType <- output == "bayesm"
        codaType   <- output == "coda"
    }
    
    regdata <- Data$regdata
    if (nodata || is.null(regdata)) 
        stop("Missing data for processing")
    
    nreg <- length(regdata)
    nlen <- sum(
        sapply(regdata, function(item) { length(item$y) })
        )
    
    nvar <- ncol(regdata[[1]]$X)
    data <- matrix(nrow=nlen, ncol=nvar+2)
    
    curr <- 1
    for (reg in 1:nreg) {
        item <- regdata[[reg]]
        nobs <- length(item$y)
        if (nobs != nrow(item$X) || nvar != ncol(item$X))
            stop("The input data contains non-conformant matrices")
        data[curr:(curr+nobs-1),] <- cbind(reg, item$y, item$X)
        curr <- curr+nobs
    }

    Z <- if (is.null(Data$Z)) 1 else Data$Z
    if (is.numeric(Z) && length(Z) == 1) 
        Z <- matrix(1, nrow=nreg, ncol=1)
    if (!is.matrix(Z) || nreg != nrow(Z)) 
        stop("The Z prior is invalid")
    nz <- ncol(Z)
    
    Deltabar <- if (noprior || is.null(Prior$Deltabar))
                    matrix(0, nrow=nz, ncol=nvar) else Prior$Deltabar 
    if (!is.matrix(Deltabar) || nz != nrow(Deltabar) || nvar != ncol(Deltabar)) 
        stop("The Deltabar prior is invalid")
    
    A <- if (noprior || is.null(Prior$A)) 0.01 else Prior$A
    if (is.numeric(A) && length(A) == 1) A <- A*diag(nz)
    if (!is.matrix(A) || nz != nrow(A) || nz != ncol(A)) 
        stop("The A prior is invalid")
    
    nu.e <- if (noprior || is.null(Prior$nu.e)) 3 else Prior$nu.e
    if (!is.numeric(nu.e) || length(nu.e) != 1 || nu.e <= 0) 
        stop("The nu.e prior is invalid")
    
    ssq <- if (noprior || is.null(Prior$ssq))
                numeric(nreg) else Prior$ssq
    ## find in rpudplus instead 
    #        sapply(regdata, function(item) {
    #            v <- var(item$y)
    #            if (!is.na(v) && v > 0) v else 1
    #            })
           
    if (!is.numeric(ssq) || nreg != length(ssq)) 
        stop("The ssq prior is invalid")
    
    nu <- if (noprior || is.null(Prior$nu)) (nvar+3) else Prior$nu
    if (!is.numeric(nu) || length(nu) != 1 || nu <= 0) 
        stop("The nu prior is invalid")
    
    V <- if (noprior || is.null(Prior$V)) nu else Prior$V
    if (is.numeric(V) && length(V) == 1) V <- V*diag(nvar)
    if (!is.matrix(V) || nvar != nrow(V) || nvar != ncol(V)) 
        stop("The V prior is invalid")
    
    keep <- if (nomcmc || is.null(Mcmc$keep)) 1 else Mcmc$keep
    if (keep <= 0) stop("The amount of MCMC thining is incorrect")
    
    if (nomcmc || is.null(Mcmc$R) || Mcmc$R <= 0) 
        stop("The number of MCMC iterations is incorrect")
    R <- Mcmc$R
    
    mclen <- floor(R/keep)
    if (mclen < 1) 
        stop("The MCMC thining level exceeds the number of iterations")
    
    #
    # print out problem
    #
    cat(" ", fill=TRUE)
    cat("Starting Gibbs Sampler for Linear Hierarchical Model",fill=TRUE)
    cat("   ",nreg," Regressions",fill=TRUE)
    cat("   ",ncol(Z)," Variables in Z (if 1, then only intercept)",fill=TRUE)
    cat(" ", fill=TRUE)
    cat("Prior Parms: ",fill=TRUE)
    cat("===========  ",fill=TRUE)
    cat("Deltabar",fill=TRUE)
    print(Deltabar)
    cat(" ",fill=TRUE)    
    cat("A",fill=TRUE)
    print(A)
    cat(" ",fill=TRUE)    
    cat("nu.e (d.f. for regression error variances) =",nu.e,fill=TRUE)
    cat(" ",fill=TRUE)    
    cat("Vbeta ~ IW(nu,V)",fill=TRUE)
    cat(" ",fill=TRUE)    
    cat("nu =",nu,fill=TRUE)
    cat(" ",fill=TRUE)    
    cat("V ",fill=TRUE)
    print(V)
    cat(" ", fill=TRUE)
    cat("MCMC parms: ",fill=TRUE)
    cat("==========  ",fill=TRUE)
    cat("R = ",R,", keep = ",keep,fill=TRUE,sep="")
    cat(" ",fill=TRUE)    
    
    if (!codaType) {
        message("bayesm option = ", bayesmType, "\n")
        return (.rbayesHierLinearModel(
                        data,
                        Z,
                        Deltabar,
                        A,
                        V,
                        ssq,
                        nu.e,
                        nu,
                        nreg,
                        nz,
                        nvar,
                        nlen,
                        bayesmType,
                        mclen,
                        keep,
                        R))
    }
    
    mcmc.chains <- if (!nomcmc && !is.null(Mcmc$chains)) 
                as.integer(Mcmc$chains) else as.integer(3) 
    if (!is.integer(mcmc.chains) || mcmc.chains <= 0) 
                stop("The mcmc.chains param is invalid")
    
    library(coda)
    Vbeta.mcmc <- mcmc.list()
    Delta.mcmc <- mcmc.list()
    tau.mcmc   <- mcmc.list()
    beta.mcmc  <- mcmc.list()

    upper <- which(upper.tri(diag(nvar), diag=TRUE))
    for (i in 1:mcmc.chains) {
        out <- .rbayesHierLinearModel(
                        data,
                        Z,
                        Deltabar,
                        A,
                        V,
                        ssq,
                        nu.e,
                        nu,
                        nreg,
                        nz,
                        nvar,
                        nlen,
                        FALSE,
                        mclen,
                        keep,
                        R)
                
        Vbetadraw <- matrix(out$Vbetadraw, nrow=mclen)
        Deltadraw <- matrix(out$Deltadraw, nrow=mclen)
        taudraw   <- matrix(out$taudraw,   nrow=mclen)
        betadraw  <- matrix(out$betadraw,  nrow=mclen)
        
        Vbeta.mcmc[[i]] <- mcmc(Vbetadraw[, upper])
        Delta.mcmc[[i]] <- mcmc(Deltadraw)
        tau.mcmc  [[i]] <- mcmc(taudraw)
        beta.mcmc [[i]] <- mcmc(betadraw)
    }
    
    list(
        Vbeta.mcmc=Vbeta.mcmc,
        Delta.mcmc=Delta.mcmc,
        tau.mcmc  =tau.mcmc,
        beta.mcmc =beta.mcmc
    )
}


#------------------------------------------------------------------------------
# .rbayesHierLinearModel
#    -- internal utility
#------------------------------------------------------------------------------
`.rbayesHierLinearModel` <- function(
    data,
    Z,
    Deltabar,
    A,
    V,
    ssq,
    nu.e,
    nu,
    nreg,
    nz,
    nvar,
    nlen,
    bayesmType,
    mclen,
    keep,
    R
) {
    
    pkg <- rpuLoadPackage(rhierlmcLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rhierLinearModel")
    
    seed <- as.integer(runif(1)*100000)
    ret <- .C("rpuHierLinearModel2", 
            as.rpuNumeric(data), 
            as.rpuNumeric(Z),
            as.rpuNumeric(Deltabar), 
            as.rpuNumeric(A), 
            as.rpuNumeric(V),
            as.rpuNumeric(ssq), 
            as.rpuNumeric(nu.e), 
            as.rpuNumeric(nu),
            as.integer(nreg),
            as.integer(nz),
            as.integer(nvar),
            as.integer(nlen),
            VbetaDraw	= rpuNumeric(mclen*nvar*nvar), 
            DeltaDraw	= rpuNumeric(mclen*nz*nvar), 
            tauDraw  	= rpuNumeric(mclen*nreg), 
            betaDraw  	= rpuNumeric(mclen*nreg*nvar),
            as.integer(bayesmType),
            as.integer(mclen),
            as.integer(keep),
            as.integer(seed),
            PACKAGE = pkg)
    
    VbetaDraw <- matrix(ret$VbetaDraw, nrow=mclen)
    DeltaDraw <- matrix(ret$DeltaDraw, nrow=mclen)
    tauDraw   <- matrix(ret$tauDraw,   nrow=mclen)
    betaDraw  <- if (bayesmType) matrix(ret$betaDraw, ncol=mclen)
                    else matrix(ret$betaDraw, nrow=mclen)
    
    if (bayesmType) {
        attributes(VbetaDraw)$class <- c("bayesm.var","bayesm.mat","mcmc")
        attributes(VbetaDraw)$mcpar <- c(1,R,keep)
        
        attributes(DeltaDraw)$class <- c("bayesm.mat","mcmc")
        attributes(DeltaDraw)$mcpar <- c(1,R,keep)
        
        attributes(tauDraw)$class <- c("bayesm.mat","mcmc")
        attributes(tauDraw)$mcpar <- c(1,R,keep)
        
        betaDraw <- array(as.vector(betaDraw), dim=c(nreg, nvar, mclen))
        attributes(betaDraw)$class <- c("bayesm.hcoef")
    }
    
    list(
        Vbetadraw=VbetaDraw,
        Deltadraw=DeltaDraw,
        taudraw=tauDraw,
        betadraw=betaDraw
        )
}
    
