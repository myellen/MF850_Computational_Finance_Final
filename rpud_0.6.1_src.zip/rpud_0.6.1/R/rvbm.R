#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  Based on vbmp (ver 1.26.0)
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##


LOG2PI <- log(2*pi)

rvbmLevel <- 0x30

rvbmKernelNames <- c(
		"linear", 
		"polynomial", 
		"cauchy", 
		"gaussian", 
		"laplacian", 
		"sigmoid")


`rvbm` <-
function (X, 
		 t.class, 
		 X.TEST, 
		 t.class.TEST, 
		 theta = rep(1, ncol(X)), 
		 control = list()
) UseMethod ("rvbm")


`rvbm.default` <- 
function (X, 
		 t.class, 
		 X.TEST, 
		 t.class.TEST, 
		 theta = rep(1, ncol(X)), 
		 control = list()
) {
# X - Feature matrix for parameter 'estimation' - of dimension N x Kd
# t.class - The corresponing target values - class labels
# X.TEST - Feature matrix to compute out-of-sample (test) prediction errors and likelihoods
# t.TEST - Corresponding target values for test data
# theta - The covariance function parameters - e.g. scaling coefficients for each dimension
# control param list:
#   bThetaEstimate - TRUE if covariance parameter estimation switched on, FALSE if switched off
#   maxIts - the maximum number of variational EM steps to take (default=50)
#   sKernelType - Select from Gaussian, Polynomial or Linear Inner product (default=gauss)
#   Thresh - Convergence threshold on marginal likelihood lower-bound (default=1e-4)
#   InfoLevel - 0 to suppress tracing ( > 0 to print different levels of monitoring information)

	# ------------ check data dimension
	if (is.null(dim(X)))  X <- matrix(X,nrow=length(X),ncol=1)
	if (is.null(dim(X.TEST))){
		X.TEST <- matrix(X.TEST, ncol=ncol(X))
	} else if (ncol(X.TEST) != ncol(X)) stop("Number of cols differ between X and X.TEST")
	
	# ------------ check parameters    
	con <- .controlParams(control)
	con$bMonitor <- con$bMonitor | con$bPlotFitting
	
	if (is.factor(t.class) || is.character(t.class)){
		temp <- as.numeric(factor(c(as.character(t.class), as.character(t.class.TEST))))
		t.class <- temp[1:length(t.class)]
		t.class.TEST <- temp[(length(t.class)+1):length(temp)]
		rm(temp)
	}
	if (any(theta<=0)) stop("theta params (scale) must be > 0")
	
	## ------------------------------------------------------------------------------
	G.LOWER.BOUND.DEFAULT <-  -1e-3 ## default lower bound value
	G.DIFF.DEFAULT        <-  1e100 ## Monitor difference in marginal likelihood
	
	.beginRvbmSession()
	
	.printTrace(paste("Starting at: ", date(), "...... \n"),
			con$sFILE.TRACE, con$InfoLevel, bAppend=FALSE)
	
	.printTrace(paste(" feature matrix dimension = (", toString(dim(X)), 
					  "), test matrix dimension = (", toString(dim(X.TEST)), ")\n"),
			con$sFILE.TRACE, con$InfoLevel - 2)
	
	# decide b.traintest
	if (nrow(X) == nrow(X.TEST)) {
		b.traintest <- all(X == X.TEST) && all(t.class == t.class.TEST)
	} else  b.traintest <- FALSE
	
	Kc <- max(t.class)            ## Identify the number of classes
	N <- nrow(X); Kd <- ncol(X)   ## Get number of samples and dimension of data
	
	## randomly initializse M,Y matrix (see paper)
	Y <- matrix(rnorm(N*Kc), nrow=N, ncol=Kc)
	if (con$bInitM) Mt <- matrix(runif(N*Kc), nrow=N, ncol=Kc)
	.printTrace(paste("  bInitM =", con$bInitM), con$sFILE.TRACE, con$InfoLevel - 1)
	
	## diagonal matrix of the covariance params for passing to kernel function
	#Theta <- diag(theta)
	## Set hyper-params for covariance params to one. In this application
	## The vbmp authors use a simple exponential distribution over the theta values so
	## there is only a mean value required psi.
	if (length(theta) == 0) theta <- rep(1, Kd)
	psi   <- rep(1, length(theta))
	
	In    <- diag(1, N)          ## N x N dimensional identity matrix
	Ic    <- diag(1, Kc)         ## Kc x Kc dimensional identity matrix

	## Create the covariance (kernel) matrix and add some small jitter on diagonal
	PHI <- .computeKernel(X, NULL, theta, con) + In * con$nSmallNo
	
	## precompute the inverse matrices required
	cholPHI <- rpuchol(PHI + In)

	#invPHI <- chol2inv(cholPHI)
	#Ki <- PHI %*% invPHI
	invChol <- backsolve(cholPHI, In, transpose=TRUE)

	K2 <- backsolve(cholPHI, invChol %*% PHI)
	trace.Ki  <- sum(diag(K2))

	diag.InvPHI <- sum(invChol*invChol)
	logDiag.cholPHI <- sum(.safeLog(diag(cholPHI)))
	
	## Collect all the posterior mean values of the covariance params
	THETA <- matrix(theta, nrow=1, ncol=length(theta))
	## Collect all the values of the lower-bound
	lowerBound <- G.LOWER.BOUND.DEFAULT
	## Monitor difference in marginal likelihood
	scan.diff <- G.DIFF.DEFAULT
	## Collect all values of the predictive likelihood
	PL <- NULL
	## Collect all values of the percentage predictions incorrect
	testErr <- NULL   
	
	## -------------------------------------------------------------------------
	## Main loop
	## -------------------------------------------------------------------------
	its     <- 0         ## Initiliase iteration number
	bconverged <- FALSE
	tmean.scan <- NULL
	
	Nsamps <- if (con$method == "quadrature") con$nNodesQuad else con$nSampsTG
	UQP <- .gaussQuad(Nsamps)
	
	while ((its < con$maxIts) && (! bconverged)) {
		its <- its + 1
		
		.printTrace(paste(its, 
			"> update the columns of the M-matrix ",
			"- equation (8) of the paper"), 
			con$sFILE.TRACE, con$InfoLevel - 1)
		## - formula (4.6)
		Mt <- crossprod(K2, Y)
		
		.printTrace(paste(its, 
			"> update the rows of the Y-matrix",
			"- equation (5) & (6) of the paper "), 
			con$sFILE.TRACE, con$InfoLevel - 1)
		scan.res <- .computeMeanQuad(Y, Mt, t.class, UQP, con)
		scan.lower.bound <- scan.res$lower.bound
		Y <- scan.res$Y
		
		.printTrace(paste(its, "> initial scan.lower.bound =", scan.lower.bound), 
				con$sFILE.TRACE, con$InfoLevel - 1)
		
		if (con$bThetaEstimate) {
			.printTrace(paste(its, "> update the posterior mean estimates of the",
								"covariance function parameters and hyper-params"),
					con$sFILE.TRACE, con$InfoLevel - 1)
			
			## - formula (4.7)  pag 1796 
			theta <- .varphiUpdate(X, Mt, psi, con)
			.printTrace(paste(its, "> theta =", sQuote(toString(theta))), 
					con$sFILE.TRACE, con$InfoLevel - 3)
		
			## - formula (4.8)  pag 1797
			psi   <- (con$parGammaSigma + 1)/(con$parGammaTau + theta)
			
			if (con$bMonitor) 
				THETA <- rbind(THETA, theta)
			
			if (con$bPlotFitting) {
				if (its == 1) par(mfrow=c(2, 2))                
				scov <- matrix(as.numeric(.safeLog(THETA)), ncol=ncol(THETA),
						nrow=nrow(THETA))
				plot(NULL, type="n", xlim=c(1,nrow(scov)), xlab="Iteration",
						main="Covariance Params Posterior Mean Values",
						ylim=c(min(scov)-1e-6, max(scov)+1e-6), ylab="log(theta)")
				for (kkk in 1:ncol(scov)) {
					lines(scov[, kkk],  lty="dotdash", col=kkk)
				}
			}
			
			PHI <- .computeKernel(X, NULL, theta, con)
			cholPHI <- rpuchol(PHI + In)
			
			#invPHI <- chol2inv(cholPHI)
			#Ki <- PHI %*% invPHI
			invChol <- backsolve(cholPHI, In, transpose=TRUE)

			K2 <- backsolve(cholPHI, invChol %*% PHI)
			trace.Ki  <- sum(diag(K2))

			diag.InvPHI <- sum(invChol*invChol)
			logDiag.cholPHI <- sum(.safeLog(diag(cholPHI)))
			
			.printTrace(paste(its, "> trace.Ki =", trace.Ki, 
							", diag.InvPHI =",  diag.InvPHI,
							", logDiag.cholPHI =",  logDiag.cholPHI),
					con$sFILE.TRACE, con$InfoLevel - 2)
		}
		
		.printTrace(paste(its, "> compute the lower-bound"), 
				con$sFILE.TRACE, con$InfoLevel - 1)
		LM <- invChol %*% Mt
		scan.lower.bound <- scan.lower.bound - 0.5 * sum(LM*LM) + 
				-0.5 * Kc * (trace.Ki + diag.InvPHI + 2*logDiag.cholPHI) + 
				-0.5 * ((Kc-1) * LOG2PI - Kc) * N 
		.printTrace(paste(its, "> accumulated scan.lower.bound =", scan.lower.bound, "\n"), 
				con$sFILE.TRACE, con$InfoLevel - 2)
		
		## update the development of the bound at every iteration
		lowerBound <- c(lowerBound, scan.lower.bound)
		if (its == 2) lowerBound[1] <- lowerBound[2]
		
		if (con$bPlotFitting) {
			if (its == 1 && (!con$bThetaEstimate)) par(mfrow=c(1,3))
			plot(lowerBound, type="l", main="Lower Bound",
					lty="dotdash", xlab="Iteration", ylab="Lower bound")
		}
		
		## Monitoring convergence
		scan.diff <- abs(100*(scan.lower.bound - lowerBound[its])/lowerBound[its])
		bconverged <- (scan.diff < con$Thresh)
		if (con$bMonitor || bconverged || its == con$maxIts || con$bPlotFitting) {
			## --------------------------------------------------------------
			.printTrace(paste(its, 
				"> Compute the predictive posteriors on the test set"),
				con$sFILE.TRACE, con$InfoLevel - 1)
			
			## Compute the predictive posteriors on the test set and
			## the associated likelihood and test errors
			Ntest <- nrow(X.TEST)     ## Number of test points
			
			## Create test covariance matrices required to obtain predictive
			## mean and variance values
			if (!b.traintest) {
				PHItest <- .computeKernel(X, X.TEST, theta, con)
				PHItestSelf <- .computeDiagKernel(X.TEST, theta, con)
			} else {
				PHItest <- PHI
				PHItestSelf <- diag(PHI)
			}
			
			## ---------------------------------------------------------------
			## Computes the predictive posteriors as defined in Section 4.5 of the paper.
			## first two equations at page 1798
			Ptest <- .computePredictivePosterior(
						Y, cholPHI, PHItest, PHItestSelf, UQP, con)
				
			## Computes the overall predictive likelihood
			predictive.likelihood <- sum(.safeLog( 
				apply( cbind(Ptest, t.class.TEST), 1, function(s){ s[s[Kc+1]] } )
			))
	
			if (is.null(PL)) {
				PL <- predictive.likelihood/Ntest
			} else {
				PL <- c(PL, predictive.likelihood/Ntest)
			}
			
			if (con$bPlotFitting) {
				plot(PL, type="l", main="Predictive Likelihood",
						lty="dotdash", xlab="Iteration")
			}
			
			## Compute the 0-1 error loss.
			fvals <- as.numeric(apply(Ptest, 1, which.max))
			scanTestErr  <- 100*(sum(fvals != t.class.TEST))/Ntest
			if (is.null(testErr)) { 
				testErr <- scanTestErr
			} else { 
				testErr <- c(testErr, scanTestErr)
			}
			if (con$bPlotFitting) {
				plot((100-testErr), type="l", lty="dotdash", xlab="Iteration",
						main="Out-of-Sample Percent Prediction Correct")
			}
			
			.printTrace(paste(its, 
				"> Value of Lower-Bound =", scan.lower.bound,
				", Prediction Error = ", scanTestErr,
				", Predictive Likelihood = ", predictive.likelihood/Ntest),
				con$sFILE.TRACE, con$InfoLevel)
			#Acc <- 100 - testErr[its]
			vbmultiprob.obj <- 
				structure( list(
						call			= match.call(),
						Ptest			= Ptest, 
						X				= X, 
						cholPHI			= cholPHI, 
						Y				= Y, 
						Kc				= Kc, 
						M				= Mt,
						sKernelType		= con$sKernelType, 
						THETA			= THETA, 
						con				= con,
						lowerBound		= lowerBound,
						testErr			= testErr, 
						PL				= PL),  
					class="rvbm")
		}
		
		if (!is.null(con$tmpSave)) {
			save(vbmultiprob.obj, file=con$tmpSave)
		}
		
	}	# while

	.endRvbmSession()
	
	vbmultiprob.obj
}


`predict.rvbm` <-
function(object, X.TEST=NULL, ...) {
## Computes the predictive posteriors as defined in Section 4.5 of the paper.
## first two equations at page 1798
	if (!inherits(object, "rvbm"))	
		stop("The input object must inherits rvbm")

	con <- .controlParams(object$con)
	
	X  <- object$X
	if (length(X.TEST)==0) X.TEST <- X
	
	Y <- object$Y
	cholPHI <- object$cholPHI
	
	theta <- .covParams(object)
	PHItest <- .computeKernel(X, X.TEST, theta, con)
	PHItestSelf <- .computeDiagKernel(X.TEST, theta, con)
	
	Nsamps <- if (con$method == "quadrature") con$nNodesQuad else con$nSampsTG
	UQP <- .gaussQuad(Nsamps)
	
	Ptest <- .computePredictivePosterior(
		Y, cholPHI, PHItest, PHItestSelf, UQP, con)

	ret <- as.numeric(apply(Ptest, 1, which.max))
	attr(ret, "Ptest") <- Ptest
	
	ret
}


`plot.rvbm` <-
function(x, ...) {
	if (!inherits(x, "rvbm"))	
		stop("The input object must inherits rvbm")
	
	theta <- x$THETA
	if (nrow(theta) > 1)  {
		par(mfrow=c(2, 2))
		## plot covariance parameters evolution
		scov <- matrix(as.numeric(.safeLog(theta)), ncol=ncol(theta), 
				nrow=nrow(theta))
		plot(NULL, type="n", xlim=c(1,nrow(scov)), xlab="Iteration",
				main="Covariance Parameters",
				ylim=c(min(scov)-1e-6, max(scov)+1e-6), ylab="log(theta)")
		for (kkk in 1:ncol(scov)) {
			lines(scov[, kkk],  lty="dotdash", col=kkk)
		}   
	} else par(mfrow=c(1, 3))
	## plot lower bound evolution
	plot(x$lowerBound, type="l", main="Lower Bound", lty="dotdash", 
			xlab="Iteration", ylab="Lower bound")
	## plot PL evolution
	plot(x$PL, type="l", main="Predictive Likelihood", lty="dotdash", 
			xlab="Iteration", ylab="PL")
	## plot test error
	plot((100-x$testErr), type="l", lty="dotdash", xlab="Iteration", 
			ylab="Accuracy %", main="Out-of-Sample Prediction Correct")
	par(mfrow=c(1,1))
}


`print.rvbm` <-
function (x, ...) {
	if (!inherits(x, "rvbm"))	
		stop("The input object must inherits rvbm")

	cat("\nCall:", deparse(x$call, 0.8 * getOption("width")), "\n", sep="\n")
	cat("Parameters:\n")
	
	con <- x$con
	cat("  Kernel type:         ", con$sKernelType, "\n")
	
	kName <- con$kName
	if (kName == "polynomial" || kName == "cauchy")
		cat("      degree:      ", con$kDegree, "\n")
	if (kName == "polynomial" || kName == "sigmoid")
		cat("      coefficient: ", con$kCoef0, "\n")
	
	cat("  Integration method:  ", con$method, "\n")
	if (con$method == "quadrature"){
		cat("      number of nodes: ", con$nNodesQuad, "\n")
	} else {
		cat("      number of truncated samples: ", con$nSampsTG, "\n")
	}
	cat("  Importance sampling population:  ", con$nSampsIS, "\n")
	
	cat("  Gamma prior over covariance parameters: \n")
	cat("      location: ", con$parGammaTau, "\n")
	cat("      scale:    ", con$parGammaSigma, "\n")
	
	cat("\n\n")
}


`summary.rvbm` <-
function(object, ...) {
	if (!inherits(object, "rvbm"))	
		stop("The input object must inherits rvbm")

	structure(
		list(
			model = object,
			Kc = object$Kc,
			covParams = .covParams(object),
			predLik = .predLik(object),
			predError = .predError(object),
			predClass = .predClass(object)
		),
		class = "summary.rvbm"
	)
}


`print.summary.rvbm` <-
function (x, ...) {
	if (!inherits(x, "summary.rvbm"))	
		stop("The input argument must be an object of type summary.rvbm")
		
	print(x$model)

	cat("Number of auxiliary classes:   ", x$Kc, "\n\n")
	
	cat("Covariance kernel hyperparameters: \n")
	print(summary(x$covParams))
	cat("\n\n")
	
	cat("Posterior log likelihood: ", x$predLik, "\n")
	cat("Prediction error rate:    ", x$predError * 100, "%\n")
	
	cat("\n\n")
}
	


###################################################
## support functions


`rpuchol` <- 
function (x, ...) {
	
	x <- as.matrix(x)
	
	num <- nrow(x)
	if (ncol(x) != num) stop("Non-symmetrical dimensions")
	
	pkg <- rpuLoadPackage(rvbmLevel)
	if (pkg != RPUDPLUS || num < 1024) return (chol(x, ...))
	
	cret <- .C("rgpCholFactor",
			x = as.rpuNumeric(x),
			as.integer(num),
			PACKAGE = pkg)
	matrix(cret$x, nrow=num)
	
#	#chol2inv
#	K <- backsolve(L, diag(num), upper=T, tran=T)	# K = Inv(L')
#	backsolve(L, K, upper=T)							# Inv(L)%*%Inv(L')
}


`rvbm.kernel` <- 
function(X, 
		Y 		= NULL, 
		kName	= "gaussian",
		kDegree	= 1,
		kCoef0	= 0,
		kParams	= NULL
){
# X - M x d data matrix
# Y - N x d data matrix
# kName - string name of kernel function
#	Prefix with '+' to add bias (e.g. '+gauss')
#	Prefix with '*' to add bias and augmenting with Y covariate (e.g. '*gauss')
# kParams - coordinate scale parameters
# returns - M x N (or N+1 if bias, or N+ncol(Y)+1 for Y augmentation) design matrix.
#	The first column comprises 1's if a bias is used
#	The subsequent ncol(Y) columns comprises Y covariate if Y augmentation is used
	
	X <- as.matrix(X)
	
	symm <- length(Y) == 0
	if (!symm) {
		Y <- as.matrix(Y)
		symm <- all(dim(X) == dim(Y)) && all(X == Y)
	}
	
	M <- nrow(X)
	N <- if (symm) M else nrow(Y)
	
	dm <- ncol(X)
	if (!symm && dm != ncol(Y)) stop("Mismatched column dimensions")
	
	kParams <- as.numeric(kParams)
	if (length(kParams) == 0) kParams = 1	# falls through
	if (length(kParams) == 1) kParams <- rep(kParams, dm)
	if (any(kParams <= 0))	stop("Kernel parameters must be all positive")
	
	augParams <- .augmentParams(X, kName)
	kName <- augParams$kName
	
	# validate params
	err <- " argument must not be NULL or empty!"
	if (length(kName)   == 0) 	stop(sQuote("kName"), err)
	if (length(kDegree) == 0) 	stop(sQuote("kDegree"), err)
	if (length(kCoef0)  == 0) 	stop(sQuote("kCoef0"), err)
	
	pkg <- rpuLoadPackage(rvbmLevel)
	if (pkg == RPUDPLUS) {
		kapper <- rpuNumeric(2)
		kapper[1] <- kDegree
		kapper[2] <- kCoef0
		
		cret <- .C("rgpKernelMatrix",
				x   = as.rpuNumeric (X),
				y   = as.rpuNumeric (if (!symm) Y else 0),
				as.integer(M),
				as.integer(N),
				as.integer(dm),
				as.integer(symm),
				as.rpuNumeric(kapper),
				as.integer(length(kapper)),
				as.rpuNumeric(kParams),
				as.integer(length(kParams)),
				kernel = match.arg(kName, rvbmKernelNames), 
				PHI = rpuNumeric(M*N),
				PACKAGE = pkg)
		PHI <- cret$PHI	
		dim(PHI) <- c(M, N)
		
	} else {
		
		kParams <- sqrt(kParams)
		X <- t(as.matrix(apply(X, 1, function(x) x/kParams)))
		Y <- if (symm) X else t(as.matrix(apply(Y, 1, function(x) x/kParams)))
		
		if (kName == 'linear') {
			PHI <- tcrossprod(X, Y) 
			
		} else if (kName =='polynomial') {
			PHI <- tcrossprod(X, Y)
			PHI <- (PHI+kCoef0)^(kDegree)
			
		} else if (kName == 'cauchy') {
			r2  <- .distSqrd(X, Y)
			PHI <- (1+r2)^(-kDegree)
			
		} else if (kName =='gaussian') {
			PHI <- exp(- .distSqrd(X, Y))
			
		} else if (kName == 'laplacian') {
			r2  <- .distSqrd(X, Y)
			PHI <- exp(-sqrt(r2))
			
		} else if (kName == 'sigmoid') {
			PHI <- tcrossprod(X, Y) 
			PHI <- tanh(PHI+kCoef0)
		}
	}
	
	b <- augParams$b
	if (any(b)) {
		varParams <- augParams$varParams
		if (!is.null(varParams)) {
			b <- t(as.matrix(apply(b, 1, function(x) x/varParams)))
		}
		PHI <- as.matrix(cbind(b, PHI))
	}
	
	PHI
}


###################################################
## internal functions


`.beginRvbmSession` <-
function() {
	
	pkg <- rpuLoadPackage(rvbmLevel)
	if (pkg == RPUDPLUS) {
		cret <- .C("beginSession",
				param = as.integer(rvbmLevel),
				PACKAGE = pkg)
	} else {
		message("Missing rpudplus library.\n")
	}
	
}


`.endRvbmSession` <-
function() {
	
	pkg <- rpuLoadPackage(rvbmLevel)
	if (pkg == RPUDPLUS) {
		cret <- .C("endSession",
				param = as.integer(rvbmLevel),
				PACKAGE = pkg)
	}
	
}


`.augmentParams` <-
function(X, kName) {

	M <- nrow(X)
	dm <- ncol(X)
	
	b <- NULL
	varParams <- NULL
	
	prefix <- substr(kName, 1, 1)
	if (prefix == '+') {
		b <- matrix(1, nrow=M, ncol=1)
		kName <- substr(kName, 2, nchar(kName))
		
	} else if (prefix == '*') {
		b <- as.matrix(cbind(rep(1, M), X))
		kName <- substr(kName, 2, nchar(kName))
		if (length(kParams) == dm)  {
			varParams <- c(1, rep(1, dm))
		} else {
			# rescaling Y compontents differently from that used for kernel
			varParams <- c(1, kParams[1:dm])
			kParams <- kParams[(dm+1):(2*dm)]
		}
	}
	
	list(
		b = b,
		kName = kName,
		varParams = varParams
	)
}


`.controlParams` <-
function(control) {
	
	con <- list(
		InfoLevel		= 0, 			#
		sFILE.TRACE		= NULL, 
		bThetaEstimate	= FALSE, 		#
		sKernelType		= "gaussian",	#
		kName			= NULL,
		kDegree			= 3,
		kCoef0			= 1,
		maxIts			= 50, 			#
		Thresh			= 1e-4, 		#
		tmpSave			= NULL, 
		nNodesQuad		= 49,
		nSampsTG		= 1000, 
		nSampsIS		= 1000, 
		nSmallNo		= 1e-10, 
		parGammaSigma	= 1e-6, 
		parGammaTau		= 1e-6, 
		bMonitor		= FALSE, 
		bPlotFitting	= FALSE, 
		bInitM			= FALSE,
		method			= "quadrature"
	)
	con[names(control)] <- control		# override default params
	
	kName <- con$sKernelType
	prefix <- substr(kName, 1, 1)
	if (prefix == '+' || prefix == '*') {
		kName <- substr(kName, 2, nchar(kName))
	}
	
	index <- pmatch(kName, rvbmKernelNames)
	if (is.na(index)) stop(paste("Invalid kernel type parameter:", sQuote(kName)))
	con$kName <- rvbmKernelNames[index] 
	
	con
}


`.computeDiagKernel` <- 
function(X, kParams, con) {

	X <- as.matrix(X)
	M <- nrow(X)
	dm <- ncol(X)
	
	augParams <- .augmentParams(X, con$sKernelType)
	if (any(augParams$b)) {
		return (diag(.computeKernel(X, NULL, kParams, con)))
	}
	kName <- augParams$kName
	
	PHI <- NULL
	if (kName == "linear"|| kName == "polynomial" || kName == "sigmoid") {
		
		kParams <- as.numeric(kParams)
		if (length(kParams) == 0) kParams = 1	# falls through
		if (length(kParams) == 1) kParams <- rep(kParams, dm)
		if (any(kParams <= 0))	stop("Kernel parameters must be all positive")
		
		kParams <- sqrt(kParams)
		X <- t(as.matrix(apply(X, 1, function(x) x/kParams)))
		PHI <- rowSums(X*X)
		
		kDegree <- con$kDegree
		kCoef0  <- con$kCoef0
		if (kName =='polynomial') {
			PHI <- (PHI+kCoef0)^(kDegree)
		} else if (kName == 'sigmoid') {
			PHI <- tanh(PHI+kCoef0)
		}
	} else {
		PHI <- rep(1, M)
	}
	
	PHI
}
	

`.computeKernel` <- 
function(X, Y, kParams, con) {
	
	rvbm.kernel(X, Y, 
			con$sKernelType,
			con$kDegree,
			con$kCoef0,
			kParams)
}


`.computeMeanQuad` <-
function(Y, Mt, t.class, UQP, con) {
	
	Nsamps <- length(UQP$nodes)
	if (!Nsamps) stop("Empty sample nodes from gaussian quadrature")
	
	N <- nrow(Y)
	Kc <- ncol(Y)
	scan.lower.bound <- 0
	
	pkg <- rpuLoadPackage(rvbmLevel)
	if (pkg == RPUDPLUS) {
		
		cret <- .C("rvbmMeanQuad",
				as.rpuNumeric   (Mt),
				as.integer   	(t.class-1),
				as.integer      (N),
				as.integer      (Kc),
				
				as.rpuNumeric   (UQP$nodes),
				as.rpuNumeric   (UQP$weights),
				as.integer      (Nsamps),
				
				Y 			= rpuNumeric(N*Kc),
				lower.bound = rpuNumeric(1),
				PACKAGE = pkg)
		
		Y <- matrix(cret$Y, nrow=N, ncol=Kc)
		scan.lower.bound <- cret$lower.bound
		
	} else {
		z <- numeric(nrow(Y))
		for (n in 1:nrow(Y)) {
			scan.tm <- .tmean.quad(Mt[n,], t.class[n], Nsamps, UQP)
			if (! is.null(scan.tm)) {
				Y[n,] <- scan.tm$tm
				z[n] <- scan.tm$z
			} else stop("tmean error.....")
		}
		scan.lower.bound <- sum(.safeLog(z))
	}
	
	list(Y=Y, lower.bound=scan.lower.bound)
}


`.computePredictivePosterior` <-
function (Y, cholPHI, PHItest, PHItestSelf, UQP, con) {

	Kc <- ncol(Y)
	if (Kc <= 2) stop("Multinomial only code....")
	
	if (ncol(PHItest) != length(PHItestSelf)) stop("Incorrect diagonal kernel length")
	
	Ptest <- NULL
	quadMtd <- con$method == "quadrature"

	pkg <- rpuLoadPackage(rvbmLevel)
	if (pkg == RPUDPLUS) {
		
		N <- nrow(PHItest)
		Ntest <- ncol(PHItest)
		
		cret <- .C("rvbmPredict",
				as.rpuNumeric   (cholPHI),
				as.rpuNumeric   (PHItest),
				as.rpuNumeric   (PHItestSelf),
				as.rpuNumeric   (Y),
				as.integer   	(N),
				as.integer      (Ntest),
				as.integer      (Kc),
				
				as.rpuNumeric   (UQP$nodes),
				as.rpuNumeric   (UQP$weights),
				as.integer      (length(UQP$weights)),
				as.integer		(quadMtd),
				
				Res = rpuNumeric(Ntest*Kc),
				PACKAGE = pkg)
		
		Res <- matrix(cret$Res, nrow=Ntest, ncol=Kc)
		Ptest <- if (quadMtd) Res else .genCPP.classic(Res, UQP)
		
	} else {
		
		LT <- backsolve(cholPHI, PHItest, transpose=TRUE)
		LY <- backsolve(cholPHI, Y, transpose=TRUE)
		
		Res <- t(LT)%*%LY
		S <- PHItestSelf - colSums(LT*LT)
		
		Res <- Res / sqrt(1 + S)
		Ptest <- if (quadMtd) .genCPP.quad(Res, UQP) else .genCPP.classic(Res, UQP)
	}
		
	Ptest		
}


`.distSqrd` <-
function (X,Y) {
	nx <- nrow(X);	ny <- nrow(Y)
	abs(rowSums(X^2)%o%rep(1, ny) + rep(1, nx)%o%rowSums(Y^2) - 2*(X%*%t(Y)))
}


`.gaussQuad` <-
function(n) {
# Code developed by Gordon Smyth  <smyth@wehi.edu.au>
#
# Calculate nodes and weights for Guassian quadrature using probability densities.
# Adapted from Netlib routine gaussq.f
# Gordon Smyth, Walter and Eliza Hall Institute
# Corrections for n=1 and n=2 by Spencer Graves, 28 Dec 2005
# 4 Sept 2002. Last modified 4 Jan 2005.
	
	mu <- 0; sigma <- 1
	n  <- as.integer(n)
	i  <- 1:n
	i1 <- 1:(n-1)
	a  <- rep(0,n)
	b  <- sqrt(i1/2)
	A  <- rep(0,n*n)
	A[(n+1)*(i-1)+1]  <- a
	A[(n+1)*(i1-1)+2] <- b
	A[(n+1)*i1]       <- b
	dim(A) <- c(n,n)
	vd <- eigen(A,symmetric=TRUE)
	w <- rev(as.vector( vd$vectors[1,] ))^2
	x <- rev( vd$values )
	x <- mu + sqrt(2)*sigma*x
	list(nodes=x,weights=w)
}


`.genCPP.classic` <-
function(Res, UQP) {

	Nsamps <- length(UQP$nodes)
	Ntest <- nrow(Res)
	Kc <- ncol(Res)
	
	Ptest  <- matrix(1, nrow=Ntest, ncol=Kc)
	u      <- rnorm(Nsamps)
	for (n in 1:Ntest) {
		for (i in 1:Kc) {
			pp <- rep(1, Nsamps)
			for (j in ((1:Kc)[-i])) {
				pp <- pp * .safeNormCDF(u + (Res[n, i] - Res[n, j]))
			}
			Ptest[n, i] <- mean(pp)
		}
	}
	t(apply(Ptest, 1, function(x) {x/sum(x)})) ## JUST IN CASE
}


`.genCPP.quad` <-
function(Res, UQP) {

	Kc <- ncol(Res)
	
	Ptest <- t(apply(Res,1, 
					
		function(Res.n) {
			Ptest.n <- rep(0,Kc)
			for (i in 1:Kc) {
				
				Res.i <- UQP$nodes + Res.n[i]
				pp    <- UQP$weights * apply(
							sapply(Res.n[-i], 
								function(vb) 
									.safeNormCDF(Res.i - vb)
								), 
							1, prod)
				Ptest.n[i] <- sum(pp)
			}
			Ptest.n
		}
	))
	t(apply(Ptest, 1, function(x) {x/sum(x)})) ## JUST IN CASE
}



`.covParams` <-
function(obj) {
	obj$THETA[nrow(obj$THETA),]
}


`.predClass` <-
function(obj) {
	as.numeric(apply(obj$Ptest, 1, which.max))
}


`.predLik` <-
function(obj) {
	obj$PL[length(obj$PL)]
}


`.predError` <-
function(obj) {
	obj$testErr[length(obj$testErr)]/100
}


`.printTrace` <-
function(mystr, sFile, InfoLevel, bAppend=TRUE, bStop=FALSE) {
	if (InfoLevel > 0) {
		if (length(sFile) > 0) {
			cat(mystr, file=sFile, sep="\n", 
					fill=TRUE, labels=NULL, append=bAppend)
		} else cat(mystr, sep="\n")
		
		flush.console()
		if (bStop) stop(mystr)
	}
}


`.safeLimit` <-
function(x, lower, upper) {
	x[x < lower] <- lower
	x[x > upper] <- upper
	return (x)
}


`.safeLog` <-
function(x) {
	G.THRESH.LOG <-  1e+200       ## threshold used to avoid numerical problem
	log(.safeLimit(x, 1/G.THRESH.LOG, G.THRESH.LOG))
}


`.safeLogDet` <-
function(x) {
	.safeLog(det(x))  # 2*sum(safeLog(diag(chol(x))))
}


`.safeNormCDF` <-
function(x) {
	G.THRESH.NORM.CDF <-  10     ## threshold used to avoid numerical problem
	pnorm(.safeLimit(x, -G.THRESH.NORM.CDF, G.THRESH.NORM.CDF))
}


`.safeNormPDF` <-
function(x) {
	G.THRESH.NORM.PDF <-  35     ## threshold used to avoid numerical problem
	dnorm(.safeLimit(x, -G.THRESH.NORM.PDF, G.THRESH.NORM.PDF))
}


`.tmean.quad` <-
function(m, indexMax, Nsamps, UQP) {
## This function computes the mean of the truncated Gaussian as detailed in
## the paper equations (5) & (6).

	Kc <- length(m);
	t.class   <- rep(m[indexMax], Kc) - m;
	tr.class  <- t.class;
	t.class   <- t.class[-indexMax];
	## s ( Nsamps x Kc-1 )
	s  <- matrix(rep(UQP$nodes, Kc-1),byrow=F, nrow=Nsamps, ncol=Kc-1) +
			t(matrix(rep(t.class, Nsamps), byrow=F, ncol=Nsamps));
	if (is.null(dim(s)) || ncol(s) == 1 || nrow(s) == 1) {
		z <- sum(.safeNormCDF(as.numeric(s))*UQP$weights);
	} else {
		z <- sum(as.numeric(apply(.safeNormCDF(s), 1, prod))*UQP$weights);
	}
	
	sr0 <- matrix(rep(UQP$nodes, Kc), byrow=F, nrow=Nsamps) +
			t(matrix(rep(tr.class,Nsamps), byrow=F, ncol=Nsamps));
	if (Kc > 2) {
		tm <- rep(NA, Kc);
		for (r in 1:Kc) {
			if (r == indexMax) {
				tm[r] <- 0
			} else {
				## sr ( Nsamps x Kc )
				sr <- sr0[, -c(r, indexMax)];
				if (is.null(dim(sr)) || ncol(sr) == 1 || nrow(sr) == 1) {
					snr <- as.numeric(.safeNormCDF(sr));
				} else {
					snr <- as.numeric(apply(.safeNormCDF(sr), 1, prod));
				}
				nr <- sum(UQP$weights*.safeNormPDF(UQP$nodes + m[indexMax] - m[r]) * snr );
				tm[r] <- m[r] - nr/z;
			}
		}
		tm[indexMax] <- sum(m) - sum(tm);
	} else {
		stop('Multinomial only code !!!');
	}
	structure(list(tm=tm, z=z),	class="tmean.obj");
}


`.varphiUpdate` <-
function(X, Mt, psi, con) {
# This computes the posterior mean of the covariance hyperparameters
# using a simple importance sampler
	
	nSamps <- con$nSampsIS
	W <- numeric(nSamps)
	
	nPsi <- length(psi)
	varphi <- numeric(nPsi)
	
	if (nPsi != ncol(X)) 
		stop("The number of theta parameters must be equal to the number of covariates")
	
	pkg <- rpuLoadPackage(rvbmLevel)
	if (pkg == RPUDPLUS) {
		
		expnDist <- rexp(nSamps*nPsi)/psi
		
		kapper <- rpuNumeric(2)
		kapper[1] <- con$kDegree
		kapper[2] <- con$kCoef0
		
		cret <- .C("rvbmAutoRelDet",
				as.rpuNumeric   (X),
				as.rpuNumeric   (Mt),
				as.integer      (nrow(X)),	# N
				as.integer      (ncol(X)),	# Kd
				as.integer      (ncol(Mt)),	# Kc
				
				as.rpuNumeric	(expnDist),
				as.integer      (nSamps),
				
				as.rpuNumeric	(kapper),
				as.integer(length(kapper)),
				con$kName, 
				
				varphi = rpuNumeric(nPsi),
				PACKAGE = pkg)
		varphi <- cret$varphi
		
	} else {
		
		V <- matrix(0, nSamps, nPsi)
		n <- rep(1, nPsi)
		In <- diag(1, nrow(X))
		for (i in 1:nSamps) {
			V[i,] <- varphi <- rexp(n, rate=psi)

			PHI <- .computeKernel(X, NULL, varphi, con) + In
			cholPHI <- chol(PHI)    # missing rpudplus

			LM <- backsolve(cholPHI, Mt, transpose=TRUE)
			W[i] <- exp(-0.5*sum(LM*LM))
		}
		
		varphi <- W%*%V/sum(W)
	}
	
	varphi
}

