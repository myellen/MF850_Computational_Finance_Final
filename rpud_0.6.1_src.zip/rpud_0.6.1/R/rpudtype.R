#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##

`rpuNumeric` <- function(x) {
	double(x)
}

`as.rpuNumeric` <- function(x) {
	as.double(x)
}




