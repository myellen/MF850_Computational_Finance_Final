#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##


#####################################################################
# rpudl
#
rpudlLevel <- 0x60

`rpudl` <-
function (
    model.file,
    data.source,
    ...,
    log.level = 1
) UseMethod ("rpudl")

`rpudl.default` <-
function (
	model.file,
	data.source,
    ...,
    log.level = 1
) {

    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rpudl methods")
    
	ds <- data.source
	if (!inherits(ds, "rpudl.data.source")) 
		stop("invalid rpudl data source object")
	
	if (missing(model.file) || is.null(model.file)) 
		stop("missing model definition file argument")
	fz <- file.info(model.file)
	model.spec <- readChar(model.file, fz$size)
	
	data.format <- ds$data.format
	if (is.null(data.format)) stop("missing data format")
	
	data.dir <- ds$data.dir
	if (is.null(data.dir)) stop("missing data directory")
	
	train.data <- ds$train.data
	if (is.null(train.data)) train.data <- ""
	
	test.data <- ds$test.data
	if (is.null(test.data)) test.data <- ""
	
	shape <- ds$data.shape
	if (is.null(shape)) shape <- c(1, 1)
	if (length(shape) != 2) stop("invalid data shape dimensions")
	
	channels <- ds$data.channels
	if (is.null(channels)) channels <- 1
    
	# create model
	ret <- .C("rpudlCreateModel",
			as.character(model.spec),
            
			as.character(data.format),
			as.character(data.dir),
            
			as.integer(shape),
			as.integer(channels),
            
			param.data.length = integer(1),
			classes = integer(1),
            
			mean.data = single(as.integer(prod(shape)*channels)),
            
            as.integer(log.level),
            PACKAGE=pkg
	)
	
	obj <- list(
            model.file  = model.file,
            model.spec  = model.spec,
            
            data.format = data.format,
            data.dir    = data.dir,
            
            data.shape  = shape,
            data.channels = channels,
            
            train.data  = train.data,
            test.data   = test.data,
            
            param.data   = single(ret$param.data.length),
            mean.data    = ret$mean.data, 
            model.classes = ret$classes,
            
            learning.rate = 0,
            iter        = 0,
            pretrain    = FALSE,
            
            cost.log    = single(0),
            cost        = NaN,
            loss        = NaN
    )
	structure(obj, class="rpudl")
}


#####################################################################
# rpudlTrain
#
`rpudlTrain` <-
function (
	model,
	learning.rate = 0,
	batch.size = 128,
	iterations = 128,
	display = 100,
	top.n = 1,
	seed = 0,
	...,
	log.level = 1
) {
		
    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for train.rpudl")
    
    if (!inherits(model, "rpudl")) 
		stop("invalid rpudl model object")
	
	if (is.null(model$iter)) model$iter <- 0
	if (!display) stop("invalid training progress display")
	
	if (model$pretrain) {
		model$pretrain <- FALSE
		model$iter <- 0	# start over
	}
    model$learning.rate <- learning.rate
    
	# train model
	ret <- .C("rpudlTrainModel",
			as.character(model$model.spec),
            
			as.character(model$data.format),
            as.character(model$data.dir),
            
			as.integer(model$data.shape),
			as.integer(model$data.channels),
			
			as.character(model$train.data),
			as.character(model$test.data),
            
			param.data = as.single(model$param.data),
			length(model$param.data),
            
			mean.data = as.single(model$mean.data),
			length(model$mean.data),
            
			as.integer(model$iter),
			as.integer(iterations),
			as.integer(display),
			
			as.integer(batch.size),
			as.single(learning.rate),
            
            as.integer(top.n),
            
			cost.log = single(as.integer(iterations)),
			loss = single(1),
            
            as.integer(seed),
            as.integer(log.level),
            
            PACKAGE=pkg
	)
			
	
	model$param.data <- ret$param.data 
	model$mean.data  <- ret$mean.data 
	model$iter       <- model$iter + as.integer(iterations)
	model$loss       <- ret$loss
	
	cost.log <- c(model$cost.log, ret$cost.log)
	model$cost.log   <- cost.log
	model$cost       <- sum(cost.log)/length(cost.log)
	
	if (log.level > 0)
		message(sprintf("\ntraining ends with average cost of %g, and accuracy %g%%",
						model$cost, 100*(1 - ret$loss)))
	model
}


#####################################################################
# rpudlPretrain
#
`rpudlPretrain` <-
function (
	model,
	learning.rate = 0,
	batch.size = 128,
	iterations = 128,
	display = 100,
	seed = 0,
	...,
	log.level = 1
) {

    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for pretrain.rpudl")
    
    if (!inherits(model, "rpudl")) 
		stop("invalid rpudl model object")
	
	if (is.null(model$iter)) model$iter <- 0
	if (!display) stop("invalid pre-train progress display interval")
	
	if (!model$pretrain) {
		model$pretrain <- TRUE
		model$iter <- 0	# start over
	}
	
	# pretrain model
	ret <- .C("rpudlPretrainModel",
			as.character(model$model.spec),
            
			as.character(model$data.format),
            as.character(model$data.dir),
            
			as.integer(model$data.shape),
			as.integer(model$data.channels),
            
			as.character(model$train.data),
			as.character(model$test.data),
            
			param.data = as.single(model$param.data),
			length(model$param.data),
            
			mean.data = as.single(model$mean.data),
			length(model$mean.data),
            
			as.integer(model$iter),
			as.integer(iterations),
			as.integer(display),
            
			as.integer(batch.size),
			as.single(learning.rate),			
			
			as.integer(seed),
			as.integer(log.level),
            
			PACKAGE=pkg
	)
	
	model$param.data <- ret$param.data
	model$mean.data  <- ret$mean.data
	model$iter <- model$iter + iterations
	
	model
}


#####################################################################
# predict.rpudl
#
`predict.rpudl` <-
function (
	model,
	x,
	...,
	log.level = 1
) {
	
    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for predict.rpudl")
    
    if (!inherits(model, "rpudl")) 
		stop("invalid rpudl model object")
	
	if (!is.matrix(x))
		stop("input data fails to be a matrix")
	
	reclen <- nrow(x)
	num    <- ncol(x)
	#message("reclen=", reclen, ", num=", num)
	
	shape <- model$data.shape
	channels <- model$data.channels
	#message("shape=(", toString(shape), "), channels=", channels)
	
	if (reclen != prod(shape)*channels)
		stop("input data dimension is incompatible with model")
	
	classes <- model$model.classes
	if (as.integer(classes) <= 0)
		stop("invalid model output classes")
	
    # predict
    ret <- .C("rpudlPredict",
			as.character(model$model.spec),
            
			as.integer(shape),
			as.integer(channels),
            
			param.data = as.single(model$param.data),
			length(model$param.data),
            
			mean.data = as.single(model$mean.data),
			length(model$mean.data),
            
			as.integer(classes),
			as.integer(num),
			
			x = as.raw(x),
			y = single(classes * num),
			
			as.integer(log.level),            
			PACKAGE=pkg
	)
	val <- matrix(ret$y, nrow=classes, ncol=num)
	res <- apply(val, 2, which.max)
	
	attr(res, "decision.values") <- val
	res
}


#####################################################################
# rpudlGetLayerWeights
#
`rpudlGetLayerWeights` <-
function (
	model,
	layer.name
) {

    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rpudl.weights")
    
    if (!inherits(model, "rpudl")) 
		stop("invalid rpudl model object")
		
	# layer weight params
	ret <- .C("rpudlLayerWeights",
			as.character(layer.name),
            
			as.character(model$model.spec),
			as.character(model$data.format),
            
			as.integer(model$data.shape),
			as.integer(model$data.channels),
            
			wt.dim = integer(4),
			wt.offset = integer(1),
            
			PACKAGE=pkg
			)
			
	wt.dim <- ret$wt.dim
	wt.beg <- ret$wt.offset + 1
	wt.end <- wt.beg + prod(wt.dim) - 1
	
	wt <- model$param.data[wt.beg:wt.end]
	dim(wt) <- wt.dim
    class(wt) <- c(class(wt), "rpudl.weights")
	
	wt
}


#####################################################################
# rpudlPlotLayerWeights
#
`rpudlPlotLayerWeights` <-
function (
	obj
) {
    
    if (!inherits(obj, "array") || !inherits(obj, "rpudl.weights"))
        stop("invalid rpudl weights object")
	
	dims <- dim(obj)
	if (length(dims) != 4 || any(dims <= 0))
		stop("invalid weights array dimensions")
	
	fx <- dims[1]
	fy <- dims[2]
	if (fx <= 1 || fy <=1) 
		stop("two dimensional input expected")
	
	inchn  <- dims[3]
	if (inchn == 1)	
		return (.rpudlPlot1dWeights(obj, fx, fy))
	
	if (inchn == 3)	
		return (.rpudlPlot3dWeights(obj, fx, fy))
	
	stop("only 1 or 3 dimensional input channels are supported")
}


`.rpudlNormalizeValues` <- 
function(x) {

	interval <- range(x)
	lower <- interval[1]
	upper <- interval[2]
	
	if (lower == upper) 
		return (rep(0, length(x)))
	
	return ((x-lower)/(upper-lower))
}


`.rpudlPlot1dWeights` <-
function (
	obj,
	fx,
	fy
) {
	
	len <- length(obj)
	f2 <- fx*fy
	n <- len/f2
	
	x <- rep(1:fx, len/fx)
	y <- rep(1:fy, each=fx, n)
	z <- rep(1:n, each=f2)
	
	w <- .rpudlNormalizeValues(c(obj))
	data <- data.frame(x, y, z, w)
	
	library(ggplot2)
	ggplot(data=data) +
			geom_raster(aes(x=x, y=y, fill=w)) +
			facet_wrap(~z) +
			scale_fill_continuous(low='white',high='black') +
			labs(x=NULL, y=NULL)
}


`.rpudlPlot3dWeights` <-
function (
	obj,
	fx,
	fy
) {
	
	len <- length(obj)/3
	f2 <- fx*fy
	n <- len/f2
	
	x <- rep(1:fx, len/fx)
	y <- rep(1:fy, each=fx, n)
	z <- rep(1:n, each=f2)
	
	r <- .rpudlNormalizeValues(obj[ , , 1, ])
	g <- .rpudlNormalizeValues(obj[ , , 2, ])
	b <- .rpudlNormalizeValues(obj[ , , 3, ])
	data <- data.frame(x, y, z, r, g, b)
	
	library(ggplot2)
	ggplot(data=data) +
			geom_raster(aes(x=x, y=y, fill=rgb(r,g,b))) +
			facet_wrap(~z) + 
			scale_fill_identity() +
			labs(x=NULL, y=NULL)
}

	

#####################################################################
# rpudl
#
`print.rpudl` <-
function (obj, ...) {
	
#	if (!inherits(obj, "rpudl"))	
#		stop("invalid model object type")
	
	cat("\n")
	cat("  model file: '", obj$model.file, "'\n", sep="")
	
	cat("\n")
	cat("  data format:", obj$data.format, "\n")
	cat("  input dimensions: (", toString(obj$data.shape), ")\n", sep="")
	cat("  input channels:", obj$data.channels, "\n")
	cat("  output classes:", obj$model.classes, "\n")
	
	cat("\n")
	if (obj$learning.rate > 0)
		cat("  learning rate:", obj$learning.rate, "\n")
	
	if (!is.nan(obj$cost))
		cat("  model cost:", obj$cost, "\n")
	
	if (!is.nan(obj$loss))
		cat("  test loss: ", obj$loss * 100, "%\n", sep="")
	
	cat("\n\n")
}


#####################################################################
# summary
#
`summary.rpudl` <-
function (obj, ...)
	structure(obj, class="summary.rpudl")


`print.summary.rpudl` <-
function (obj, ...) {
	
	print.rpudl(obj)
}


