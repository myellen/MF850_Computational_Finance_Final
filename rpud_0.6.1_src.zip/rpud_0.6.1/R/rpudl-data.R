#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##


#####################################################################
# mnist data spec
#
MNIST_WIDTH <- 28
MNIST_CHANNELS <- 1

MNIST_TRAIN_IMAGES <- "train-images-idx3-ubyte"
MNIST_TRAIN_LABELS <- "train-labels-idx1-ubyte"

MNIST_TEST_IMAGES <- "t10k-images-idx3-ubyte"
MNIST_TEST_LABELS <- "t10k-labels-idx1-ubyte"


#####################################################################
# cifar data spec
#
CIFAR_WIDTH <- 32
CIFAR_CHANNELS <- 3

CIFAR10_DATA <- "cifar-10-binary.tar.gz"
CIFAR10_DIR  <- "cifar-10-batches-bin"

CIFAR100_DATA <- "cifar-100-binary.tar.gz"
CIFAR100_DIR  <- "cifar-100-binary"


#####################################################################
# data download
#
`rpudlCreateDataSource` <- 
function(
        data.format = c("lmdb", "cifar10", "cifar100", "minst"),
		data.dir,
		data.shape = NULL,
		data.channels = 1,
		train.data = NULL,
		test.data = NULL,
		url = NULL
) {
		
	if (!dir.exists(data.dir)) 
		dir.create(data.dir, recursive=TRUE)

	classNames <- c(
		"lmdb",
		"mnist",
		"cifar10",
		"cifar100"
		)
	data.format <- match.arg(data.format, classNames)
	
	# data.dir
	data.dir <- if (data.format == "mnist")
		.rpudlDownloadMnist(data.dir, url)
	else if (data.format == "cifar10")
		.rpudlDownloadCifar(data.dir, url, FALSE)
	else if (data.format == "cifar100")
		.rpudlDownloadCifar(data.dir, url, TRUE)	
	else data.dir

	# data.shape
	data.shape <- if (data.format == "mnist")
		c(MNIST_WIDTH, MNIST_WIDTH)
	else if (substr(data.format, 1, 7) == "cifar10")
		c(CIFAR_WIDTH, CIFAR_WIDTH)
	else data.shape

	if (is.null(data.shape) || length(data.shape) != 2 ||
			data.shape[1] <= 0 || data.shape[2] <= 0) 
		stop("invalid data source dimensions")

	# data.channels
	data.channels <- if (data.format == "mnist") 1
		else if (substr(data.format, 1, 7) == "cifar10") 3 
		else data.channels

	if (is.null(data.channels) || length(data.channels) != 1 || 
			data.channels[1] <= 0) 
		stop("invalid data source channels")

	# obj
	obj <- list()
	obj$data.format    <- data.format
	obj$data.dir       <- data.dir
	obj$data.shape     <- data.shape
	obj$data.channels  <- data.channels
	obj$train.data     <- if (is.null(train.data)) "" else train.data 
	obj$test.data      <- if (is.null(test.data)) "" else test.data
	
	structure(obj, class="rpudl.data.source")
}


#####################################################################
# download archives
#
`.rpudlDownloadMnist` <- 
		function(
				data.dir,
				url
) {
	
	MNIST_URL <- "http://yann.lecun.com/exdb/mnist"
	if (is.null(url)) url <- MNIST_URL  
	
	.rpudlDownloadArchive(data.dir, MNIST_TRAIN_IMAGES, url)
	.rpudlDownloadArchive(data.dir, MNIST_TRAIN_LABELS, url)
	.rpudlDownloadArchive(data.dir, MNIST_TEST_IMAGES, url)
	.rpudlDownloadArchive(data.dir, MNIST_TEST_LABELS, url)
	
	data.dir
}


`.rpudlDownloadCifar` <- 
		function(
				data.dir,
				url,
				cifar100
) {
	
	CIFAR_URL <- "https://www.cs.toronto.edu/~kriz"
	if (is.null(url)) url <- CIFAR_URL  
	
	filename <- if (cifar100) CIFAR100_DATA else CIFAR10_DATA 
	tarfile <- .rpudlDownloadFile(data.dir, filename, url)
	untar(tarfile, exdir=data.dir, compressed="gzip")
	
	dirname <- if (cifar100) CIFAR100_DIR else CIFAR10_DIR 
	file.path(data.dir, dirname)
}


`.rpudlDownloadArchive` <- 
function(
	data.dir,
	filename,
	url
) {
	
	dst <- file.path(data.dir, filename)
	if (!file.exists(dst)) {
		
		# download gzfile
		src <- .rpudlDownloadFile(
				data.dir, 
				paste(filename, ".gz", sep=""), 
				url)
		
		# extract
		infile <- gzfile(src, "rb")
		outfile <- file(dst, "wb")
		
		repeat {
			bytes <- readBin(con=infile, raw(), size=1L, n=1e06)
			if (length(bytes))
				writeBin(bytes, con=outfile, size=1L)
			else
				break
		}
		
		close(infile)
		close(outfile)
	}
	
	return (dst)
}


`.rpudlDownloadFile` <- 
function(
	data.dir,
	filename,
	url
) {
	
	dst <- file.path(data.dir, filename)
	if (!file.exists(dst)) {
		message("downloading ", filename, " ...")
		download.file(file.path(url, filename), dst)
	}
	dst
}


#####################################################################
# LMDB 
#
`rpudlWriteLMDB` <- 
function(
    data.source,
    prefix = "rpudl",
    ...,
    log.level = 1
) {
    
    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rpudl.create.lmdb")
    
    ds <- data.source
    if (!inherits(ds, "rpudl.data.source")) 
        stop("invalid rpudl data source object")
    
    prefix <- file.path(ds$data.dir, prefix)
    
    train.lmdb.dir <- paste(prefix, "_train_lmdb", sep="")
    if (dir.exists(train.lmdb.dir))
        stop(sprintf("train data directory %s already exists", train.lmdb.dir));
    
    test.lmdb.dir <- paste(prefix, "_test_lmdb", sep="")
    if (dir.exists(test.lmdb.dir))
        stop(sprintf("test data directory %s already exists", test.lmdb.dir));
    
    ret <- .C("rpudlCreateLmdb",
            as.character(ds$data.format),
            as.character(ds$data.dir),
            
            as.integer(ds$data.shape),
            as.integer(ds$data.channels),
            
            as.character(ds$train.data),
            as.character(ds$test.data),
            
            as.character(train.lmdb.dir),
            as.character(test.lmdb.dir),
            
            as.integer(log.level),
            PACKAGE=pkg
    )
    
    invisible(ret)
}


#####################################################################
# train data mean 
#
`rpudlFindTrainingDataMean` <- 
function(
    data.source,
    filename = "data.mean",
    ...,
    log.level = 1
) {
    
    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rpudl.data.mean")
    
    ds <- data.source
    if (!inherits(ds, "rpudl.data.source")) 
        stop("invalid rpudl data source object")
    
    ret <- .C("rpudlTrainDataMean",
        as.character(ds$data.format),
        as.character(ds$data.dir),
        
        as.integer(ds$data.shape),
        as.integer(ds$data.channels),
        
        as.character(ds$train.data),
        as.character(ds$test.data),
        
        as.character(file.path(ds$data.dir, filename)),
        
        as.integer(log.level),
        PACKAGE=pkg
        )
        
    invisible(ret)
}


#####################################################################
# test data samples 
#
`rpudlGetTestingDataSamples` <- 
function(
	data.source,
	data.interval,
    label.offset = 1
) {
    
    pkg <- rpuLoadPackage(rpudlLevel)
    if (pkg != RPUDPLUS) stop("Please install Rpudplus for rpudl.data.sample")
    
	ds <- data.source
	if (!inherits(ds, "rpudl.data.source")) 
		stop("invalid rpudl data source object")
	nrow <- as.integer(prod(ds$data.shape) * ds$data.channels)
	#message("nrow=", nrow)
	
	I <- as.integer(data.interval)
	if (length(I) != 2 || I[1] > I[2] || I[1] <= 0)
		stop("invalid data interval")
	ncol = I[2] - I[1] + 1
	#message("ncol=", ncol)
	
	ret <- .C("rpudlTestDataSample",
				as.character(ds$data.format),
				as.character(ds$data.dir),
				
				as.integer(ds$data.shape),
				as.integer(ds$data.channels),
				
				as.character(ds$train.data),
				as.character(ds$test.data),
				
				I,
                
				x = raw(nrow*ncol),
				y = integer(ncol),
				n = integer(1),
                
				PACKAGE=pkg
				)
	n <- ret$n
	x <- if (n < ncol) ret$x[1:(nrow*n)] else ret$x 
	y <- if (n < ncol) ret$y[1:n] else ret$y 
	
	list(
		x = matrix(x, nrow=nrow, ncol=ncol),
		y = y + label.offset
		)
}


