#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##


#####################################################################
# rpudplus
#
RPUDPLUS <- "rpudplus"
RPUDPLUS_LIB <- "rpudplusLib"

rpudLevel <- 0x10

rpud_050 <- 0x50
rpud_060 <- 0x60


#####################################################################
# rpuLoadPackage
#
`rpuLoadPackage` <-
function(ver) {

    rpudEnvId <- ".rpud"
    rpudplusId <- RPUDPLUS
    rpudplusLibId  <- RPUDPLUS_LIB

    benv <- globalenv()
    rpudEnv <- NULL

    if (exists(rpudEnvId, envir=benv)) {
        rpudEnv <- get(rpudEnvId, envir=benv)
    }

    rpudplus <- ""
    rpudplusLib <- ""
    if (!is.null(rpudEnv) && is.environment(rpudEnv)) {
        rpudplus <- get(rpudplusId, envir=rpudEnv)
        rpudplusLib <- get(rpudplusLibId, envir=rpudEnv)
    }

    if (rpudplusLib == "") {
        basePath <- if (.Platform$OS.type == "windows")
        				"rpudplus/libs/x64/rpudplus.dll"
        			else
        				"rpudplus/libs/rpudplus.so"
		for (s in .libPaths()) {
			s <- file.path(s, basePath)
			if (file.exists(s)) {
				rpudplusLib <- s
				break
			}
		}
    }
	hasRpudplus <- file.exists(rpudplusLib)

	if ((rpudplus != "1" && hasRpudplus) ||
        (rpudplus == "1" && !hasRpudplus) ||
        (rpudplus == "")) {

        # start over, probably should unload any old shared libs
        rpudEnv <- new.env(benv)
        assign(rpudEnvId, rpudEnv, envir=benv)

        if (hasRpudplus) {
            dyn.load(rpudplusLib)
            assign(rpudplusId, 1, envir=rpudEnv)
            assign(rpudplusLibId, rpudplusLib, envir=rpudEnv)

        } else {
            assign(rpudplusId, 0, envir=rpudEnv)
        }
    }

    # read it again the second time
    rpudplus <- get(rpudplusId, envir=rpudEnv)

    # check for rpudplus version
    if (rpudplus == "1") {
        rpinfo <- .C("getModuleInfo",
                    rpinfo = integer(1),
                    PACKAGE = RPUDPLUS)$rpinfo
        if (rpinfo >= ver) {
            return (RPUDPLUS);
        }

        warning(paste(
            "installed version of rpudplus does not support requested function,",
            "switching over to stock routine ..."))
        # falls through
    }

    return ("rpud")
}


#####################################################################
# .onLoad / .onUnload
#
`.onLoad` <-
function(libpath, pkgname) {

    pkg <- rpuLoadPackage(rpud_060)

    if (pkg != RPUDPLUS) {

   	    .C("onLoad", PACKAGE=pkg)

	} else {

        s <- file.path(Sys.getenv("HOME"), "rpudplus.LICENSE")
	    if (!file.exists(s))
            s <- file.path(libpath, "rpudplus/rpudplus.LICENSE")
	    if (!file.exists(s))
            s <- file.path(libpath, "rpud/etc/rpudplus.ini")
        if (!file.exists(s))
            stop("License file not found.")

        .C("onLoadEx",
            text = readChar(s, 8192),
            PACKAGE = pkg)
	}

}


`.onUnload` <-
function(libpath) {

    pkg <- rpuLoadPackage(rpudLevel)
   .C("onUnload", PACKAGE=pkg)
}


#####################################################################
# rpuSetDevice
#
`rpuSetDevice` <-
function(deviceId) {

    pkg <- rpuLoadPackage(rpudLevel)
    .C("setDevice", as.integer(deviceId), PACKAGE = pkg)

    rpuGetDevice()
}


#####################################################################
# rpuGetDevice
#
`rpuGetDevice` <-
function() {

    pkg <- rpuLoadPackage(rpudLevel)
    result <- .C("getDevice",
                    deviceId = integer(1),
                    PACKAGE = pkg)$deviceId
    return (result)
}


#####################################################################
# rpuCountDevices
#
`rpuCountDevices` <-
		function() {

    pkg <- rpuLoadPackage(rpud_050)
	.C("countDevices",
			count = integer(1),
			PACKAGE = pkg)$count
}


#####################################################################
# rpuDist
#
`rpuDist` <-
function(points, method="euclidean", diag=FALSE, upper=FALSE, p=2) {

    pkg <- rpuLoadPackage(rpudLevel)

    methodNames <- c(
            "euclidean",
            "maximum",
            "manhattan",
            "canberra",
            "binary",
            "minkowski")
	method <- match.arg(method, methodNames)

    points <- as.matrix(points)
    num <- nrow(points)
    dm  <- ncol(points)

    d <- .C("rpuDistance",
            method,
            as.single(points),
            as.integer(num),
            as.integer(dm),
            as.single(p),
            d = single((num*(num-1))/2),
			NAOK = TRUE,
			PACKAGE = pkg)$d
    attr(d, "Size")     <- num
    attr(d, "Labels")   <- dimnames(points)[[1L]]
    attr(d, "Diag")     <- diag
    attr(d, "Upper")    <- upper
    attr(d, "method")   <- method
    attr(d, "call")     <- match.call()
    if (method == "minkowski") {
        attr(d, "p")  <- p
    }
    class(d) <- "dist"

    return (d)
}


#####################################################################
# rpuHclust
#
`rpuHclust` <-
function(d, method="complete", members=NULL) {

	pkg <- rpuLoadPackage(rpudLevel)
    if (pkg != RPUDPLUS) {
        return (stats::hclust(d, method, members))
    }

    methodNames <- c(
            "ward",
            "single",
            "complete",
            "average",
            "mcquitty",
            "median",
            "centroid")
	method <- match.arg(method, methodNames)

    n <- as.integer(attr(d, "Size"))
    if (is.null(n))
        stop("invalid dissimilarities")
    if (n < 2)
        stop("must have n >= 2 objects to cluster")

    len <- as.integer(n*(n-1)/2)
    if (length(d) != len)
        (if (length(d) < len) stop
         else warning)("dissimilarities of improper length")

    if (is.null(members))
        members <- rep(1, n)
    else if (length(members) != n)
        stop("invalid length of members")

    hcl <- .C("rpuHclust",
            method,
		    d = as.single(d),
		    num = n,
		    iia = integer(n),
		    iib = integer(n),
  		    order = integer(n),
		    crit = single(n),
		    members = as.single(members),
            PACKAGE = pkg)

    tree <- list(
        merge   = cbind(hcl$iia[1L:(n-1)], hcl$iib[1L:(n-1)]),
		height  = hcl$crit[1L:(n-1)],
		order   = hcl$order,
		labels  = attr(d, "Labels"),
        method  = method,
        call    = match.call(),
        dist.method = attr(d, "method"))
    class(tree) <- "hclust"

    return (tree)
}



