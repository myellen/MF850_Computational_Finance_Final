#####################################################################
##  rpud : An R packge for GPU computing
##  Copyright (C) 2010-2016 Chi Yau. All Rights Reserved.
##
##  Based on svm.R in e1071 (ver 1.6-1)
##
##  This program is free software; you can redistribute it and/or modify
##  it under the terms of the GNU General Public License as published by
##  the Free Software Foundation; version 3 of the License.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, see <http://www.gnu.org/licenses/>.
##

rpusvmLevel <- 0x12

`rpusvm` <-
function (x, ...)
    UseMethod ("rpusvm")


`rpusvm.formula` <-
function (formula, data = NULL, ..., subset, na.action = na.omit, scale = TRUE, verbose = TRUE)
{
	call <- match.call()
	if (!inherits(formula, "formula"))
		stop("method is only for formula objects")
	
	m <- match.call(expand.dots = FALSE)
	if (identical(class(eval.parent(m$data)), "matrix"))
		m$data <- as.data.frame(eval.parent(m$data))
	
	m$... <- NULL
	m$scale <- NULL
	m$verbose <- NULL
	m$na.action <- na.action
	m[[1]] <- as.name("model.frame")
	
	m <- eval(m, parent.frame())
	Terms <- attr(m, "terms")
	attr(Terms, "intercept") <- 0
	x <- model.matrix(Terms, m)
	y <- model.extract(m, "response")
	attr(x, "na.action") <- attr(y, "na.action") <- attr(m, "na.action")
	
	ret <- rpusvm.default (x, y, scale = scale, ..., na.action = na.action, verbose = verbose)
	ret$call <- call
	ret$call[[1]] <- as.name("rpusvm")
	ret$terms <- Terms
	if (!is.null(attr(m, "na.action")))
		ret$na.action <- attr(m, "na.action")
	class(ret) <- c("rpusvm.formula", class(ret))
	return (ret)
}


`rpusvm.default` <-
function (x,
          y           = NULL,
          scale       = TRUE,
          type        = NULL,
          kernel      = "radial",
          degree      = 3,
		  gamma       = if (is.vector(x)) 1 else 1 / ncol(x),
		  coef0       = 0,
          cost        = 1,
          nu          = 0.5,
          class.weights = NULL,
          cachesize   = 100,
          tolerance   = 0.001,
          epsilon     = 0.1,
          shrinking   = TRUE,
          cross       = 0,
          probability = FALSE,
          fitted      = TRUE,
		  seed        = 0,
		  ...,
          subset,
          na.action = na.omit,
		  verbose	= TRUE)
{
	x <- .sparse.csr(x)
    if (sparse <- inherits(x, "matrix.csr"))
        library("SparseM")
	
    xhold   <- if (fitted) x else NA
    x.scale <- y.scale <- NULL
    formula <- inherits(x, "rpusvm.formula")

    ## determine model type
    if (is.null(type)) type <-
        if (is.null(y)) "one-classification"
        else if (is.factor(y)) "C-classification"
        else "eps-regression"

	typeNames <- c(
			"C-classification",
			"nu-classification",
			"one-classification",
			"eps-regression",
			"nu-regression")
	type <- match.arg(type, typeNames)
	type <- pmatch(type, typeNames)-1
	
	kernelNames <- c(
			"linear",
			"polynomial",
			"radial",
			"sigmoid")
	kernel <- match.arg(kernel, kernelNames)
	kernel <- pmatch(kernel, kernelNames)-1
	
    nac <- attr(x, "na.action")

    ## subsetting, and NA handling
    if (sparse) {
        if(!is.null(y)) na.fail(y)
		x <- SparseM::t(SparseM::t(x)) ## make sure that col-indices are sorted
	} else {
        x <- as.matrix(x)

        ## subsetting and na-handling for matrices
        if (!formula) {
            if (!missing(subset)) x <- x[subset,]
            if (is.null(y))
                x <- na.action(x)
            else {
                df <- na.action(data.frame(y, x))
                y <- df[,1]
                x <- as.matrix(df[,-1])
                nac <- attr(df, "na.action")
            }
        }
    }
	
	## further parameter checks
    nr <- nrow(x)
    if (cross > nr)
        stop(sQuote("cross"), " cannot exceed the number of observations!")

    if (!is.vector(y) && !is.factor (y) && type != 2)
        stop("y must be a vector or a factor.")
    if (type != 2 && length(y) != nr)
        stop("x and y don't match.")

    if (cachesize < 1)
        cachesize <- 1

    if (type > 2 && !is.numeric(y))
        stop("Need numeric dependent variable for regression.")

    lev <- NULL
    weightlabels <- NULL

    ## in case of classification: transform factors into integers
    if (type == 2) # one class classification --> set dummy
        y <- rep(1, nr)
    else
        if (is.factor(y)) {
            lev <- levels(y)
            y <- as.integer(y)
            if (!is.null(class.weights)) {
                if (is.null(names(class.weights)))
                    stop("Weights have to be specified along with their according level names !")
                weightlabels <- match (names(class.weights), lev)
                if (any(is.na(weightlabels)))
                    stop("At least one level name is missing or misspelled.")
            }
        } else {
            if (type < 3) {
                if(any(as.integer(y) != y))
                    stop("dependent variable has to be of factor or integer type for classification mode.")
                y <- as.factor(y)
                lev <- levels(y)
                y <- as.integer(y)
            } else lev <- unique(y)
        }
		
	if (is.null(y) || length(y) < nr) {
		stop("missing dependent values for training.")		
	}
	
	if (type <= 2) {
		if (length(scale) == 1) {
			if (is.logical(scale) && scale == TRUE) {
				scale <- c(-1, 1)
			}
		} else if (length(scale) > 2) {
			scale <- scale[1:2]
		}
	}
	
	scale.ret <- rpuScale(x, y, scale) 
	x2 <- scale.ret$x
	y2 <- scale.ret$y
	r2 <- scale.ret$r2
	
    nclass <- 2
    if (type < 2) nclass <- length(lev)

    if (type > 1 && length(class.weights) > 0) {
        class.weights <- NULL
        warning(sQuote("class.weights"), 
				" are set to NULL for regression mode. For classification, use a _factor_ for ", 
				sQuote("y"), ", or specify the correct ", sQuote("type"), " argument.")
    }
	
	## NULL parameters?
	err <- " argument must not be NULL or empty!"
	if (is.null(type)) 		stop(sQuote("type"), err)
	if (is.null(kernel)) 	stop(sQuote("kernel"), err)
	if (is.null(degree)) 	stop(sQuote("degree"), err)
	if (is.null(gamma)) 	stop(sQuote("gamma"), err)
	if (is.null(coef0)) 	stop(sQuote("coef0"), err)
	if (is.null(cost)) 		stop(sQuote("cost"), err)
	if (is.null(nu)) 		stop(sQuote("nu"), err)
	if (is.null(cachesize)) stop(sQuote("cachesize"), err)
	if (is.null(tolerance)) stop(sQuote("tolerance"), err)
	if (is.null(epsilon)) 	stop(sQuote("epsilon"), err)
	if (is.null(shrinking)) stop(sQuote("shrinking"), err)
	if (is.null(cross)) 	stop(sQuote("cross"), err)
	if (is.null(sparse)) 	stop(sQuote("sparse"), err)
	if (is.null(probability)) stop(sQuote("probability"), err)
	if (is.null(seed)) 		stop(sQuote("seed"), err)
	if (is.null(verbose)) 	stop(sQuote("verbose"), err)
	
	pkg <- rpuLoadPackage(rpusvmLevel)
	if (pkg != RPUDPLUS) stop("Please install Rpudplus for rpusvm")
	
	L <- nclass
	L2 <- L * (L - 1)/2
	
	dm  <- ncol(x2)
	num <- nrow(x2)

	# start session
	session.params <- integer(2)
	session.params[1] <- rpusvmLevel
	session.params[2] <- verbose
			
	.C("beginSession",
			param = session.params,
			PACKAGE = pkg)
	
	cret <- .C ("rpuSvmTrain",
		## data
		x        = as.rpuNumeric (if (sparse) x2@ra else t(x2)),
		y        = as.rpuNumeric (y2),
		
		as.integer (dm),		# dim
		as.integer (num),		# num 
		as.integer (sparse),
		
		## sparse index info
		ja       = as.integer (if (sparse) (x2@ja - 1) else 0),
		ia       = as.integer (if (sparse) (x2@ia - 1) else 0),
		
		## parameters
		as.integer (type),
		as.integer (kernel),
		as.integer (degree),
		as.rpuNumeric (gamma),
		as.rpuNumeric (coef0),
		
		as.rpuNumeric (cost),
		as.rpuNumeric (nu),
		as.integer (weightlabels),
		as.rpuNumeric (class.weights),
		as.integer (length (class.weights)),
		
		as.rpuNumeric (tolerance),
		as.rpuNumeric (epsilon),
		
		as.integer (seed),	# random seed
		as.integer (0),		# maxcycles
		as.integer (cachesize),
		as.integer (shrinking),
		
		as.integer (cross),
		as.integer (probability),
		
		## results
		nr       = integer  (1), # nr of support vectors
		index    = integer  (nr),
		
		nclasses = integer  (1),
		nSV      = integer  (L),
		labels   = integer 	(L),
		
		rho      = rpuNumeric   (L2),
		coefs    = rpuNumeric   (num * (L - 1)),
		
		sigma    = rpuNumeric   (1),
		probA    = rpuNumeric   (L2),
		probB    = rpuNumeric   (L2),
		
		cresults = rpuNumeric   (cross),
		ctotal1  = rpuNumeric   (1),
		ctotal2  = rpuNumeric   (1),
		
		PACKAGE = pkg)
		
	# end session
	.C("endSession",
			param = session.params,
			PACKAGE = pkg)
	
	L <- cret$nclasses
	L2 <- L * (L - 1)/2
	
	svLen <- cret$nr
	svIdx <- as.integer(cret$index + 1)
	
    ret <- list (
                 call     = match.call(),
                 type     = type,
                 kernel   = kernel,
                 cost     = cost,
                 degree   = degree,
                 gamma    = gamma,
                 coef0    = coef0,
                 nu       = nu,
                 epsilon  = epsilon,
                 sparse   = sparse,
                 scale    = scale,
				 
                 x.scale  = scale.ret$x.scale,
                 y.scale  = scale.ret$y.scale,
				 x.bound  = scale.ret$x.bound,
				 y.bound  = scale.ret$y.bound,
				 
                 nclasses = L, #number of classes
                 levels   = lev,
                 tot.nSV  = svLen, #total number of sv
                 nSV      = cret$nSV[1:L], #number of SV in diff. classes
                 labels   = cret$labels[1:L], #labels of the SVs.
                 SV       = if (sparse) SparseM::t(SparseM::t(x2[svIdx[1:svLen],]))
                 			else t(t(x2[svIdx[1:svLen],])), #copy of SV
                 index    = svIdx[1:svLen],  #indexes of sv in x
                 ##constants in decision functions
                 rho      = cret$rho[1:L2],
                 ##probabilites
                 compprob = probability,
                 probA    = if (probability) cret$probA[1:L2] else rpuNumeric(0),
                 probB    = if (probability) cret$probB[1:L2] else rpuNumeric(0),
                 sigma    = if (probability) cret$sigma else rpuNumeric(0),
                 ##coefficiants of sv
                 coefs    = if (svLen == 0) NULL else
								t(matrix(cret$coefs[1:((L - 1) * svLen)],
								        nrow = L - 1,
								        byrow = TRUE)),
                 na.action = nac
                 )

    ## cross-validation-results
    if (cross > 0)
        if (type > 2) {
            ret$MSE          <- cret$cresults * r2
            ret$tot.MSE      <- cret$ctotal1 * r2
            ret$scorrcoeff   <- cret$ctotal2;
        } else {
            ret$accuracies   <- cret$cresults;
            ret$tot.accuracy <- cret$ctotal1;
        }

    class (ret) <- "rpusvm"

    if (fitted) {
        ret$fitted <- na.action(predict(ret, xhold,
                                        decision.values = TRUE, verbose = verbose))
        ret$decision.values <- attr(ret$fitted, "decision.values")
        attr(ret$fitted, "decision.values") <- NULL
        if (type > 1) ret$residuals <- y - ret$fitted
    }

    ret
}


`predict.rpusvm` <-
function (object, newdata,
          decision.values = FALSE,
          probability = FALSE,
          ...,
          na.action = na.omit,
		  verbose = TRUE)
{
	if (verbose) message("predict.rpusvm ...");
	
    if (missing(newdata))
        return(fitted(object))

    if (object$tot.nSV < 1)
        stop("Model is empty!")

	newdata <- .sparse.csr(newdata)
   	sparse <- inherits(newdata, "matrix.csr")
    if (object$sparse || sparse)
        library("SparseM")

    act <- NULL
	
    if ((is.vector(newdata) && is.atomic(newdata)))
        newdata <- t(t(newdata))
    if (sparse)
        newdata <- SparseM::t(SparseM::t(newdata))
	
    preprocessed <- !is.null(attr(newdata, "na.action"))
	
	rowns <- rownames(newdata)
	if (is.null(rowns))
		rowns <- 1:nrow(newdata)
	## rowns <- if (!is.null(rownames(newdata)))
	##     rownames(newdata)
	## else
	##     1:nrow(newdata)

    if (!object$sparse) {
        if (inherits(object, "rpusvm.formula")) {
            if(is.null(colnames(newdata)))
                colnames(newdata) <- colnames(object$SV)
            newdata <- na.action(newdata)
            act <- attr(newdata, "na.action")
            newdata <- model.matrix(delete.response(terms(object)),
                                    as.data.frame(newdata))
        }
    }

    if (!is.null(act) && !preprocessed)
        rowns <- rowns[-act]

    if (ncol(object$SV) != ncol(newdata))
        stop (paste("test data does not match model: dim(SV) =",
				ncol(object$SV), ", dim(newdata) =", ncol(newdata)))

	pkg <- rpuLoadPackage(rpusvmLevel)
	if (pkg != RPUDPLUS) stop("Please install Rpudplus for predict.rpusvm")
	
	# start session
	session.params <- integer(2)
	session.params[1] <- rpusvmLevel
	session.params[2] <- verbose
	
	.C("beginSession",
			param = session.params,
			PACKAGE = pkg)
	
	ret <- .C ("rpuSvmPredict",
			## test matrix
			as.rpuNumeric (if (sparse) newdata@ra else t(newdata)),
			as.integer (ncol(newdata)),
			as.integer (nrow(newdata)),
			as.integer (sparse),
			as.integer (if (sparse) (newdata@ja - 1) else 0),
			as.integer (if (sparse) (newdata@ia - 1) else 0),
			
			## model
			as.rpuNumeric (if (object$sparse) object$SV@ra else t(object$SV)),
			as.integer (object$tot.nSV),
			as.integer (object$sparse),
			as.integer (if (object$sparse) (object$SV@ja - 1) else 0),
			as.integer (if (object$sparse) (object$SV@ia - 1) else 0),
			
			as.integer (object$nclasses),
			as.integer (object$nSV),
			as.integer (object$labels),
			
			as.rpuNumeric (object$rho),
			as.rpuNumeric (as.vector(object$coefs)),
			
			as.integer (object$compprob),
			as.rpuNumeric (object$sigma),
			as.rpuNumeric (object$probA),
			as.rpuNumeric (object$probB),
			
			# scale
			as.rpuNumeric(object$x.scale),
			as.rpuNumeric(object$y.scale),
			as.rpuNumeric(object$x.bound),
			as.rpuNumeric(object$y.bound),
			
			## parameters
			as.integer (object$type),
			as.integer (object$kernel),
			as.integer (object$degree),
			as.rpuNumeric (object$gamma),
			as.rpuNumeric (object$coef0),
			
			as.integer (decision.values),
			as.integer (probability),
			
			## decision-values
			ret = rpuNumeric(nrow(newdata)),
			dec = rpuNumeric(nrow(newdata) * object$nclasses * (object$nclasses - 1) / 2),
			prob = rpuNumeric(nrow(newdata) * object$nclasses),
			
			PACKAGE = pkg
			)
			
	# end session
	.C("endSession",
			param = session.params,
			PACKAGE = pkg)
	
	ret2 <- if (is.character(object$levels)) # classification: return factors
				factor (object$levels[ret$ret], levels = object$levels)
			else if (object$type == 2) # one-class-classification: return TRUE/FALSE
				ret$ret == 1
			## else if (any(object$scaled) && !is.null(object$y.scale)) # return raw values, possibly scaled back
			##     ret$ret * object$y.scale$"scaled:scale" + object$y.scale$"scaled:center"
			else
				ret$ret
	
	names(ret2) <- rowns
    ret2 <- napredict(act, ret2)

    if (decision.values) {
        colns = c()
        for (i in 1:(object$nclasses - 1))
            for (j in (i + 1):object$nclasses)
                colns <- c(colns,
                           paste(object$levels[object$labels[i]],
                                 "/", object$levels[object$labels[j]],
                                 sep = ""))
        attr(ret2, "decision.values") <-
            napredict(act,
                      matrix(ret$dec, nrow = nrow(newdata), byrow = TRUE,
                             dimnames = list(rowns, colns)
                             )
                      )
    }

    if (probability && object$type < 2)
        attr(ret2, "probabilities") <-
            napredict(act,
                      matrix(ret$prob, nrow = nrow(newdata), byrow = TRUE,
                             dimnames = list(rowns, object$levels[object$labels])
                             )
                      )

    ret2
}


`print.rpusvm` <-
function (x, ...)
{
    cat("\nCall:", deparse(x$call, 0.8 * getOption("width")), "\n", sep="\n")
    cat("Parameters:\n")
    cat("   SVM-Type: ", c("C-classification",
                           "nu-classification",
                           "one-classification",
                           "eps-regression",
                           "nu-regression")[x$type+1], "\n")
    cat(" SVM-Kernel: ", c("linear",
                           "polynomial",
                           "radial",
                           "sigmoid")[x$kernel+1], "\n")
    if (x$type==0 || x$type==3 || x$type==4)
        cat("       cost: ", x$cost, "\n")
    if (x$kernel==1)
        cat("     degree: ", x$degree, "\n")
    cat("      gamma: ", x$gamma, "\n")
    if (x$kernel==1 || x$kernel==3)
        cat("     coef.0: ", x$coef0, "\n")
    if (x$type==1 || x$type==2 || x$type==4)
        cat("         nu: ", x$nu, "\n")
    if (x$type==3) {
        cat("    epsilon: ", x$epsilon, "\n\n")
        if (x$compprob)
            cat("Sigma: ", x$sigma, "\n\n")
    }

    cat("\nNumber of Support Vectors: ", x$tot.nSV)
    cat("\n\n")

}


`summary.rpusvm` <-
function(object, ...)
    structure(object, class="summary.rpusvm")


`print.summary.rpusvm` <-
function (x, ...)
{
    print.rpusvm(x)
    if (x$type<2) {
        cat(" (", x$nSV, ")\n\n")
        cat("\nNumber of Classes: ", x$nclasses, "\n\n")
        cat("Levels:", if(is.numeric(x$levels)) "(as integer)", "\n", x$levels)
    }
    cat("\n\n")
    if (x$type==2) cat("\nNumber of Classes: 1\n\n\n")

    if ("MSE" %in% names(x)) {
        cat(length (x$MSE), "-fold cross-validation on training data:\n\n", sep="")
        cat("Total Mean Squared Error:", x$tot.MSE, "\n")
        cat("Squared Correlation Coefficient:", x$scorrcoef, "\n")
        cat("Mean Squared Errors:\n", x$MSE, "\n\n")
    }
    if ("accuracies" %in% names(x)) {
        cat(length (x$accuracies), "-fold cross-validation on training data:\n\n", sep="")
        cat("Total Accuracy:", x$tot.accuracy, "\n")
        cat("Single Accuracies:\n", x$accuracies, "\n\n")
    }
    cat("\n\n")
}


`plot.rpusvm` <-
function(x, data, formula = NULL, fill = TRUE,
         grid = 50, slice = list(), symbolPalette = palette(),
         svSymbol = "x", dataSymbol = "o", ...)
{
    if (x$type < 3) {
        if (is.null(formula) && ncol(data) == 3) {
            formula <- formula(delete.response(terms(x)))
            formula[2:3] <- formula[[2]][2:3]
        }
        if (is.null(formula))
            stop("missing formula.")
        if (fill) {
            sub <- model.frame(formula, data)
            xr <- seq(min(sub[, 2]), max(sub[, 2]), length = grid)
            yr <- seq(min(sub[, 1]), max(sub[, 1]), length = grid)
            l <- length(slice)
            if (l < ncol(data) - 3) {
                slnames <- names(slice)
                slice <- c(slice, rep(list(0), ncol(data) - 3 -
                                      l))
                names <- labels(delete.response(terms(x)))
                names(slice) <- c(slnames, names[!names %in%
                                                 c(colnames(sub), slnames)])
            }
            for (i in names(which(sapply(data, is.factor))))
                if (!is.factor(slice[[i]])) {
                    levs <- levels(data[[i]])
                    lev <- if (is.character(slice[[i]])) slice[[i]] else levs[1]
                    fac <- factor(lev, levels = levs)
                    if (is.na(fac))
                        stop(paste("Level", dQuote(lev), "could not be found in factor", sQuote(i)))
                    slice[[i]] <- fac
                }

            lis <- c(list(yr), list(xr), slice)
            names(lis)[1:2] <- colnames(sub)
            new <- expand.grid(lis)[, labels(terms(x))]
            preds <- predict(x, new)
            filled.contour(xr, yr, matrix(as.numeric(preds), nrow = length(xr), byrow = TRUE),
                           plot.axes = {
                               axis(1)
                               axis(2)
                               colind <- as.numeric(model.response(model.frame(x, data)))
                               dat1 <- data[-x$index,]
                               dat2 <- data[x$index,]
                               coltmp1 <- symbolPalette[colind[-x$index]]
                               coltmp2 <- symbolPalette[colind[x$index]]
                               points(formula, data = dat1, pch = dataSymbol, col = coltmp1)
                               points(formula, data = dat2, pch = svSymbol, col = coltmp2)
                           },
                           levels = 1:(length(levels(preds)) + 1),
                           key.axes = axis(4, 1:(length(levels(preds))) + 0.5,
                           labels = levels(preds),
                           las = 3),
                           plot.title = title(main = "SVM classification plot",
                           xlab = names(lis)[2], ylab = names(lis)[1]),
                           ...)
        }
        else {
            plot(formula, data = data, type = "n", ...)
            colind <- as.numeric(model.response(model.frame(x,
                                                            data)))
            dat1 <- data[-x$index,]
            dat2 <- data[x$index,]
            coltmp1 <- symbolPalette[colind[-x$index]]
            coltmp2 <- symbolPalette[colind[x$index]]
            points(formula, data = dat1, pch = dataSymbol, col = coltmp1)
            points(formula, data = dat2, pch = svSymbol, col = coltmp2)
            invisible()
        }
    }
}


`write.rpusvm` <-
function (object, rpusvm.file="Rdata.rpusvm")
{

	pkg <- rpuLoadPackage(rpusvmLevel)
	if (pkg != RPUDPLUS) stop("Please install Rpudplus for write.rpusvm")
		
	ret <- .C ("rpuSvmSave",
			## model
			as.rpuNumeric (if (object$sparse) object$SV@ra else t(object$SV)),
			as.integer (ncol(object$SV)),
			as.integer (nrow(object$SV)),
			as.integer (object$sparse),
			as.integer (if (object$sparse) (object$SV@ja - 1) else 0),
			as.integer (if (object$sparse) (object$SV@ia - 1) else 0),
			
			as.integer (object$nclasses),
			as.integer (object$nSV),
			as.integer (object$labels),
			
			as.rpuNumeric (object$rho),
			as.rpuNumeric (as.vector(object$coefs)),
			
			as.integer (object$compprob),
			as.rpuNumeric (object$sigma),
			as.rpuNumeric (object$probA),
			as.rpuNumeric (object$probB),
			
			# scale
			as.rpuNumeric(object$x.scale),
			as.rpuNumeric(object$y.scale),
			as.rpuNumeric(object$x.bound),
			as.rpuNumeric(object$y.bound),
			
			## parameter
			as.integer (object$type),
			as.integer (object$kernel),
			as.integer (object$degree),
			as.rpuNumeric (object$gamma),
			as.rpuNumeric (object$coef0),
			
			## filename
			as.character(rpusvm.file),
			
			PACKAGE = pkg
			)$ret

	ret
}


`read.svm.data` <- 
function(file, fac = TRUE, sparse = TRUE) {

	pkg <- rpuLoadPackage(rpusvmLevel)
	if (pkg != RPUDPLUS) stop("Please install Rpudplus for read.svm.data")
	
	pret <- .C ("rpuSvmPreloadData",
				row 	= integer	(1),
				col 	= integer	(1),
				nnz 	= integer	(1),
				
				as.integer(sparse),
				as.character(file),
				PACKAGE = pkg)
	
	row <- as.integer(pret$row)
	col <- as.integer(pret$col)
	nnz <- as.integer(pret$nnz)
	
	cret <- .C ("rpuSvmLoadData",
				row,
				col,
				nnz, 
			
				ra 		= rpuNumeric 	(nnz),
				y 		= rpuNumeric	(row),
				ja 		= integer		(if (sparse) nnz else 0),
				csr 	= integer		(if (sparse) (row+1) else 0),
				
				as.integer(sparse),
				as.character(file),
				PACKAGE = pkg)
	
	if (sparse) {
		library("SparseM")
		x <- new("matrix.csr",
				ra = as.double(cret$ra),
				ja = as.integer(cret$ja + 1),
				ia = as.integer(cret$csr + 1),
				dimension = c(row, col))
	} else {
		x <- matrix(cret$ra, nrow=row, byrow=TRUE)
	}
	
	y <- cret$y

	list (
		x = x,
		y = if (fac) as.factor(y) else as.numeric(y)
		)

}


`rpuScale` <- 
function(x, y = NULL, scale = TRUE) {
	
	if (is.logical(scale) && length(scale) == 1) {
		
		if (scale == FALSE) {
			return (list(
					x = x,
					y = y,
					x.scale = rpuNumeric(2),
					y.scale = rpuNumeric(2),
					x.bound = rpuNumeric(2),
					y.bound = rpuNumeric(2),
					r2 = 1
					))
			
		} else if (scale == TRUE) {
			scale <- c(-1, 1, -1, 1)		# default scale
		}
	}
	
	x.scale <- NULL 
	y.scale <- NULL
	
	if (is.numeric(scale)) {
		if (length(scale) >= 2) {
			x.scale <- scale[1:2]
		}
		if (length(scale) >= 4 && !is.factor(y) && !is.null(y)) {
			y.scale <- scale[3:4]
		}
	}
	
	if (!is.null(x.scale)) {
		if (x.scale[1] >= x.scale[2]) {
			stop("The lower end of the x-scale cannot be larger than its upper end.")
		}
	}
	
	if (!is.null(y.scale)) {
		if (y.scale[1] >= y.scale[2]) {
			stop("The lower end of the y-scale cannot be larger than its upper end.")
		}
	}
	
	if (is.null(x.scale) && is.null(y.scale)) {
		stop(paste("Unrecognizable scale parameter: ", scale))
	}
	
	x.scale <- as.rpuNumeric (x.scale)
	y.scale <- as.rpuNumeric (y.scale)
	
	x <- .sparse.csr(x)
	sparse <- inherits(x, "matrix.csr")
	if (!sparse && !is.matrix(x)) {
		stop("The x component must be an instrinsic or sparse matrix.")
	} 
	
	dm  <- as.integer(ncol(x))
	num <- as.integer(nrow(x))
	
	if (!is.null(y) && length(y) != num) {
		stop("Mismatched x and y dimensions.")
	}
	
	ra <- as.rpuNumeric (if (sparse) x@ra else t(x))
	ja <- as.integer	(if (sparse) (x@ja - 1) else 0)
	ia <- as.integer	(if (sparse) (x@ia - 1) else 0)
	y1 <- if (!is.null(y.scale)) as.rpuNumeric(y) else rpuNumeric(2)
	
	pkg <- rpuLoadPackage(rpusvmLevel)
	if (pkg != RPUDPLUS) stop("Please install Rpudplus for rpuScale")
	
	x.scale <- if (is.numeric(x.scale) && length(x.scale)==2) x.scale else rpuNumeric(2)
	y.scale <- if (is.numeric(x.scale) && length(y.scale)==2) y.scale else rpuNumeric(2)
	
	cret <- .C ("rpuSvmPrescaleData",
				dm,
				num,
				as.integer(sparse),
				
				## input
				ra       = ra,
				y        = y1,
				ja       = ja,
				ia       = ia,
				
				## output
				nnz      = integer		(1),
				
				x.scale	 = x.scale,
				y.scale	 = y.scale,
				x.bound  = rpuNumeric   (2*dm),
				y.bound  = rpuNumeric   (2),
				
				r2		 = rpuNumeric	(1),
				PACKAGE = pkg)
		
	dim(cret$x.bound) <- c(2, dm)
	dim(cret$y.bound) <- c(2, 1)
	nnz2 <- as.integer(cret$nnz)
	
	cret2 	<- .C ("rpuSvmScaleData",
				dm,
				num,
				as.integer(sparse),
				
				## input
				ra       = ra,
				y        = y1,
				ja       = ja,
				ia       = ia,
				
				## output
				ra2      = rpuNumeric	(nnz2),
				y2       = rpuNumeric	(if (!is.null(y1)) num else 2),
				ja2      = integer		(if (sparse) (nnz2) else 0),
				ia2      = integer		(if (sparse) (num+1) else 0),
				
				x.scale  = x.scale,
				y.scale  = y.scale,
				
				cret$x.bound,
				cret$y.bound,
				PACKAGE = pkg)
		
	if (sparse) {
		library("SparseM")
		x2 <- new("matrix.csr",
				ra = as.double(cret2$ra2),
				ja = as.integer(cret2$ja2 + 1),
				ia = as.integer(cret2$ia2 + 1),
				dimension = c(num, dm))
	} else {
		x2 <- t(matrix(cret2$ra2, nrow=dm))
	}
	
	list (
		x = x2,
		y = if (!is.null(y.scale)) as.numeric(cret2$y2) else y,
		x.scale = x.scale,
		y.scale = y.scale,
		x.bound = cret$x.bound,
		y.bound = cret$y.bound,
		r2 = as.numeric(cret$r2)
		)
	
} 


`.sparse.csr` <- 
function(x) {
	
	if (is.null(x))
		stop("x must not be NULL!")
	
	if(inherits(x, "Matrix")) {
		library("Matrix")
		library("SparseM")
		x <- as(x, "matrix.csr")
	}
	
	if(inherits(x, "simple_triplet_matrix")) {
		library("SparseM")
		ind <- order(x$i, x$j)
		x <- new("matrix.csr",
				ra = x$v[ind],
				ja = x$j[ind],
				ia = as.integer(cumsum(c(1, tabulate(x$i[ind])))),
				dimension = c(x$nrow, x$ncol))
	}
	
	x
}


