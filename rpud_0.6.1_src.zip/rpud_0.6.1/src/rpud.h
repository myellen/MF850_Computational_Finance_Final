////////////////////////////////////////////////////////////////////////
//  rpud : An R package for GPU computing
//  Copyright (C) 2010-2011 Chi Yau. All Rights Reserved.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; version 3 of the License.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#ifndef __RPUD_H__
#define __RPUD_H__

#include "inc/rputypes.h"


#ifdef __cplusplus
extern "C"
{
#endif 


////////////////////////////////////////////////////////////////////////
// onLoad
//
RPU_EXPORT 
void onLoad();



////////////////////////////////////////////////////////////////////////
// onUnload
//
RPU_EXPORT 
void onUnload();



////////////////////////////////////////////////////////////////////////
// getDevice
//
// @param device            Device Id of the GPU in use by the current thread
//
RPU_EXPORT 
void getDevice(PInteger device);



////////////////////////////////////////////////////////////////////////
// setDevice
//
// @param device            Select the GPU of given device Id for use by the current thread
//
RPU_EXPORT 
void setDevice(PInteger device);



////////////////////////////////////////////////////////////////////////
// countDevices
//
// @param count            Count of GPU devices
//
RPU_EXPORT
void countDevices(PInteger count);



////////////////////////////////////////////////////////////////////////
// findDistance
//
// @param pType             Type of distance metric
// @param points            Address of the input row vector matrix
// @param pNum              Number of row vectors in the matrix
// @param pDim              Dimension of each row vector in the matrix
// @param pMinkowski        Minkowski dimension
// @param pDistances        Distance matrix of the vectors
//
RPU_EXPORT 
void rpuDistance(
        const PString pType, 
        const PFloat points,
        const PInteger pNum, 
        const PInteger pDim,
        const PFloat pMinkowski,
        PFloat pDistances);



#ifdef __cplusplus
}
#endif 

#endif     // __RPUD_H__







