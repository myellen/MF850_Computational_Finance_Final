////////////////////////////////////////////////////////////////////////
//  rpud : An R package for GPU computing
//  Copyright (C) 2010-2014 Chi Yau. All Rights Reserved.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; version 3 of the License.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#ifndef __RPUBASE_H__
#define __RPUBASE_H__

#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdarg>
#include <stdexcept>


#ifdef _RPUD_
#include <R.h>
//#include <Rmath.h>  header collision with std::ios
#define RPU_BUFSIZE    R_PROBLEM_BUFSIZE
#else
#define RPU_BUFSIZE    8192
#endif

#if defined (_DEBUG) || !defined (_RPUD_)
#define _VERBOSE       1
#endif



////////////////////////////////////////////////////////////////////////
// debug macros
//

#ifdef _DEBUG

#define RPU_MSG(...)    \
    rpu::printf(__VA_ARGS__)

#else

#define RPU_MSG(...)

#endif     // _DEBUG


namespace rpu {

void printf(const char* fmt, ...);


////////////////////////////////////////////////////////////////////////
// RuntimeException
//
class RuntimeException : public std::runtime_error {

public:
    explicit RuntimeException(const char* msg) :
        std::runtime_error("") {

        std::strncpy(m_buf, msg, RPU_BUFSIZE);
    }

    explicit RuntimeException(const char* msg, const char* file, const int line) :
        std::runtime_error("") {

        std::sprintf(m_buf, "%s(%i): %s\n", file, line, msg);
    }

    explicit RuntimeException(const char* method, const char* msg,
            const char* szError, const char* file, const int line) :
        std::runtime_error("") {
     
        std::sprintf(m_buf, "%s(%i): %s: %s - %s.\n",
            file, line, method, msg, szError);
    }

    virtual const char* what() const throw() {
        return m_buf;
    }

private:
    char m_buf[RPU_BUFSIZE];
};


class AppException : public std::exception {

public:
    explicit AppException(const char* msg) {
        std::strncpy(m_buf, msg, RPU_BUFSIZE);
    }

    virtual const char* what() const throw() {
        return m_buf;
    }

private:
    char m_buf[RPU_BUFSIZE];
};


}   // namespace rpu



////////////////////////////////////////////////////////////////////////
// error handling
//

#define rpuError(msg)           __rpuError((msg), __FILE__, __LINE__)


inline void __rpuError(const char* errorMessage, 
        const char* file, const int line) {

    throw rpu::RuntimeException(errorMessage, file, line);
}


#endif     // __RPUBASE_H__



