////////////////////////////////////////////////////////////////////////
//  rpud : An R package for GPU computing
//  Copyright (C) 2010-2014 Chi Yau. All Rights Reserved.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; version 3 of the License.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#ifndef __RPUTYPES_H__
#define __RPUTYPES_H__


#ifdef __cplusplus
extern "C"
{
#endif 

//Throw out an error for unsupported target
#if defined(DOUBLE_PRECISION) && defined(__CUDACC__) && defined(CUDA_NO_SM_13_DOUBLE_INTRINSICS)
    #error -arch sm_13 nvcc flag is required to compile in double-precision mode
#endif


#ifdef DOUBLE_PRECISION
typedef double      Numeric;
#else
typedef float       Numeric;
#endif
typedef Numeric    *PNumeric;

typedef int         Integer;
typedef Integer    *PInteger;

typedef unsigned    Uint;
typedef Uint       *PUint;

typedef long        Long;
typedef Long       *PLong;

typedef unsigned long   ULong;
typedef ULong          *PULong;

typedef float       Float;
typedef Float      *PFloat;

typedef double      Double;
typedef Double     *PDouble;

typedef char       *String;
typedef String     *PString;

typedef void       *PVoid;


#ifdef DOUBLE_PRECISION
    #define RPU_ALIGN_T     __align__(8)
    #define RPU_ALIGN_T2    __align__(16)
#else
    #define RPU_ALIGN_T     __align__(4)
    #define RPU_ALIGN_T2    __align__(8)
#endif


#ifdef __cplusplus
}
#endif 


#ifdef __GNUC__
#define RPU_EXPORT  __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define RPU_EXPORT  __declspec(dllexport)
#else
#define RPU_EXPORT
#endif


#endif     // __RPUTYPES_H__



