////////////////////////////////////////////////////////////////////////
//  rpud : An R package for GPU computing
//  Copyright (C) 2010-2014 Chi Yau. All Rights Reserved.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; version 3 of the License.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


#ifndef __RPUDEV_H__
#define __RPUDEV_H__


// CUDA header
#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_texture_types.h>
#include <device_launch_parameters.h>
#include <math_constants.h>
#include <math_functions.h>

#include "rpubase.h"


////////////////////////////////////////////////////////////////////////
// literal constants
//
#define RPU_NON_NA(a)           (!isnan(a))
#define RPU_BOTH_NON_NA(a, b)   (!isnan(a) && !isnan(b))

#define RPU_FINITE(a)           (!isinf(a))
#define RPU_BOTH_FINITE(a, b)   (!isinf(a) && !isinf(b))

// only single precision for now
#define RPU_NUMERIC_INF         CUDART_INF_F
#define RPU_NUMERIC_NAN         CUDART_NAN_F
#define RPU_NUMERIC_MAX         CUDART_MAX_NORMAL_F
#define RPU_NUMERIC_MIN_DENORM  CUDART_MIN_DENORM_F
#define RPU_NUMERIC_PI          CUDART_PI_F

#define RPU_ZERO2               (make_double2(0, 0))



////////////////////////////////////////////////////////////////////////
// error handling
//

#define rpuSafeCall(err)        __rpuSafeCall((err), __FILE__, __LINE__)
#define rpuCheckMsg(msg)        __rpuCheckMsg((msg), __FILE__, __LINE__)


inline void __rpuSafeCall(cudaError err,
        const char* file, const int line) {

    if (cudaSuccess != err) {
        const char *szError = cudaGetErrorString(err);
        throw rpu::RuntimeException("rpuSafeCall",
                        "CUDA runtime error", szError, file, line);
    }
}


inline void __rpuCheckMsg(const char* errorMessage,
        const char* file, const int line) {

    const cudaError_t err = cudaGetLastError();
    const char *szError= cudaGetErrorString(err);
    if (cudaSuccess != err) {
        throw rpu::RuntimeException("rpuCheckMsg",
                        errorMessage, szError, file, line);
    }
}





#endif     // __RPUDEV_H__



